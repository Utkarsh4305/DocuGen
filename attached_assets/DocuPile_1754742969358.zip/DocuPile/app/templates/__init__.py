"""
Jinja2 templates for code generation
"""

