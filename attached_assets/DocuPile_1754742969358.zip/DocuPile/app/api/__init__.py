"""
API package for FastAPI routes
"""
