"""
FastAPI routes for the Universal Code Transpiler
"""

import os
import uuid
import tempfile
import logging
from typing import List, Dict, Any, Optional
from fastapi import APIRouter, UploadFile, File, HTTPException, BackgroundTasks, Query
from fastapi.responses import FileResponse
import shutil

from ..models import (
    ProjectUploadResponse, 
    TechStackAnalysis, 
    ConversionRequest, 
    ConversionResult,
    ConversionProgress,
    LanguageType,
    FrameworkType
)
from ..services.project_analyzer import ProjectAnalyzer
from ..services.language_detector import LanguageDetector
from ..core.file_handler import FileHandler
from ..core.transpiler import CodeTranspiler
from ..core.uir import UIRGenerator

router = APIRouter()
logger = logging.getLogger(__name__)

# Global instances
project_analyzer = ProjectAnalyzer()
language_detector = LanguageDetector()
file_handler = FileHandler()
transpiler = CodeTranspiler()
uir_generator = UIRGenerator()

# In-memory storage for conversion progress (use Redis in production)
conversion_progress = {}

@router.post("/upload", response_model=ProjectUploadResponse)
async def upload_project(file: UploadFile = File(...)):
    """Upload and analyze a project file or zip"""
    try:
        logger.info(f"Uploading project file: {file.filename}")
        
        # Check file size limit (50MB)
        MAX_FILE_SIZE = 50 * 1024 * 1024  # 50MB
        file_content = await file.read()
        if len(file_content) > MAX_FILE_SIZE:
            raise ValueError(f"File too large: {len(file_content) / (1024*1024):.1f}MB. Maximum allowed: 50MB")
        
        # Reset file position for further processing
        await file.seek(0)
        
        # Generate unique project ID
        project_id = str(uuid.uuid4())
        
        # Create temporary file
        with tempfile.NamedTemporaryFile(delete=False, suffix=f"_{file.filename}") as temp_file:
            temp_file.write(file_content)
            temp_path = temp_file.name
        
        try:
            # Extract project
            extraction_path = file_handler.extract_project(temp_path, project_id)
            
            # Analyze project
            analysis = project_analyzer.analyze_project(extraction_path)
            
            # Get supported conversions
            languages = [lang.language for lang in analysis.languages]
            supported_conversions = language_detector.get_supported_conversions(
                languages, analysis.frameworks
            )
            
            response = ProjectUploadResponse(
                project_id=project_id,
                analysis=analysis,
                supported_conversions=supported_conversions,
                upload_path=extraction_path
            )
            
            logger.info(f"Project upload completed: {project_id}")
            return response
            
        finally:
            # Cleanup temporary file
            if os.path.exists(temp_path):
                os.unlink(temp_path)
                
    except OSError as e:
        if e.errno == 122 or "quota exceeded" in str(e).lower() or "no space left" in str(e).lower():
            logger.error(f"Disk space error during upload: {str(e)}")
            raise HTTPException(
                status_code=413, 
                detail="Project too large. Please upload a smaller project (max 50MB) or try uploading only essential source code files. Large projects with dependencies, build files, or media assets should be filtered before upload."
            )
        else:
            logger.error(f"File system error during upload: {str(e)}")
            raise HTTPException(status_code=500, detail=f"File system error: {str(e)}")
    except ValueError as e:
        # Handle custom validation errors from file_handler
        logger.error(f"Validation error during upload: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Project upload failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Upload failed: {str(e)}")

@router.get("/project/{project_id}/analysis", response_model=TechStackAnalysis)
async def get_project_analysis(project_id: str):
    """Get detailed project analysis"""
    try:
        project_path = os.path.join("uploads", project_id)
        if not os.path.exists(project_path):
            raise HTTPException(status_code=404, detail="Project not found")
        
        analysis = project_analyzer.analyze_project(project_path)
        return analysis
        
    except Exception as e:
        logger.error(f"Failed to get project analysis: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/project/{project_id}/complexity")
async def get_project_complexity(project_id: str):
    """Get project complexity analysis"""
    try:
        project_path = os.path.join("uploads", project_id)
        if not os.path.exists(project_path):
            raise HTTPException(status_code=404, detail="Project not found")
        
        complexity = project_analyzer.analyze_code_complexity(project_path)
        return complexity
        
    except Exception as e:
        logger.error(f"Failed to get complexity analysis: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/convert", response_model=ConversionResult)
async def convert_project(
    request: ConversionRequest,
    background_tasks: BackgroundTasks
):
    """Start project conversion process"""
    try:
        logger.info(f"Starting conversion for project: {request.project_id}")
        
        project_path = os.path.join("uploads", request.project_id)
        if not os.path.exists(project_path):
            raise HTTPException(status_code=404, detail="Project not found")
        
        # Initialize conversion progress
        conversion_progress[request.project_id] = ConversionProgress(
            project_id=request.project_id,
            status="starting",
            progress_percentage=0.0,
            current_step="Initializing conversion",
            errors=[]
        )
        
        # Start background conversion
        background_tasks.add_task(
            perform_conversion,
            request,
            project_path
        )
        
        return ConversionResult(
            success=True,
            project_id=request.project_id,
            output_path="",
            conversion_log=["Conversion started"],
            errors=[],
            warnings=[],
            conversion_stats={"status": "in_progress"}
        )
        
    except Exception as e:
        logger.error(f"Failed to start conversion: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

async def perform_conversion(request: ConversionRequest, project_path: str):
    """Perform the actual conversion in background"""
    try:
        project_id = request.project_id
        
        # Update progress: Parsing project
        conversion_progress[project_id].status = "parsing"
        conversion_progress[project_id].progress_percentage = 20.0
        conversion_progress[project_id].current_step = "Parsing source code"
        
        # Generate UIR from project
        target_languages = [request.source_language.value]
        uir_data = project_analyzer.generate_uir_from_project(project_path, target_languages)
        
        # Update progress: Converting
        conversion_progress[project_id].status = "converting"
        conversion_progress[project_id].progress_percentage = 60.0
        conversion_progress[project_id].current_step = "Generating target code"
        
        # Extract main UIR for transpilation
        if uir_data['modules']:
            main_module = uir_data['modules'][0]
            from ..core.uir import UIRNode
            main_uir = UIRNode.from_dict(main_module['uir'])
            
            # Perform transpilation
            result = transpiler.transpile(main_uir, request)
            
            if result.success:
                # Update progress: Finalizing
                conversion_progress[project_id].status = "finalizing"
                conversion_progress[project_id].progress_percentage = 90.0
                conversion_progress[project_id].current_step = "Creating output archive"
                
                # Create output archive
                archive_path = file_handler.create_output_archive(project_id)
                result.output_path = archive_path
                
                # Update progress: Complete
                conversion_progress[project_id].status = "completed"
                conversion_progress[project_id].progress_percentage = 100.0
                conversion_progress[project_id].current_step = "Conversion completed"
                
                logger.info(f"Conversion completed successfully: {project_id}")
            else:
                conversion_progress[project_id].status = "failed"
                conversion_progress[project_id].errors = result.errors
                logger.error(f"Conversion failed: {project_id}")
        else:
            conversion_progress[project_id].status = "failed"
            conversion_progress[project_id].errors = ["No source files found"]
            
    except Exception as e:
        logger.error(f"Conversion process failed: {str(e)}")
        conversion_progress[project_id].status = "failed"
        conversion_progress[project_id].errors = [str(e)]

@router.get("/convert/{project_id}/progress", response_model=ConversionProgress)
async def get_conversion_progress(project_id: str):
    """Get conversion progress status"""
    try:
        if project_id not in conversion_progress:
            raise HTTPException(status_code=404, detail="Conversion not found")
        
        return conversion_progress[project_id]
        
    except Exception as e:
        logger.error(f"Failed to get conversion progress: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/convert/{project_id}/download")
async def download_converted_project(project_id: str):
    """Download converted project as zip"""
    try:
        archive_path = f"output/{project_id}.zip"
        
        if not os.path.exists(archive_path):
            raise HTTPException(status_code=404, detail="Converted project not found")
        
        return FileResponse(
            path=archive_path,
            filename=f"transpiled_{project_id}.zip",
            media_type="application/zip"
        )
        
    except Exception as e:
        logger.error(f"Failed to download project: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/languages")
async def get_supported_languages():
    """Get list of supported languages and frameworks"""
    return {
        "languages": [lang.value for lang in LanguageType],
        "frameworks": [framework.value for framework in FrameworkType],
        "categories": language_detector.language_categories.get("categories", {})
    }

@router.get("/languages/{language}/info")
async def get_language_info(language: str):
    """Get detailed information about a specific language"""
    try:
        info = language_detector.get_language_info(language)
        if not info:
            # Fallback to ecosystem info
            info = language_detector.get_language_ecosystem_info(language)
        
        return info or {"error": "Language not found"}
        
    except Exception as e:
        logger.error(f"Failed to get language info: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/conversions/compatibility")
async def get_conversion_compatibility(
    source_lang: str = Query(..., description="Source language"),
    target_lang: str = Query(..., description="Target language"),
    source_framework: Optional[str] = Query(None, description="Source framework"),
    target_framework: Optional[str] = Query(None, description="Target framework")
):
    """Get compatibility information for a specific conversion"""
    try:
        compatibility = language_detector.get_conversion_compatibility(
            source_lang, target_lang, source_framework, target_framework
        )
        return compatibility
        
    except Exception as e:
        logger.error(f"Failed to get conversion compatibility: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.delete("/project/{project_id}")
async def cleanup_project(project_id: str):
    """Clean up project files"""
    try:
        file_handler.cleanup_project(project_id)
        
        # Remove from progress tracking
        if project_id in conversion_progress:
            del conversion_progress[project_id]
        
        return {"message": "Project cleaned up successfully"}
        
    except Exception as e:
        logger.error(f"Failed to cleanup project: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/health")
async def health_check():
    """Health check endpoint for API"""
    return {
        "status": "healthy",
        "service": "universal-code-transpiler-api",
        "active_conversions": len(conversion_progress)
    }
