"""
AST Parser for multiple programming languages
Converts source code into Abstract Syntax Trees
"""

import ast
import json
import logging
from typing import List, Dict, Any, Optional
from pathlib import Path

logger = logging.getLogger(__name__)

class ASTParser:
    """Multi-language AST parser"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.supported_languages = {
            'python': ['.py'],
            'javascript': ['.js', '.jsx'],
            'typescript': ['.ts', '.tsx'],
            'java': ['.java'],
            'go': ['.go'],
            'sql': ['.sql']
        }
    
    def parse_file(self, filepath: str, language: str) -> Optional[Any]:
        """Parse a single file and return AST"""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
            
            return self.parse_content(content, language)
            
        except Exception as e:
            self.logger.error(f"Failed to parse file {filepath}: {str(e)}")
            return None
    
    def parse_content(self, content: str, language: str) -> Optional[Any]:
        """Parse content string and return AST"""
        try:
            if language == 'python':
                return self._parse_python(content)
            elif language in ['javascript', 'typescript']:
                return self._parse_javascript(content, language)
            elif language == 'java':
                return self._parse_java(content)
            elif language == 'go':
                return self._parse_go(content)
            elif language == 'sql':
                return self._parse_sql(content)
            else:
                self.logger.warning(f"Unsupported language: {language}")
                return None
                
        except Exception as e:
            self.logger.error(f"Failed to parse {language} content: {str(e)}")
            return None
    
    def _parse_python(self, content: str) -> ast.AST:
        """Parse Python code using built-in ast module"""
        try:
            tree = ast.parse(content)
            self.logger.debug(f"Parsed Python AST with {len(tree.body)} statements")
            return tree
        except SyntaxError as e:
            self.logger.error(f"Python syntax error: {e}")
            raise
    
    def _parse_javascript(self, content: str, language: str) -> Dict[str, Any]:
        """Parse JavaScript/TypeScript using a simple parser"""
        # Note: In production, you would use @babel/parser or similar
        # This is a simplified implementation for the MVP
        
        try:
            # Basic parsing for common patterns
            ast_nodes = []
            lines = content.split('\n')
            
            current_function = None
            current_class = None
            brace_depth = 0
            
            for i, line in enumerate(lines):
                line = line.strip()
                if not line or line.startswith('//'):
                    continue
                
                # Function declarations
                if 'function ' in line and not line.startswith('//'):
                    func_match = self._extract_function_info(line)
                    if func_match:
                        ast_nodes.append({
                            'type': 'FunctionDeclaration',
                            'id': {'name': func_match['name']},
                            'params': func_match['params'],
                            'async': 'async' in line,
                            'body': {'body': []},
                            'line': i + 1
                        })
                
                # Variable declarations
                elif any(keyword in line for keyword in ['const ', 'let ', 'var ']):
                    var_info = self._extract_variable_info(line)
                    if var_info:
                        ast_nodes.append({
                            'type': 'VariableDeclaration',
                            'kind': var_info['kind'],
                            'declarations': [{
                                'id': {'name': var_info['name']},
                                'init': var_info['init']
                            }],
                            'line': i + 1
                        })
                
                # Class declarations
                elif 'class ' in line and not line.startswith('//'):
                    class_info = self._extract_class_info(line)
                    if class_info:
                        ast_nodes.append({
                            'type': 'ClassDeclaration',
                            'id': {'name': class_info['name']},
                            'superClass': class_info.get('extends'),
                            'body': {'body': []},
                            'line': i + 1
                        })
                
                # Import statements
                elif line.startswith('import '):
                    import_info = self._extract_import_info(line)
                    if import_info:
                        ast_nodes.append({
                            'type': 'ImportDeclaration',
                            'source': {'value': import_info['source']},
                            'specifiers': import_info['specifiers'],
                            'line': i + 1
                        })
            
            return {
                'type': 'Program',
                'body': ast_nodes,
                'sourceType': 'module' if language == 'typescript' else 'script'
            }
            
        except Exception as e:
            self.logger.error(f"JavaScript parsing error: {e}")
            return {'type': 'Program', 'body': [], 'errors': [str(e)]}
    
    def _parse_java(self, content: str) -> Dict[str, Any]:
        """Basic Java parsing"""
        # Simplified Java parser for MVP
        ast_nodes = []
        lines = content.split('\n')
        
        for i, line in enumerate(lines):
            line = line.strip()
            if not line or line.startswith('//'):
                continue
            
            # Class declarations
            if line.startswith('public class ') or line.startswith('class '):
                class_name = line.split('class ')[1].split()[0].rstrip('{')
                ast_nodes.append({
                    'type': 'ClassDeclaration',
                    'name': class_name,
                    'line': i + 1
                })
            
            # Method declarations
            elif 'public ' in line and '(' in line and ')' in line:
                method_info = self._extract_java_method_info(line)
                if method_info:
                    ast_nodes.append({
                        'type': 'MethodDeclaration',
                        'name': method_info['name'],
                        'returnType': method_info['returnType'],
                        'parameters': method_info['parameters'],
                        'line': i + 1
                    })
        
        return {'type': 'CompilationUnit', 'body': ast_nodes}
    
    def _parse_go(self, content: str) -> Dict[str, Any]:
        """Basic Go parsing"""
        ast_nodes = []
        lines = content.split('\n')
        
        for i, line in enumerate(lines):
            line = line.strip()
            if not line or line.startswith('//'):
                continue
            
            # Function declarations
            if line.startswith('func '):
                func_info = self._extract_go_function_info(line)
                if func_info:
                    ast_nodes.append({
                        'type': 'FunctionDeclaration',
                        'name': func_info['name'],
                        'parameters': func_info['parameters'],
                        'returnType': func_info['returnType'],
                        'line': i + 1
                    })
            
            # Package declaration
            elif line.startswith('package '):
                package_name = line.split('package ')[1]
                ast_nodes.append({
                    'type': 'PackageDeclaration',
                    'name': package_name,
                    'line': i + 1
                })
        
        return {'type': 'File', 'body': ast_nodes}
    
    def _parse_sql(self, content: str) -> Dict[str, Any]:
        """Basic SQL parsing"""
        statements = []
        
        # Split by semicolon for individual statements
        sql_statements = [s.strip() for s in content.split(';') if s.strip()]
        
        for i, stmt in enumerate(sql_statements):
            stmt_upper = stmt.upper()
            
            if stmt_upper.startswith('CREATE TABLE'):
                table_info = self._extract_sql_table_info(stmt)
                statements.append({
                    'type': 'CreateTableStatement',
                    'tableName': table_info['name'],
                    'columns': table_info['columns'],
                    'line': i + 1
                })
            
            elif stmt_upper.startswith('SELECT'):
                statements.append({
                    'type': 'SelectStatement',
                    'query': stmt,
                    'line': i + 1
                })
            
            elif stmt_upper.startswith('INSERT'):
                statements.append({
                    'type': 'InsertStatement',
                    'query': stmt,
                    'line': i + 1
                })
        
        return {'type': 'SQLProgram', 'statements': statements}
    
    def _extract_function_info(self, line: str) -> Optional[Dict[str, Any]]:
        """Extract function information from JavaScript line"""
        try:
            # Simple regex-like extraction
            if 'function ' in line:
                parts = line.split('function ')[1]
                if '(' in parts:
                    name = parts.split('(')[0].strip()
                    params_part = parts.split('(')[1].split(')')[0]
                    params = [p.strip() for p in params_part.split(',') if p.strip()]
                    return {'name': name, 'params': params}
        except:
            pass
        return None
    
    def _extract_variable_info(self, line: str) -> Optional[Dict[str, Any]]:
        """Extract variable information from JavaScript line"""
        try:
            for keyword in ['const ', 'let ', 'var ']:
                if keyword in line:
                    rest = line.split(keyword)[1]
                    if '=' in rest:
                        name = rest.split('=')[0].strip()
                        init_value = rest.split('=')[1].strip().rstrip(';')
                        return {
                            'kind': keyword.strip(),
                            'name': name,
                            'init': {'type': 'Literal', 'value': init_value}
                        }
        except:
            pass
        return None
    
    def _extract_class_info(self, line: str) -> Optional[Dict[str, Any]]:
        """Extract class information from JavaScript line"""
        try:
            if 'class ' in line:
                parts = line.split('class ')[1]
                class_info = {'name': '', 'extends': None}
                
                if ' extends ' in parts:
                    name_part = parts.split(' extends ')[0].strip()
                    extends_part = parts.split(' extends ')[1].split()[0].strip()
                    class_info['name'] = name_part
                    class_info['extends'] = {'name': extends_part}
                else:
                    class_info['name'] = parts.split()[0].strip()
                
                return class_info
        except:
            pass
        return None
    
    def _extract_import_info(self, line: str) -> Optional[Dict[str, Any]]:
        """Extract import information from JavaScript line"""
        try:
            if ' from ' in line:
                import_part = line.split(' from ')[0].replace('import ', '').strip()
                source_part = line.split(' from ')[1].strip().strip("';\"")
                
                specifiers = []
                if import_part.startswith('{') and import_part.endswith('}'):
                    # Named imports
                    names = import_part[1:-1].split(',')
                    for name in names:
                        specifiers.append({'local': {'name': name.strip()}})
                else:
                    # Default import
                    specifiers.append({'local': {'name': import_part}})
                
                return {'source': source_part, 'specifiers': specifiers}
        except:
            pass
        return None
    
    def _extract_java_method_info(self, line: str) -> Optional[Dict[str, Any]]:
        """Extract Java method information"""
        try:
            # Basic method parsing
            parts = line.split('(')
            if len(parts) >= 2:
                signature = parts[0].strip()
                params = parts[1].split(')')[0]
                
                sig_parts = signature.split()
                method_name = sig_parts[-1]
                return_type = sig_parts[-2] if len(sig_parts) > 1 else 'void'
                
                parameters = [p.strip() for p in params.split(',') if p.strip()]
                
                return {
                    'name': method_name,
                    'returnType': return_type,
                    'parameters': parameters
                }
        except:
            pass
        return None
    
    def _extract_go_function_info(self, line: str) -> Optional[Dict[str, Any]]:
        """Extract Go function information"""
        try:
            # func name(params) returnType
            func_part = line.replace('func ', '').strip()
            if '(' in func_part:
                name = func_part.split('(')[0]
                rest = func_part.split('(')[1]
                
                if ')' in rest:
                    params = rest.split(')')[0]
                    return_type = rest.split(')')[1].strip()
                    
                    return {
                        'name': name,
                        'parameters': [p.strip() for p in params.split(',') if p.strip()],
                        'returnType': return_type
                    }
        except:
            pass
        return None
    
    def _extract_sql_table_info(self, stmt: str) -> Dict[str, Any]:
        """Extract SQL table creation information"""
        try:
            # CREATE TABLE name (columns)
            parts = stmt.split('(', 1)
            if len(parts) >= 2:
                table_name = parts[0].replace('CREATE TABLE', '').strip()
                columns_part = parts[1].rsplit(')', 1)[0]
                
                columns = []
                for col in columns_part.split(','):
                    col = col.strip()
                    if col:
                        col_parts = col.split()
                        if len(col_parts) >= 2:
                            columns.append({
                                'name': col_parts[0],
                                'type': col_parts[1],
                                'constraints': ' '.join(col_parts[2:]) if len(col_parts) > 2 else ''
                            })
                
                return {'name': table_name, 'columns': columns}
        except:
            pass
        return {'name': 'unknown', 'columns': []}
