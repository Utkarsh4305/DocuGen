"""
Core transpilation engine
Converts UIR to target language code using templates
"""

import os
import logging
from typing import Dict, List, Any, Optional
from pathlib import Path
from jinja2 import Environment, FileSystemLoader, Template

from .uir import UIRNode, UIRNodeType
from ..models import ConversionRequest, ConversionResult

logger = logging.getLogger(__name__)

class CodeTranspiler:
    """Core code transpilation engine"""
    
    def __init__(self, templates_dir: str = "app/templates"):
        self.logger = logging.getLogger(__name__)
        self.templates_dir = templates_dir
        self.jinja_env = Environment(
            loader=FileSystemLoader(templates_dir),
            trim_blocks=True,
            lstrip_blocks=True
        )
        
        # Language-specific code generation rules
        self.language_rules = {
            'typescript': {
                'file_extension': '.ts',
                'templates': {
                    'function': 'typescript_function.jinja2',
                    'class': 'typescript_class.jinja2',
                    'interface': 'typescript_interface.jinja2',
                    'component': 'react_component.jinja2'
                },
                'imports': self._generate_typescript_imports,
                'type_mapping': {
                    'string': 'string',
                    'number': 'number',
                    'boolean': 'boolean',
                    'array': 'Array<any>',
                    'object': 'object',
                    'function': 'Function'
                }
            },
            'python': {
                'file_extension': '.py',
                'templates': {
                    'function': 'python_function.jinja2',
                    'class': 'python_class.jinja2',
                    'api_route': 'python_fastapi.jinja2'
                },
                'imports': self._generate_python_imports,
                'type_mapping': {
                    'string': 'str',
                    'number': 'Union[int, float]',
                    'boolean': 'bool',
                    'array': 'List[Any]',
                    'object': 'Dict[str, Any]',
                    'function': 'Callable'
                }
            },
            'javascript': {
                'file_extension': '.js',
                'templates': {
                    'function': 'javascript_function.jinja2',
                    'class': 'javascript_class.jinja2',
                    'component': 'react_component.jinja2'
                },
                'imports': self._generate_javascript_imports,
                'type_mapping': {}
            }
        }
    
    def transpile(self, uir: UIRNode, request: ConversionRequest) -> ConversionResult:
        """Main transpilation method"""
        try:
            self.logger.info(f"Starting transpilation from {request.source_language} to {request.target_language}")
            
            # Initialize result
            result = ConversionResult(
                success=False,
                project_id=request.project_id,
                output_path="",
                conversion_log=[],
                errors=[],
                warnings=[],
                conversion_stats={}
            )
            
            # Create output directory
            output_dir = f"output/{request.project_id}"
            os.makedirs(output_dir, exist_ok=True)
            result.output_path = output_dir
            
            # Generate target code
            generated_files = self._generate_code_from_uir(
                uir, 
                request.target_language.value,
                request.target_framework.value if request.target_framework else None
            )
            
            # Write files to output directory
            for file_info in generated_files:
                file_path = os.path.join(output_dir, file_info['path'])
                os.makedirs(os.path.dirname(file_path), exist_ok=True)
                
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(file_info['content'])
                
                result.conversion_log.append(f"Generated: {file_info['path']}")
            
            # Generate package files if needed
            self._generate_package_files(output_dir, request.target_language.value, request.target_framework)
            
            result.success = True
            result.conversion_stats = {
                'files_generated': len(generated_files),
                'target_language': request.target_language.value,
                'target_framework': request.target_framework.value if request.target_framework else None
            }
            
            self.logger.info(f"Transpilation completed successfully. Generated {len(generated_files)} files.")
            return result
            
        except Exception as e:
            self.logger.error(f"Transpilation failed: {str(e)}")
            result.errors.append(str(e))
            return result
    
    def _generate_code_from_uir(self, uir: UIRNode, target_language: str, target_framework: Optional[str] = None) -> List[Dict[str, str]]:
        """Generate code files from UIR"""
        generated_files = []
        
        # Main file generation
        main_file = self._generate_main_file(uir, target_language, target_framework)
        if main_file:
            generated_files.append(main_file)
        
        # Generate individual component/module files
        for child in uir.children:
            if child.node_type in [UIRNodeType.CLASS, UIRNodeType.COMPONENT, UIRNodeType.MODULE]:
                file_info = self._generate_file_from_node(child, target_language, target_framework)
                if file_info:
                    generated_files.append(file_info)
        
        return generated_files
    
    def _generate_main_file(self, uir: UIRNode, target_language: str, target_framework: Optional[str] = None) -> Optional[Dict[str, str]]:
        """Generate the main application file"""
        try:
            if target_language == 'python' and target_framework == 'fastapi':
                template = self.jinja_env.get_template('python_fastapi.jinja2')
                
                # Extract API routes from UIR
                routes = []
                for child in uir.children:
                    if child.node_type == UIRNodeType.ROUTE:
                        routes.append({
                            'method': child.properties.get('method', 'GET'),
                            'path': child.properties.get('path', '/'),
                            'function_name': child.identifier,
                            'parameters': child.properties.get('parameters', []),
                            'return_type': child.properties.get('return_type', 'dict')
                        })
                
                content = template.render(
                    routes=routes,
                    imports=self._get_required_imports(uir, target_language),
                    app_name=uir.properties.get('name', 'app')
                )
                
                return {
                    'path': f"main{self.language_rules[target_language]['file_extension']}",
                    'content': content
                }
            
            elif target_language == 'typescript' and target_framework == 'react':
                template = self.jinja_env.get_template('react_component.jinja2')
                
                # Extract React components from UIR
                components = []
                for child in uir.children:
                    if child.node_type == UIRNodeType.COMPONENT:
                        components.append({
                            'name': child.identifier,
                            'props': child.properties.get('props', []),
                            'state': child.properties.get('state', []),
                            'methods': child.properties.get('methods', [])
                        })
                
                content = template.render(
                    components=components,
                    imports=self._get_required_imports(uir, target_language)
                )
                
                return {
                    'path': f"App{self.language_rules[target_language]['file_extension']}",
                    'content': content
                }
            
        except Exception as e:
            self.logger.error(f"Failed to generate main file: {str(e)}")
        
        return None
    
    def _generate_file_from_node(self, node: UIRNode, target_language: str, target_framework: Optional[str] = None) -> Optional[Dict[str, str]]:
        """Generate a file from a single UIR node"""
        try:
            language_config = self.language_rules.get(target_language)
            if not language_config:
                self.logger.warning(f"Unsupported target language: {target_language}")
                return None
            
            # Determine template based on node type
            template_name = None
            if node.node_type == UIRNodeType.CLASS:
                template_name = language_config['templates'].get('class')
            elif node.node_type == UIRNodeType.FUNCTION:
                template_name = language_config['templates'].get('function')
            elif node.node_type == UIRNodeType.COMPONENT:
                template_name = language_config['templates'].get('component')
            elif node.node_type == UIRNodeType.INTERFACE:
                template_name = language_config['templates'].get('interface')
            
            if not template_name:
                self.logger.warning(f"No template found for node type: {node.node_type}")
                return None
            
            # Load and render template
            try:
                template = self.jinja_env.get_template(template_name)
            except:
                # Fallback to generic template
                template = self._create_generic_template(node.node_type, target_language)
            
            content = template.render(
                node=node,
                identifier=node.identifier,
                properties=node.properties,
                children=node.children,
                type_mapping=language_config.get('type_mapping', {}),
                target_language=target_language
            )
            
            # Generate filename
            filename = f"{node.identifier or 'unnamed'}{language_config['file_extension']}"
            
            return {
                'path': filename,
                'content': content
            }
            
        except Exception as e:
            self.logger.error(f"Failed to generate file from node: {str(e)}")
            return None
    
    def _create_generic_template(self, node_type: UIRNodeType, target_language: str) -> Template:
        """Create a generic template for unsupported node types"""
        if target_language == 'python':
            if node_type == UIRNodeType.CLASS:
                template_str = """
class {{ identifier }}:
    \"\"\"Generated class\"\"\"
    
    def __init__(self):
        pass
    
    {% for child in children %}
    {% if child.node_type.value == 'function' %}
    def {{ child.identifier }}(self):
        \"\"\"Generated method\"\"\"
        pass
    {% endif %}
    {% endfor %}
"""
            elif node_type == UIRNodeType.FUNCTION:
                template_str = """
def {{ identifier }}():
    \"\"\"Generated function\"\"\"
    pass
"""
            else:
                template_str = "# Generated code for {{ identifier }}\npass"
        
        elif target_language == 'typescript':
            if node_type == UIRNodeType.CLASS:
                template_str = """
export class {{ identifier }} {
    constructor() {
        // Generated constructor
    }
    
    {% for child in children %}
    {% if child.node_type.value == 'function' %}
    {{ child.identifier }}(): void {
        // Generated method
    }
    {% endif %}
    {% endfor %}
}
"""
            elif node_type == UIRNodeType.FUNCTION:
                template_str = """
export function {{ identifier }}(): void {
    // Generated function
}
"""
            else:
                template_str = "// Generated code for {{ identifier }}"
        
        else:
            template_str = "// Generated code for {{ identifier }}"
        
        return Template(template_str)
    
    def _get_required_imports(self, uir: UIRNode, target_language: str) -> List[str]:
        """Determine required imports based on UIR content"""
        imports = set()
        
        def collect_imports(node: UIRNode):
            if node.node_type == UIRNodeType.IMPORT:
                if target_language == 'python':
                    if node.value:
                        imports.add(f"from {node.value} import {', '.join(node.properties.get('names', []))}")
                    else:
                        imports.add(f"import {', '.join(node.properties.get('modules', []))}")
                elif target_language == 'typescript':
                    specifiers = node.properties.get('specifiers', [])
                    if specifiers:
                        names = [s.get('local', {}).get('name', '') for s in specifiers]
                        imports.add(f"import {{ {', '.join(names)} }} from '{node.value}'")
            
            for child in node.children:
                collect_imports(child)
        
        collect_imports(uir)
        return list(imports)
    
    def _generate_typescript_imports(self, dependencies: List[str]) -> List[str]:
        """Generate TypeScript import statements"""
        imports = []
        for dep in dependencies:
            if dep.startswith('react'):
                imports.append("import React from 'react';")
            elif dep.startswith('@types/'):
                continue  # Type-only imports handled separately
            else:
                imports.append(f"import {{ /* imports */ }} from '{dep}';")
        return imports
    
    def _generate_python_imports(self, dependencies: List[str]) -> List[str]:
        """Generate Python import statements"""
        imports = []
        for dep in dependencies:
            if dep == 'fastapi':
                imports.append("from fastapi import FastAPI, HTTPException")
            elif dep == 'typing':
                imports.append("from typing import List, Dict, Any, Optional")
            else:
                imports.append(f"import {dep}")
        return imports
    
    def _generate_javascript_imports(self, dependencies: List[str]) -> List[str]:
        """Generate JavaScript import statements"""
        imports = []
        for dep in dependencies:
            if dep.startswith('react'):
                imports.append("import React from 'react';")
            else:
                imports.append(f"import {{ /* imports */ }} from '{dep}';")
        return imports
    
    def _generate_package_files(self, output_dir: str, target_language: str, target_framework: Optional[str] = None):
        """Generate package configuration files"""
        try:
            if target_language == 'python':
                # Generate requirements.txt placeholder
                with open(os.path.join(output_dir, 'requirements_generated.txt'), 'w') as f:
                    f.write("# Generated requirements\n")
                    if target_framework == 'fastapi':
                        f.write("fastapi>=0.68.0\n")
                        f.write("uvicorn>=0.15.0\n")
                        f.write("pydantic>=1.8.0\n")
            
            elif target_language in ['typescript', 'javascript']:
                # Generate package.json placeholder
                package_data = {
                    "name": "transpiled-project",
                    "version": "1.0.0",
                    "description": "Generated by Universal Code Transpiler",
                    "main": "index.js",
                    "scripts": {
                        "start": "node index.js",
                        "dev": "nodemon index.js"
                    }
                }
                
                if target_framework == 'react':
                    package_data["scripts"]["start"] = "react-scripts start"
                    package_data["scripts"]["build"] = "react-scripts build"
                
                import json
                with open(os.path.join(output_dir, 'package_generated.json'), 'w') as f:
                    json.dump(package_data, f, indent=2)
            
        except Exception as e:
            self.logger.error(f"Failed to generate package files: {str(e)}")
