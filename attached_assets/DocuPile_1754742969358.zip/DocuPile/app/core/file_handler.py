"""
File handling utilities for project upload and processing
"""

import os
import zipfile
import shutil
import tempfile
import logging
from typing import List, Dict, Any, Optional, Tuple
from pathlib import Path
import mimetypes

logger = logging.getLogger(__name__)

class FileHandler:
    """Handles file operations for project processing"""
    
    def __init__(self, upload_dir: str = "uploads", output_dir: str = "output"):
        self.upload_dir = upload_dir
        self.output_dir = output_dir
        self.logger = logging.getLogger(__name__)
        
        # Supported file extensions by language
        self.language_extensions = {
            'python': ['.py', '.pyx', '.pyi'],
            'javascript': ['.js', '.jsx', '.mjs'],
            'typescript': ['.ts', '.tsx', '.d.ts'],
            'java': ['.java'],
            'kotlin': ['.kt', '.kts'],
            'swift': ['.swift'],
            'dart': ['.dart'],
            'go': ['.go'],
            'rust': ['.rs'],
            'c': ['.c', '.h'],
            'cpp': ['.cpp', '.cxx', '.cc', '.hpp', '.hxx'],
            'csharp': ['.cs'],
            'php': ['.php', '.phtml'],
            'ruby': ['.rb', '.rbw'],
            'sql': ['.sql', '.ddl', '.dml'],
            'html': ['.html', '.htm'],
            'css': ['.css', '.scss', '.sass', '.less'],
            'json': ['.json'],
            'yaml': ['.yaml', '.yml'],
            'xml': ['.xml', '.xhtml'],
            'markdown': ['.md', '.markdown']
        }
        
        # Common config files to detect project structure
        self.config_files = {
            'package.json': 'nodejs',
            'requirements.txt': 'python',
            'Pipfile': 'python',
            'pyproject.toml': 'python',
            'pom.xml': 'java',
            'build.gradle': 'java',
            'Cargo.toml': 'rust',
            'go.mod': 'go',
            'composer.json': 'php',
            'Gemfile': 'ruby',
            'pubspec.yaml': 'dart'
        }
        
        # Create directories if they don't exist
        os.makedirs(self.upload_dir, exist_ok=True)
        os.makedirs(self.output_dir, exist_ok=True)
    
    def extract_project(self, file_path: str, project_id: str) -> str:
        """Extract uploaded project file and return extraction path"""
        try:
            extraction_path = os.path.join(self.upload_dir, project_id)
            
            # Remove existing directory if it exists
            if os.path.exists(extraction_path):
                shutil.rmtree(extraction_path)
            
            os.makedirs(extraction_path, exist_ok=True)
            
            # Check if it's a zip file
            if zipfile.is_zipfile(file_path):
                self.logger.info(f"Extracting zip file: {file_path}")
                with zipfile.ZipFile(file_path, 'r') as zip_ref:
                    zip_ref.extractall(extraction_path)
            else:
                # Single file upload
                self.logger.info(f"Processing single file: {file_path}")
                shutil.copy2(file_path, extraction_path)
            
            self.logger.info(f"Project extracted to: {extraction_path}")
            return extraction_path
            
        except Exception as e:
            self.logger.error(f"Failed to extract project: {str(e)}")
            raise
    
    def analyze_project_structure(self, project_path: str) -> Dict[str, Any]:
        """Analyze project structure and return detailed information"""
        try:
            analysis = {
                'total_files': 0,
                'total_lines': 0,
                'languages': {},
                'frameworks': [],
                'dependencies': {},
                'project_type': 'unknown',
                'file_tree': {},
                'config_files': [],
                'asset_files': []
            }
            
            # Walk through all files
            for root, dirs, files in os.walk(project_path):
                # Skip common ignore directories
                dirs[:] = [d for d in dirs if not d.startswith('.') and d not in ['node_modules', '__pycache__', 'target', 'build', 'dist']]
                
                for file in files:
                    if file.startswith('.'):
                        continue
                    
                    file_path = os.path.join(root, file)
                    relative_path = os.path.relpath(file_path, project_path)
                    
                    analysis['total_files'] += 1
                    
                    # Count lines of code
                    try:
                        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                            lines = len(f.readlines())
                            analysis['total_lines'] += lines
                    except:
                        lines = 0
                    
                    # Detect language by extension
                    file_ext = Path(file).suffix.lower()
                    language = self._detect_language_by_extension(file_ext)
                    
                    if language:
                        if language not in analysis['languages']:
                            analysis['languages'][language] = {
                                'files': 0,
                                'lines': 0,
                                'extensions': set()
                            }
                        
                        analysis['languages'][language]['files'] += 1
                        analysis['languages'][language]['lines'] += lines
                        analysis['languages'][language]['extensions'].add(file_ext)
                    
                    # Check for config files
                    if file in self.config_files:
                        analysis['config_files'].append({
                            'file': file,
                            'path': relative_path,
                            'type': self.config_files[file]
                        })
                    
                    # Check for asset files
                    if self._is_asset_file(file):
                        analysis['asset_files'].append(relative_path)
            
            # Convert sets to lists for JSON serialization
            for lang_info in analysis['languages'].values():
                lang_info['extensions'] = list(lang_info['extensions'])
            
            # Detect frameworks and project type
            analysis['frameworks'] = self._detect_frameworks(project_path, analysis['config_files'])
            analysis['project_type'] = self._determine_project_type(analysis['languages'], analysis['frameworks'])
            
            # Parse dependencies from config files
            analysis['dependencies'] = self._parse_dependencies(project_path, analysis['config_files'])
            
            self.logger.info(f"Project analysis completed: {analysis['total_files']} files, {len(analysis['languages'])} languages")
            return analysis
            
        except Exception as e:
            self.logger.error(f"Failed to analyze project structure: {str(e)}")
            raise
    
    def get_source_files(self, project_path: str, languages: List[str] = None) -> List[Dict[str, Any]]:
        """Get all source files optionally filtered by languages"""
        try:
            source_files = []
            
            for root, dirs, files in os.walk(project_path):
                # Skip ignore directories
                dirs[:] = [d for d in dirs if not d.startswith('.') and d not in ['node_modules', '__pycache__', 'target', 'build', 'dist']]
                
                for file in files:
                    if file.startswith('.'):
                        continue
                    
                    file_path = os.path.join(root, file)
                    relative_path = os.path.relpath(file_path, project_path)
                    file_ext = Path(file).suffix.lower()
                    language = self._detect_language_by_extension(file_ext)
                    
                    # Filter by languages if specified
                    if languages and language not in languages:
                        continue
                    
                    if language:  # Only include files with detected languages
                        try:
                            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                                content = f.read()
                            
                            source_files.append({
                                'path': relative_path,
                                'absolute_path': file_path,
                                'language': language,
                                'extension': file_ext,
                                'content': content,
                                'size': len(content),
                                'lines': len(content.splitlines())
                            })
                        except Exception as e:
                            self.logger.warning(f"Could not read file {file_path}: {str(e)}")
            
            self.logger.info(f"Found {len(source_files)} source files")
            return source_files
            
        except Exception as e:
            self.logger.error(f"Failed to get source files: {str(e)}")
            raise
    
    def create_output_archive(self, project_id: str) -> str:
        """Create a zip archive of the transpiled project"""
        try:
            output_path = os.path.join(self.output_dir, project_id)
            archive_path = f"{output_path}.zip"
            
            if not os.path.exists(output_path):
                raise FileNotFoundError(f"Output directory not found: {output_path}")
            
            with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED) as zip_file:
                for root, dirs, files in os.walk(output_path):
                    for file in files:
                        file_path = os.path.join(root, file)
                        arc_name = os.path.relpath(file_path, output_path)
                        zip_file.write(file_path, arc_name)
            
            self.logger.info(f"Created output archive: {archive_path}")
            return archive_path
            
        except Exception as e:
            self.logger.error(f"Failed to create output archive: {str(e)}")
            raise
    
    def cleanup_project(self, project_id: str):
        """Clean up temporary project files"""
        try:
            # Clean upload directory
            upload_path = os.path.join(self.upload_dir, project_id)
            if os.path.exists(upload_path):
                shutil.rmtree(upload_path)
            
            # Clean output directory (keep archive)
            output_path = os.path.join(self.output_dir, project_id)
            if os.path.exists(output_path):
                shutil.rmtree(output_path)
            
            self.logger.info(f"Cleaned up project files for: {project_id}")
            
        except Exception as e:
            self.logger.warning(f"Failed to cleanup project {project_id}: {str(e)}")
    
    def _detect_language_by_extension(self, extension: str) -> Optional[str]:
        """Detect programming language by file extension"""
        for language, extensions in self.language_extensions.items():
            if extension in extensions:
                return language
        return None
    
    def _detect_frameworks(self, project_path: str, config_files: List[Dict[str, Any]]) -> List[str]:
        """Detect frameworks used in the project"""
        frameworks = []
        
        # Check package.json for JavaScript frameworks
        package_json_path = os.path.join(project_path, 'package.json')
        if os.path.exists(package_json_path):
            try:
                import json
                with open(package_json_path, 'r') as f:
                    package_data = json.load(f)
                
                dependencies = {**package_data.get('dependencies', {}), **package_data.get('devDependencies', {})}
                
                if 'react' in dependencies:
                    frameworks.append('react')
                if 'vue' in dependencies:
                    frameworks.append('vue')
                if 'angular' in dependencies or '@angular/core' in dependencies:
                    frameworks.append('angular')
                if 'express' in dependencies:
                    frameworks.append('express')
                if 'next' in dependencies or 'next.js' in dependencies:
                    frameworks.append('nextjs')
                if 'gatsby' in dependencies:
                    frameworks.append('gatsby')
                if 'svelte' in dependencies:
                    frameworks.append('svelte')
            except:
                pass
        
        # Check requirements.txt for Python frameworks
        requirements_path = os.path.join(project_path, 'requirements.txt')
        if os.path.exists(requirements_path):
            try:
                with open(requirements_path, 'r') as f:
                    requirements = f.read().lower()
                
                if 'django' in requirements:
                    frameworks.append('django')
                if 'flask' in requirements:
                    frameworks.append('flask')
                if 'fastapi' in requirements:
                    frameworks.append('fastapi')
                if 'streamlit' in requirements:
                    frameworks.append('streamlit')
                if 'tornado' in requirements:
                    frameworks.append('tornado')
            except:
                pass
        
        # Check for specific framework files
        framework_indicators = {
            'angular.json': 'angular',
            'vue.config.js': 'vue',
            'nuxt.config.js': 'nuxtjs',
            'next.config.js': 'nextjs',
            'gatsby-config.js': 'gatsby',
            'svelte.config.js': 'svelte',
            'django.py': 'django',
            'manage.py': 'django',
            'app.py': 'flask',
            'main.py': 'fastapi',
            'pubspec.yaml': 'flutter',
            'android/app/build.gradle': 'react-native',
            'ios/Podfile': 'react-native'
        }
        
        for indicator, framework in framework_indicators.items():
            if os.path.exists(os.path.join(project_path, indicator)):
                if framework not in frameworks:
                    frameworks.append(framework)
        
        return frameworks
    
    def _determine_project_type(self, languages: Dict[str, Any], frameworks: List[str]) -> str:
        """Determine the primary project type"""
        # Check for mobile frameworks
        mobile_frameworks = ['flutter', 'react-native', 'ionic']
        if any(f in frameworks for f in mobile_frameworks):
            return 'mobile'
        
        # Check for frontend frameworks
        frontend_frameworks = ['react', 'vue', 'angular', 'svelte', 'nextjs', 'gatsby']
        frontend_languages = ['javascript', 'typescript', 'html', 'css']
        
        # Check for backend frameworks
        backend_frameworks = ['django', 'flask', 'fastapi', 'express', 'spring']
        backend_languages = ['python', 'java', 'go', 'rust', 'csharp']
        
        has_frontend = any(f in frameworks for f in frontend_frameworks) or any(l in languages for l in frontend_languages)
        has_backend = any(f in frameworks for f in backend_frameworks) or any(l in languages for l in backend_languages)
        
        if has_frontend and has_backend:
            return 'full_stack'
        elif has_frontend:
            return 'frontend'
        elif has_backend:
            return 'backend'
        elif 'sql' in languages:
            return 'database'
        else:
            return 'unknown'
    
    def _parse_dependencies(self, project_path: str, config_files: List[Dict[str, Any]]) -> Dict[str, List[str]]:
        """Parse dependencies from configuration files"""
        dependencies = {}
        
        # Parse package.json
        package_json_path = os.path.join(project_path, 'package.json')
        if os.path.exists(package_json_path):
            try:
                import json
                with open(package_json_path, 'r') as f:
                    package_data = json.load(f)
                
                deps = package_data.get('dependencies', {})
                dev_deps = package_data.get('devDependencies', {})
                
                dependencies['npm'] = list(deps.keys()) + list(dev_deps.keys())
            except:
                dependencies['npm'] = []
        
        # Parse requirements.txt
        requirements_path = os.path.join(project_path, 'requirements.txt')
        if os.path.exists(requirements_path):
            try:
                with open(requirements_path, 'r') as f:
                    lines = f.readlines()
                
                deps = []
                for line in lines:
                    line = line.strip()
                    if line and not line.startswith('#'):
                        # Extract package name (before == or >= etc.)
                        package = line.split('==')[0].split('>=')[0].split('<=')[0].split('>')[0].split('<')[0].strip()
                        if package:
                            deps.append(package)
                
                dependencies['pip'] = deps
            except:
                dependencies['pip'] = []
        
        return dependencies
    
    def _is_asset_file(self, filename: str) -> bool:
        """Check if file is an asset file (images, fonts, etc.)"""
        asset_extensions = {
            '.png', '.jpg', '.jpeg', '.gif', '.svg', '.ico', '.webp',
            '.mp3', '.mp4', '.avi', '.mov', '.wav', '.ogg',
            '.ttf', '.otf', '.woff', '.woff2',
            '.pdf', '.doc', '.docx', '.xls', '.xlsx'
        }
        
        file_ext = Path(filename).suffix.lower()
        return file_ext in asset_extensions
