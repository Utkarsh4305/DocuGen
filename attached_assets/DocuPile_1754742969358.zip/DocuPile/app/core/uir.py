"""
Universal Intermediate Representation (UIR) Generator
Converts parsed AST into language-agnostic intermediate format
"""

import json
import logging
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, asdict
from enum import Enum

logger = logging.getLogger(__name__)

class UIRNodeType(str, Enum):
    """UIR node types for different code constructs"""
    # Structure nodes
    MODULE = "module"
    CLASS = "class"
    FUNCTION = "function"
    INTERFACE = "interface"
    
    # Control flow
    IF_STATEMENT = "if_statement"
    LOOP = "loop"
    SWITCH = "switch"
    TRY_CATCH = "try_catch"
    
    # Data types
    VARIABLE = "variable"
    CONSTANT = "constant"
    ARRAY = "array"
    OBJECT = "object"
    
    # UI components (for frontend frameworks)
    COMPONENT = "component"
    ELEMENT = "element"
    STYLE = "style"
    EVENT_HANDLER = "event_handler"
    
    # API/Backend
    ROUTE = "route"
    MIDDLEWARE = "middleware"
    DATABASE_MODEL = "database_model"
    API_CALL = "api_call"
    
    # Expressions
    ASSIGNMENT = "assignment"
    BINARY_OP = "binary_op"
    UNARY_OP = "unary_op"
    FUNCTION_CALL = "function_call"
    
    # Imports/Dependencies
    IMPORT = "import"
    EXPORT = "export"

@dataclass
class UIRNode:
    """Universal Intermediate Representation node"""
    node_type: UIRNodeType
    identifier: Optional[str] = None
    value: Any = None
    properties: Dict[str, Any] = None
    children: List['UIRNode'] = None
    metadata: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.properties is None:
            self.properties = {}
        if self.children is None:
            self.children = []
        if self.metadata is None:
            self.metadata = {}
    
    def add_child(self, child: 'UIRNode'):
        """Add a child node"""
        self.children.append(child)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization"""
        result = {
            'node_type': self.node_type.value,
            'identifier': self.identifier,
            'value': self.value,
            'properties': self.properties,
            'children': [child.to_dict() for child in self.children],
            'metadata': self.metadata
        }
        return result
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'UIRNode':
        """Create UIRNode from dictionary"""
        children = [cls.from_dict(child) for child in data.get('children', [])]
        return cls(
            node_type=UIRNodeType(data['node_type']),
            identifier=data.get('identifier'),
            value=data.get('value'),
            properties=data.get('properties', {}),
            children=children,
            metadata=data.get('metadata', {})
        )

class UIRGenerator:
    """Generates UIR from parsed AST nodes"""
    
    def __init__(self):
        self.node_map = {}
        self.logger = logging.getLogger(__name__)
    
    def generate_from_ast(self, ast_nodes: List[Any], source_language: str) -> UIRNode:
        """Generate UIR from AST nodes"""
        try:
            root = UIRNode(UIRNodeType.MODULE, identifier="root")
            
            for node in ast_nodes:
                uir_node = self._convert_ast_node(node, source_language)
                if uir_node:
                    root.add_child(uir_node)
            
            self.logger.info(f"Generated UIR with {len(root.children)} top-level nodes")
            return root
            
        except Exception as e:
            self.logger.error(f"Error generating UIR: {str(e)}")
            raise
    
    def _convert_ast_node(self, ast_node: Any, language: str) -> Optional[UIRNode]:
        """Convert individual AST node to UIR"""
        try:
            # JavaScript/TypeScript AST conversion
            if language in ['javascript', 'typescript']:
                return self._convert_js_ast_node(ast_node)
            
            # Python AST conversion
            elif language == 'python':
                return self._convert_python_ast_node(ast_node)
            
            # Default fallback
            else:
                return self._convert_generic_ast_node(ast_node)
                
        except Exception as e:
            self.logger.warning(f"Failed to convert AST node: {str(e)}")
            return None
    
    def _convert_js_ast_node(self, node: Any) -> Optional[UIRNode]:
        """Convert JavaScript/TypeScript AST node"""
        node_type = getattr(node, 'type', None)
        
        if node_type == 'FunctionDeclaration':
            uir_node = UIRNode(
                UIRNodeType.FUNCTION,
                identifier=getattr(node, 'id', {}).get('name', 'anonymous'),
                properties={
                    'async': getattr(node, 'async', False),
                    'generator': getattr(node, 'generator', False),
                    'params': [p.get('name', '') for p in getattr(node, 'params', [])]
                }
            )
            
            # Convert function body
            body = getattr(node, 'body', {}).get('body', [])
            for stmt in body:
                child = self._convert_js_ast_node(stmt)
                if child:
                    uir_node.add_child(child)
            
            return uir_node
        
        elif node_type == 'VariableDeclaration':
            declarations = getattr(node, 'declarations', [])
            if declarations:
                decl = declarations[0]
                return UIRNode(
                    UIRNodeType.VARIABLE,
                    identifier=decl.get('id', {}).get('name', ''),
                    properties={
                        'kind': getattr(node, 'kind', 'var'),
                        'type': self._infer_js_type(decl.get('init'))
                    }
                )
        
        elif node_type == 'ClassDeclaration':
            return UIRNode(
                UIRNodeType.CLASS,
                identifier=getattr(node, 'id', {}).get('name', 'anonymous'),
                properties={
                    'superclass': getattr(node, 'superClass', {}).get('name', None) if getattr(node, 'superClass') else None
                }
            )
        
        elif node_type == 'ImportDeclaration':
            return UIRNode(
                UIRNodeType.IMPORT,
                value=getattr(node, 'source', {}).get('value', ''),
                properties={
                    'specifiers': [s.get('local', {}).get('name', '') for s in getattr(node, 'specifiers', [])]
                }
            )
        
        return None
    
    def _convert_python_ast_node(self, node: Any) -> Optional[UIRNode]:
        """Convert Python AST node"""
        import ast
        
        if isinstance(node, ast.FunctionDef):
            uir_node = UIRNode(
                UIRNodeType.FUNCTION,
                identifier=node.name,
                properties={
                    'async': isinstance(node, ast.AsyncFunctionDef),
                    'args': [arg.arg for arg in node.args.args],
                    'decorators': [d.id if hasattr(d, 'id') else str(d) for d in node.decorator_list]
                }
            )
            
            # Convert function body
            for stmt in node.body:
                child = self._convert_python_ast_node(stmt)
                if child:
                    uir_node.add_child(child)
            
            return uir_node
        
        elif isinstance(node, ast.ClassDef):
            return UIRNode(
                UIRNodeType.CLASS,
                identifier=node.name,
                properties={
                    'bases': [b.id if hasattr(b, 'id') else str(b) for b in node.bases],
                    'decorators': [d.id if hasattr(d, 'id') else str(d) for d in node.decorator_list]
                }
            )
        
        elif isinstance(node, ast.Assign):
            if node.targets and hasattr(node.targets[0], 'id'):
                return UIRNode(
                    UIRNodeType.VARIABLE,
                    identifier=node.targets[0].id,
                    properties={
                        'type': self._infer_python_type(node.value)
                    }
                )
        
        elif isinstance(node, ast.Import):
            return UIRNode(
                UIRNodeType.IMPORT,
                properties={
                    'modules': [alias.name for alias in node.names]
                }
            )
        
        elif isinstance(node, ast.ImportFrom):
            return UIRNode(
                UIRNodeType.IMPORT,
                value=node.module,
                properties={
                    'names': [alias.name for alias in node.names]
                }
            )
        
        return None
    
    def _convert_generic_ast_node(self, node: Any) -> Optional[UIRNode]:
        """Generic AST node conversion fallback"""
        return UIRNode(
            UIRNodeType.VARIABLE,
            identifier=str(node),
            properties={'raw': str(node)}
        )
    
    def _infer_js_type(self, init_node: Any) -> str:
        """Infer JavaScript variable type from initializer"""
        if not init_node:
            return 'undefined'
        
        node_type = init_node.get('type', '')
        if node_type == 'Literal':
            value = init_node.get('value')
            if isinstance(value, bool):
                return 'boolean'
            elif isinstance(value, (int, float)):
                return 'number'
            elif isinstance(value, str):
                return 'string'
        elif node_type == 'ArrayExpression':
            return 'array'
        elif node_type == 'ObjectExpression':
            return 'object'
        elif node_type == 'FunctionExpression':
            return 'function'
        
        return 'unknown'
    
    def _infer_python_type(self, node: Any) -> str:
        """Infer Python variable type from AST node"""
        import ast
        
        if isinstance(node, ast.Constant):
            value = node.value
            if isinstance(value, bool):
                return 'bool'
            elif isinstance(value, int):
                return 'int'
            elif isinstance(value, float):
                return 'float'
            elif isinstance(value, str):
                return 'str'
        elif isinstance(node, ast.List):
            return 'list'
        elif isinstance(node, ast.Dict):
            return 'dict'
        elif isinstance(node, ast.Call):
            if hasattr(node.func, 'id'):
                return node.func.id
        
        return 'Any'
    
    def save_uir(self, uir: UIRNode, filepath: str):
        """Save UIR to JSON file"""
        try:
            with open(filepath, 'w') as f:
                json.dump(uir.to_dict(), f, indent=2)
            self.logger.info(f"UIR saved to {filepath}")
        except Exception as e:
            self.logger.error(f"Failed to save UIR: {str(e)}")
            raise
    
    def load_uir(self, filepath: str) -> UIRNode:
        """Load UIR from JSON file"""
        try:
            with open(filepath, 'r') as f:
                data = json.load(f)
            uir = UIRNode.from_dict(data)
            self.logger.info(f"UIR loaded from {filepath}")
            return uir
        except Exception as e:
            self.logger.error(f"Failed to load UIR: {str(e)}")
            raise
