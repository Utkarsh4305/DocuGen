"""
Project analysis service
Analyzes uploaded projects and provides technology stack insights
"""

import os
import logging
from typing import Dict, List, Any, Tuple
from ..core.file_handler import FileHandler
from ..core.ast_parser import ASTParser
from ..core.uir import UIRGenerator
from ..models import TechStackAnalysis, LanguageStats, ProjectType

logger = logging.getLogger(__name__)

class ProjectAnalyzer:
    """Analyzes project structure and technology stack"""
    
    def __init__(self):
        self.file_handler = FileHandler()
        self.ast_parser = ASTParser()
        self.uir_generator = UIRGenerator()
        self.logger = logging.getLogger(__name__)
    
    def analyze_project(self, project_path: str) -> TechStackAnalysis:
        """Perform comprehensive project analysis"""
        try:
            self.logger.info(f"Starting project analysis for: {project_path}")
            
            # Get basic file structure analysis
            structure_analysis = self.file_handler.analyze_project_structure(project_path)
            
            # Convert to language statistics
            language_stats = []
            total_lines = structure_analysis['total_lines']
            
            for language, info in structure_analysis['languages'].items():
                percentage = (info['lines'] / total_lines * 100) if total_lines > 0 else 0
                
                lang_stat = LanguageStats(
                    language=language,
                    percentage=round(percentage, 2),
                    lines_of_code=info['lines'],
                    file_count=info['files']
                )
                language_stats.append(lang_stat)
            
            # Sort by percentage (highest first)
            language_stats.sort(key=lambda x: x.percentage, reverse=True)
            
            # Determine project type
            project_type = self._map_project_type(structure_analysis['project_type'])
            
            # Create comprehensive analysis
            analysis = TechStackAnalysis(
                languages=language_stats,
                frameworks=structure_analysis['frameworks'],
                dependencies=structure_analysis['dependencies'],
                project_type=project_type,
                total_lines=total_lines,
                total_files=structure_analysis['total_files']
            )
            
            self.logger.info(f"Project analysis completed: {len(language_stats)} languages detected")
            return analysis
            
        except Exception as e:
            self.logger.error(f"Project analysis failed: {str(e)}")
            raise
    
    def analyze_code_complexity(self, project_path: str) -> Dict[str, Any]:
        """Analyze code complexity and structure"""
        try:
            complexity_analysis = {
                'cyclomatic_complexity': {},
                'function_count': {},
                'class_count': {},
                'import_dependencies': {},
                'code_quality_metrics': {}
            }
            
            # Get source files for analysis
            source_files = self.file_handler.get_source_files(project_path)
            
            for file_info in source_files:
                language = file_info['language']
                file_path = file_info['path']
                
                # Parse AST for supported languages
                if language in ['python', 'javascript', 'typescript']:
                    ast_result = self.ast_parser.parse_content(file_info['content'], language)
                    
                    if ast_result:
                        metrics = self._extract_complexity_metrics(ast_result, language)
                        
                        if language not in complexity_analysis['function_count']:
                            complexity_analysis['function_count'][language] = 0
                            complexity_analysis['class_count'][language] = 0
                            complexity_analysis['import_dependencies'][language] = []
                        
                        complexity_analysis['function_count'][language] += metrics['functions']
                        complexity_analysis['class_count'][language] += metrics['classes']
                        complexity_analysis['import_dependencies'][language].extend(metrics['imports'])
            
            # Calculate aggregate metrics
            total_functions = sum(complexity_analysis['function_count'].values())
            total_classes = sum(complexity_analysis['class_count'].values())
            
            complexity_analysis['code_quality_metrics'] = {
                'total_functions': total_functions,
                'total_classes': total_classes,
                'avg_functions_per_file': total_functions / len(source_files) if source_files else 0,
                'complexity_score': self._calculate_complexity_score(complexity_analysis)
            }
            
            return complexity_analysis
            
        except Exception as e:
            self.logger.error(f"Code complexity analysis failed: {str(e)}")
            return {}
    
    def get_conversion_recommendations(self, analysis: TechStackAnalysis) -> List[Dict[str, str]]:
        """Get recommended conversion options based on project analysis"""
        try:
            recommendations = []
            
            # Determine primary language
            primary_language = analysis.languages[0].language if analysis.languages else None
            primary_frameworks = analysis.frameworks
            
            # React project recommendations
            if 'react' in primary_frameworks or primary_language == 'javascript':
                recommendations.extend([
                    {
                        'from': 'React (JavaScript)',
                        'to': 'React (TypeScript)',
                        'reason': 'Add type safety and better IDE support',
                        'difficulty': 'Easy',
                        'estimated_effort': 'Low'
                    },
                    {
                        'from': 'React',
                        'to': 'React Native',
                        'reason': 'Convert web app to mobile',
                        'difficulty': 'Medium',
                        'estimated_effort': 'Medium'
                    },
                    {
                        'from': 'React',
                        'to': 'Flutter',
                        'reason': 'Cross-platform mobile with better performance',
                        'difficulty': 'Hard',
                        'estimated_effort': 'High'
                    }
                ])
            
            # Python backend recommendations
            if primary_language == 'python' and any(f in primary_frameworks for f in ['flask', 'django', 'fastapi']):
                recommendations.extend([
                    {
                        'from': 'Python (Flask/Django)',
                        'to': 'Python (FastAPI)',
                        'reason': 'Modern async API with automatic documentation',
                        'difficulty': 'Medium',
                        'estimated_effort': 'Medium'
                    },
                    {
                        'from': 'Python',
                        'to': 'Node.js (Express)',
                        'reason': 'JavaScript ecosystem unification',
                        'difficulty': 'Hard',
                        'estimated_effort': 'High'
                    },
                    {
                        'from': 'Python',
                        'to': 'Go',
                        'reason': 'Better performance and concurrency',
                        'difficulty': 'Hard',
                        'estimated_effort': 'High'
                    }
                ])
            
            # Node.js recommendations
            if primary_language == 'javascript' and 'express' in primary_frameworks:
                recommendations.extend([
                    {
                        'from': 'Node.js (JavaScript)',
                        'to': 'Node.js (TypeScript)',
                        'reason': 'Add type safety to backend',
                        'difficulty': 'Easy',
                        'estimated_effort': 'Low'
                    },
                    {
                        'from': 'Node.js',
                        'to': 'Python (FastAPI)',
                        'reason': 'Better data science integration',
                        'difficulty': 'Medium',
                        'estimated_effort': 'Medium'
                    }
                ])
            
            # Mobile framework recommendations
            if 'flutter' in primary_frameworks:
                recommendations.append({
                    'from': 'Flutter',
                    'to': 'React Native',
                    'reason': 'Better web development integration',
                    'difficulty': 'Hard',
                    'estimated_effort': 'High'
                })
            
            if 'react-native' in primary_frameworks:
                recommendations.append({
                    'from': 'React Native',
                    'to': 'Flutter',
                    'reason': 'Better performance and single codebase',
                    'difficulty': 'Hard',
                    'estimated_effort': 'High'
                })
            
            # Database recommendations
            if 'sql' in [lang.language for lang in analysis.languages]:
                recommendations.append({
                    'from': 'SQL Database',
                    'to': 'NoSQL (MongoDB)',
                    'reason': 'Better scalability for document-based data',
                    'difficulty': 'Medium',
                    'estimated_effort': 'Medium'
                })
            
            return recommendations
            
        except Exception as e:
            self.logger.error(f"Failed to generate conversion recommendations: {str(e)}")
            return []
    
    def generate_uir_from_project(self, project_path: str, languages: List[str] = None) -> Dict[str, Any]:
        """Generate UIR representation from project files"""
        try:
            self.logger.info(f"Generating UIR from project: {project_path}")
            
            # Get source files
            source_files = self.file_handler.get_source_files(project_path, languages)
            
            project_uir = {
                'modules': [],
                'dependencies': [],
                'metadata': {
                    'total_files': len(source_files),
                    'languages': languages or [],
                    'generation_timestamp': None
                }
            }
            
            # Process each source file
            for file_info in source_files:
                language = file_info['language']
                
                # Parse AST
                ast_result = self.ast_parser.parse_content(file_info['content'], language)
                
                if ast_result:
                    # Generate UIR from AST
                    if language == 'python':
                        ast_nodes = ast_result.body if hasattr(ast_result, 'body') else [ast_result]
                    else:
                        ast_nodes = ast_result.get('body', []) if isinstance(ast_result, dict) else [ast_result]
                    
                    uir = self.uir_generator.generate_from_ast(ast_nodes, language)
                    
                    project_uir['modules'].append({
                        'file_path': file_info['path'],
                        'language': language,
                        'uir': uir.to_dict(),
                        'original_size': file_info['size'],
                        'lines': file_info['lines']
                    })
            
            import datetime
            project_uir['metadata']['generation_timestamp'] = datetime.datetime.now().isoformat()
            
            self.logger.info(f"UIR generation completed: {len(project_uir['modules'])} modules processed")
            return project_uir
            
        except Exception as e:
            self.logger.error(f"UIR generation failed: {str(e)}")
            raise
    
    def _map_project_type(self, detected_type: str) -> ProjectType:
        """Map detected project type to enum"""
        type_mapping = {
            'frontend': ProjectType.FRONTEND,
            'backend': ProjectType.BACKEND,
            'mobile': ProjectType.MOBILE,
            'database': ProjectType.DATABASE,
            'full_stack': ProjectType.FULL_STACK
        }
        return type_mapping.get(detected_type, ProjectType.FULL_STACK)
    
    def _extract_complexity_metrics(self, ast_result: Any, language: str) -> Dict[str, Any]:
        """Extract complexity metrics from AST"""
        metrics = {
            'functions': 0,
            'classes': 0,
            'imports': [],
            'complexity': 0
        }
        
        try:
            if language == 'python':
                import ast
                
                def count_nodes(node):
                    if isinstance(node, ast.FunctionDef):
                        metrics['functions'] += 1
                    elif isinstance(node, ast.ClassDef):
                        metrics['classes'] += 1
                    elif isinstance(node, (ast.Import, ast.ImportFrom)):
                        if isinstance(node, ast.ImportFrom) and node.module:
                            metrics['imports'].append(node.module)
                        elif isinstance(node, ast.Import):
                            for alias in node.names:
                                metrics['imports'].append(alias.name)
                    
                    for child in ast.iter_child_nodes(node):
                        count_nodes(child)
                
                if hasattr(ast_result, 'body'):
                    for node in ast_result.body:
                        count_nodes(node)
                else:
                    count_nodes(ast_result)
            
            elif language in ['javascript', 'typescript']:
                if isinstance(ast_result, dict):
                    body = ast_result.get('body', [])
                    for node in body:
                        if node.get('type') == 'FunctionDeclaration':
                            metrics['functions'] += 1
                        elif node.get('type') == 'ClassDeclaration':
                            metrics['classes'] += 1
                        elif node.get('type') == 'ImportDeclaration':
                            source = node.get('source', {}).get('value', '')
                            if source:
                                metrics['imports'].append(source)
            
        except Exception as e:
            self.logger.warning(f"Failed to extract metrics for {language}: {str(e)}")
        
        return metrics
    
    def _calculate_complexity_score(self, complexity_analysis: Dict[str, Any]) -> float:
        """Calculate overall complexity score"""
        try:
            total_functions = complexity_analysis['code_quality_metrics']['total_functions']
            total_classes = complexity_analysis['code_quality_metrics']['total_classes']
            
            # Simple complexity scoring algorithm
            base_score = min(total_functions * 0.1 + total_classes * 0.2, 10.0)
            
            # Adjust based on number of languages (more languages = more complexity)
            language_count = len(complexity_analysis['function_count'])
            language_penalty = language_count * 0.5
            
            final_score = min(base_score + language_penalty, 10.0)
            return round(final_score, 2)
            
        except:
            return 5.0  # Default medium complexity
