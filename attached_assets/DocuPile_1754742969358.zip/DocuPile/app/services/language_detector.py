"""
Language detection and categorization service
"""

import json
import logging
from typing import Dict, List, Any, Optional
from pathlib import Path

logger = logging.getLogger(__name__)

class LanguageDetector:
    """Language detection and categorization service"""
    
    def __init__(self, categories_file: str = "data/language_categories.json"):
        self.categories_file = categories_file
        self.logger = logging.getLogger(__name__)
        self.language_categories = self._load_language_categories()
    
    def _load_language_categories(self) -> Dict[str, Any]:
        """Load language categorization data"""
        try:
            with open(self.categories_file, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            self.logger.warning(f"Language categories file not found: {self.categories_file}")
            return self._get_default_categories()
        except Exception as e:
            self.logger.error(f"Failed to load language categories: {str(e)}")
            return self._get_default_categories()
    
    def _get_default_categories(self) -> Dict[str, Any]:
        """Get default language categories if file is not available"""
        return {
            "categories": {
                "frontend_web": {
                    "name": "Frontend Web Development",
                    "description": "Languages and frameworks for client-side web development",
                    "languages": ["javascript", "typescript", "html", "css"]
                },
                "backend_api": {
                    "name": "Backend/API Development", 
                    "description": "Server-side languages and frameworks",
                    "languages": ["python", "javascript", "java", "go", "rust", "csharp"]
                },
                "mobile": {
                    "name": "Mobile Development",
                    "description": "Native and cross-platform mobile app development",
                    "languages": ["kotlin", "swift", "dart", "javascript"]
                },
                "database": {
                    "name": "Database Languages",
                    "description": "Database query and management languages",
                    "languages": ["sql", "nosql"]
                }
            },
            "frameworks": {},
            "languages": {}
        }
    
    def get_language_info(self, language: str) -> Optional[Dict[str, Any]]:
        """Get detailed information about a programming language"""
        return self.language_categories.get('languages', {}).get(language)
    
    def get_framework_info(self, framework: str) -> Optional[Dict[str, Any]]:
        """Get detailed information about a framework"""
        return self.language_categories.get('frameworks', {}).get(framework)
    
    def categorize_languages(self, languages: List[str]) -> Dict[str, List[str]]:
        """Categorize a list of languages by their primary domain"""
        categorized = {}
        
        for category_id, category_info in self.language_categories.get('categories', {}).items():
            categorized[category_id] = []
            category_languages = category_info.get('languages', [])
            
            for language in languages:
                if language in category_languages:
                    categorized[category_id].append(language)
        
        return categorized
    
    def get_supported_conversions(self, source_languages: List[str], frameworks: List[str] = None) -> List[Dict[str, Any]]:
        """Get supported conversion options for given languages and frameworks"""
        conversions = []
        frameworks = frameworks or []
        
        # Define conversion matrix
        conversion_matrix = {
            # Frontend conversions
            ('javascript', 'react'): [
                ('typescript', 'react'),
                ('javascript', 'react-native'),
                ('dart', 'flutter'),
                ('kotlin', 'jetpack-compose')
            ],
            ('typescript', 'react'): [
                ('javascript', 'react'),
                ('dart', 'flutter'),
                ('kotlin', 'jetpack-compose'),
                ('swift', 'swiftui')
            ],
            
            # Backend conversions
            ('javascript', 'express'): [
                ('python', 'fastapi'),
                ('python', 'django'),
                ('go', 'gin'),
                ('typescript', 'express')
            ],
            ('python', 'django'): [
                ('python', 'fastapi'),
                ('javascript', 'express'),
                ('go', 'gin')
            ],
            ('python', 'fastapi'): [
                ('python', 'django'),
                ('javascript', 'express'),
                ('go', 'gin')
            ],
            
            # Mobile conversions
            ('dart', 'flutter'): [
                ('kotlin', 'jetpack-compose'),
                ('swift', 'swiftui'),
                ('javascript', 'react-native')
            ],
            ('kotlin', 'jetpack-compose'): [
                ('dart', 'flutter'),
                ('swift', 'swiftui'),
                ('javascript', 'react-native')
            ],
            ('swift', 'swiftui'): [
                ('dart', 'flutter'),
                ('kotlin', 'jetpack-compose'),
                ('javascript', 'react-native')
            ],
            
            # Database conversions
            ('sql', None): [
                ('nosql', 'mongodb')
            ],
            ('nosql', 'mongodb'): [
                ('sql', 'postgresql'),
                ('sql', 'mysql')
            ]
        }
        
        # Find applicable conversions
        for source_lang in source_languages:
            for framework in frameworks + [None]:
                source_key = (source_lang, framework)
                
                if source_key in conversion_matrix:
                    for target_lang, target_framework in conversion_matrix[source_key]:
                        conversion = {
                            'source': {
                                'language': source_lang,
                                'framework': framework
                            },
                            'target': {
                                'language': target_lang,
                                'framework': target_framework
                            },
                            'supported': True,
                            'difficulty': self._get_conversion_difficulty(source_key, (target_lang, target_framework)),
                            'features_preserved': self._get_preserved_features(source_key, (target_lang, target_framework))
                        }
                        conversions.append(conversion)
        
        return conversions
    
    def get_conversion_compatibility(self, source_lang: str, target_lang: str, source_framework: str = None, target_framework: str = None) -> Dict[str, Any]:
        """Get compatibility information for a specific conversion"""
        
        compatibility = {
            'compatible': False,
            'difficulty': 'Unknown',
            'estimated_effort': 'Unknown',
            'features_preserved': [],
            'features_lost': [],
            'additional_requirements': [],
            'notes': []
        }
        
        # Define compatibility rules
        compatibility_rules = {
            # JavaScript/TypeScript conversions
            ('javascript', 'typescript'): {
                'compatible': True,
                'difficulty': 'Easy',
                'estimated_effort': 'Low',
                'features_preserved': ['Logic', 'UI Structure', 'API Calls'],
                'features_lost': [],
                'additional_requirements': ['Type definitions'],
                'notes': ['Gradual migration possible', 'Excellent IDE support']
            },
            
            # React to React Native
            ('react', 'react-native'): {
                'compatible': True,
                'difficulty': 'Medium',
                'estimated_effort': 'Medium',
                'features_preserved': ['Component Logic', 'State Management', 'Navigation'],
                'features_lost': ['DOM APIs', 'CSS Styling'],
                'additional_requirements': ['Platform-specific components', 'Native modules setup'],
                'notes': ['UI components need replacement', 'Platform-specific features required']
            },
            
            # Python backend conversions
            ('python', 'javascript'): {
                'compatible': True,
                'difficulty': 'Hard',
                'estimated_effort': 'High',
                'features_preserved': ['API Structure', 'Business Logic'],
                'features_lost': ['Python-specific libraries', 'Type hints'],
                'additional_requirements': ['NPM equivalents for Python packages'],
                'notes': ['Async patterns may need adjustment', 'Different package ecosystem']
            }
        }
        
        # Check for direct match
        source_key = source_framework or source_lang
        target_key = target_framework or target_lang
        
        key = (source_key, target_key)
        if key in compatibility_rules:
            compatibility.update(compatibility_rules[key])
        else:
            # Generic compatibility assessment
            same_domain = self._same_domain(source_lang, target_lang)
            if same_domain:
                compatibility.update({
                    'compatible': True,
                    'difficulty': 'Medium',
                    'estimated_effort': 'Medium',
                    'features_preserved': ['Core Logic', 'Data Structures'],
                    'notes': ['Languages in same domain - conversion possible']
                })
            else:
                compatibility.update({
                    'compatible': False,
                    'difficulty': 'Very Hard',
                    'estimated_effort': 'Very High',
                    'notes': ['Cross-domain conversion - significant architecture changes needed']
                })
        
        return compatibility
    
    def _get_conversion_difficulty(self, source: tuple, target: tuple) -> str:
        """Determine conversion difficulty level"""
        source_lang, source_framework = source
        target_lang, target_framework = target
        
        # Same language, different framework
        if source_lang == target_lang:
            return 'Easy'
        
        # Similar languages (e.g., JavaScript -> TypeScript)
        similar_pairs = [
            ('javascript', 'typescript'),
            ('python', 'go'),  # Both used for backend
            ('kotlin', 'swift')  # Both mobile native
        ]
        
        if (source_lang, target_lang) in similar_pairs or (target_lang, source_lang) in similar_pairs:
            return 'Medium'
        
        # Cross-domain conversions
        return 'Hard'
    
    def _get_preserved_features(self, source: tuple, target: tuple) -> List[str]:
        """Get list of features that will be preserved in conversion"""
        features = []
        
        source_lang, source_framework = source
        target_lang, target_framework = target
        
        # Always preserve basic logic
        features.append('Basic Logic')
        
        # Same framework preserves more
        if source_framework == target_framework:
            features.extend(['Framework Features', 'Architecture Patterns'])
        
        # Same domain preserves domain-specific features
        if self._same_domain(source_lang, target_lang):
            features.append('Domain Patterns')
        
        return features
    
    def _same_domain(self, lang1: str, lang2: str) -> bool:
        """Check if two languages are in the same domain"""
        domains = {
            'web_frontend': ['javascript', 'typescript', 'html', 'css'],
            'backend': ['python', 'javascript', 'java', 'go', 'rust', 'csharp'],
            'mobile': ['kotlin', 'swift', 'dart', 'javascript'],
            'database': ['sql', 'nosql']
        }
        
        for domain_langs in domains.values():
            if lang1 in domain_langs and lang2 in domain_langs:
                return True
        
        return False
    
    def get_language_ecosystem_info(self, language: str) -> Dict[str, Any]:
        """Get ecosystem information for a language"""
        ecosystems = {
            'javascript': {
                'package_manager': 'npm/yarn',
                'testing_frameworks': ['Jest', 'Mocha', 'Cypress'],
                'build_tools': ['Webpack', 'Vite', 'Parcel'],
                'deployment_platforms': ['Netlify', 'Vercel', 'AWS'],
                'community_size': 'Very Large',
                'learning_curve': 'Easy to Medium'
            },
            'python': {
                'package_manager': 'pip/conda',
                'testing_frameworks': ['pytest', 'unittest', 'nose'],
                'build_tools': ['setuptools', 'poetry', 'pipenv'],
                'deployment_platforms': ['AWS', 'Heroku', 'DigitalOcean'],
                'community_size': 'Very Large',
                'learning_curve': 'Easy'
            },
            'typescript': {
                'package_manager': 'npm/yarn',
                'testing_frameworks': ['Jest', 'Mocha', 'Vitest'],
                'build_tools': ['TypeScript Compiler', 'Webpack', 'Vite'],
                'deployment_platforms': ['Netlify', 'Vercel', 'AWS'],
                'community_size': 'Large',
                'learning_curve': 'Medium'
            }
        }
        
        return ecosystems.get(language, {
            'package_manager': 'Unknown',
            'testing_frameworks': [],
            'build_tools': [],
            'deployment_platforms': [],
            'community_size': 'Unknown',
            'learning_curve': 'Unknown'
        })
