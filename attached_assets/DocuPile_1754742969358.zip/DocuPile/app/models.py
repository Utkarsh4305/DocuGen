"""
Pydantic models for API request/response validation
"""

from typing import List, Dict, Optional, Any
from pydantic import BaseModel, Field
from enum import Enum

class LanguageType(str, Enum):
    """Supported programming languages"""
    JAVASCRIPT = "javascript"
    TYPESCRIPT = "typescript"
    PYTHON = "python"
    GO = "go"
    JAVA = "java"
    KOTLIN = "kotlin"
    SWIFT = "swift"
    DART = "dart"
    SQL = "sql"
    NOSQL = "nosql"

class FrameworkType(str, Enum):
    """Supported frameworks"""
    REACT = "react"
    REACT_NATIVE = "react_native"
    FLUTTER = "flutter"
    JETPACK_COMPOSE = "jetpack_compose"
    SWIFTUI = "swiftui"
    NODE_EXPRESS = "node_express"
    FASTAPI = "fastapi"
    DJANGO = "django"
    GIN = "gin"

class ProjectType(str, Enum):
    """Project component types"""
    FRONTEND = "frontend"
    BACKEND = "backend"
    MOBILE = "mobile"
    DATABASE = "database"
    FULL_STACK = "full_stack"

class LanguageStats(BaseModel):
    """Language distribution statistics"""
    language: str
    percentage: float = Field(..., ge=0, le=100)
    lines_of_code: int = Field(..., ge=0)
    file_count: int = Field(..., ge=0)

class TechStackAnalysis(BaseModel):
    """Complete technology stack analysis"""
    languages: List[LanguageStats]
    frameworks: List[str]
    dependencies: Dict[str, List[str]]
    project_type: ProjectType
    total_lines: int
    total_files: int

class ConversionRequest(BaseModel):
    """Code conversion request"""
    project_id: str
    source_language: LanguageType
    target_language: LanguageType
    source_framework: Optional[FrameworkType] = None
    target_framework: Optional[FrameworkType] = None
    conversion_scope: List[ProjectType]
    preserve_structure: bool = True
    include_tests: bool = False

class ConversionResult(BaseModel):
    """Code conversion result"""
    success: bool
    project_id: str
    output_path: str
    conversion_log: List[str]
    errors: List[str]
    warnings: List[str]
    conversion_stats: Dict[str, Any]

class UIRNode(BaseModel):
    """Universal Intermediate Representation node"""
    node_type: str
    identifier: Optional[str] = None
    properties: Dict[str, Any] = {}
    children: List['UIRNode'] = []
    metadata: Dict[str, Any] = {}

# Enable forward references
UIRNode.model_rebuild()

class ProjectUploadResponse(BaseModel):
    """Project upload response"""
    project_id: str
    analysis: TechStackAnalysis
    supported_conversions: List[Dict[str, str]]
    upload_path: str

class ConversionProgress(BaseModel):
    """Conversion progress tracking"""
    project_id: str
    status: str
    progress_percentage: float = Field(..., ge=0, le=100)
    current_step: str
    estimated_time_remaining: Optional[int] = None
    errors: List[str] = []
