"""
Node.js Express to Python FastAPI converter
Specialized converter for migrating Express.js APIs to FastAPI
"""

import logging
import re
from typing import Dict, List, Any, Optional, Tuple
from ..core.uir import UIRNode, UIRNodeType
from ..models import ConversionRequest, ConversionResult

logger = logging.getLogger(__name__)

class NodeJsPythonConverter:
    """Converts Node.js Express projects to Python FastAPI"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        # HTTP method mappings
        self.http_methods = {
            'get': 'GET',
            'post': 'POST', 
            'put': 'PUT',
            'delete': 'DELETE',
            'patch': 'PATCH',
            'head': 'HEAD',
            'options': 'OPTIONS'
        }
        
        # Express to FastAPI middleware mappings
        self.middleware_mappings = {
            'express.json()': 'JSONResponse',
            'express.static()': 'StaticFiles',
            'cors()': 'CORSMiddleware',
            'helmet()': 'TrustedHostMiddleware',
            'rateLimit()': 'SlowAPIMiddleware'
        }
        
        # JavaScript to Python type mappings
        self.type_mappings = {
            'string': 'str',
            'number': 'Union[int, float]',
            'boolean': 'bool',
            'array': 'List[Any]',
            'object': 'Dict[str, Any]',
            'Date': 'datetime',
            'Buffer': 'bytes',
            'Promise': 'Awaitable',
            'any': 'Any',
            'null': 'Optional',
            'undefined': 'Optional'
        }
        
        # Common NPM to PyPI package mappings
        self.package_mappings = {
            'express': 'fastapi',
            'mongoose': 'motor',  # MongoDB async driver
            'jsonwebtoken': 'python-jose',
            'bcrypt': 'passlib',
            'nodemailer': 'sendgrid',
            'axios': 'httpx',
            'lodash': 'more-itertools',
            'moment': 'datetime',
            'uuid': 'uuid',
            'joi': 'pydantic',
            'dotenv': 'python-decouple'
        }
    
    def convert(self, uir: UIRNode, request: ConversionRequest) -> ConversionResult:
        """Convert Node.js Express UIR to Python FastAPI"""
        try:
            self.logger.info("Starting Node.js to Python FastAPI conversion")
            
            result = ConversionResult(
                success=False,
                project_id=request.project_id,
                output_path="",
                conversion_log=[],
                errors=[],
                warnings=[],
                conversion_stats={}
            )
            
            # Convert API routes
            converted_routes = []
            route_count = 0
            
            for child in uir.children:
                if child.node_type == UIRNodeType.ROUTE:
                    converted_route = self._convert_express_route(child)
                    if converted_route:
                        converted_routes.append(converted_route)
                        route_count += 1
                        result.conversion_log.append(f"Converted route: {child.identifier}")
            
            # Convert middleware
            converted_middleware = []
            middleware_count = 0
            
            for child in uir.children:
                if child.node_type == UIRNodeType.MIDDLEWARE:
                    converted_mid = self._convert_express_middleware(child)
                    if converted_mid:
                        converted_middleware.append(converted_mid)
                        middleware_count += 1
                        result.conversion_log.append(f"Converted middleware: {child.identifier}")
            
            # Convert database models
            converted_models = []
            model_count = 0
            
            for child in uir.children:
                if child.node_type == UIRNodeType.DATABASE_MODEL:
                    converted_model = self._convert_database_model(child)
                    if converted_model:
                        converted_models.append(converted_model)
                        model_count += 1
                        result.conversion_log.append(f"Converted model: {child.identifier}")
            
            # Convert utility functions
            converted_functions = []
            function_count = 0
            
            for child in uir.children:
                if child.node_type == UIRNodeType.FUNCTION:
                    converted_function = self._convert_function(child)
                    if converted_function:
                        converted_functions.append(converted_function)
                        function_count += 1
                        result.conversion_log.append(f"Converted function: {child.identifier}")
            
            # Generate FastAPI main application
            main_app = self._generate_fastapi_app(converted_routes, converted_middleware)
            
            # Generate Pydantic models
            pydantic_models = self._generate_pydantic_models(converted_models)
            
            # Generate requirements
            requirements = self._generate_requirements(uir)
            
            result.success = True
            result.conversion_stats = {
                'routes_converted': route_count,
                'middleware_converted': middleware_count,
                'models_converted': model_count,
                'functions_converted': function_count,
                'conversion_type': 'nodejs_to_python',
                'target_framework': 'fastapi'
            }
            
            if route_count == 0:
                result.warnings.append("No Express routes found to convert")
            
            self.logger.info(f"Node.js to Python conversion completed: {route_count} routes, {middleware_count} middleware")
            return result
            
        except Exception as e:
            self.logger.error(f"Node.js to Python conversion failed: {str(e)}")
            result.errors.append(str(e))
            return result
    
    def _convert_express_route(self, route_node: UIRNode) -> Optional[Dict[str, Any]]:
        """Convert Express route to FastAPI endpoint"""
        try:
            route_info = {
                'path': route_node.properties.get('path', '/'),
                'method': route_node.properties.get('method', 'GET').upper(),
                'function_name': route_node.identifier or 'endpoint',
                'parameters': [],
                'request_body': None,
                'response_model': None,
                'middleware': [],
                'python_code': ''
            }
            
            # Convert path parameters (Express :param to FastAPI {param})
            path = route_info['path']
            path = re.sub(r':(\w+)', r'{\1}', path)  # :id -> {id}
            route_info['path'] = path
            
            # Extract route parameters
            params = route_node.properties.get('parameters', [])
            route_info['parameters'] = self._convert_route_parameters(params, path)
            
            # Extract request body schema
            request_schema = route_node.properties.get('request_body')
            if request_schema:
                route_info['request_body'] = self._convert_request_body_schema(request_schema)
            
            # Extract response schema
            response_schema = route_node.properties.get('response')
            if response_schema:
                route_info['response_model'] = self._convert_response_schema(response_schema)
            
            # Convert middleware
            middleware = route_node.properties.get('middleware', [])
            route_info['middleware'] = [self._convert_middleware_call(m) for m in middleware]
            
            # Generate Python FastAPI code
            route_info['python_code'] = self._generate_fastapi_route(route_info)
            
            return route_info
            
        except Exception as e:
            self.logger.error(f"Failed to convert route {route_node.identifier}: {str(e)}")
            return None
    
    def _convert_express_middleware(self, middleware_node: UIRNode) -> Optional[Dict[str, Any]]:
        """Convert Express middleware to FastAPI middleware"""
        try:
            middleware_info = {
                'name': middleware_node.identifier,
                'type': 'custom',
                'parameters': [],
                'python_code': ''
            }
            
            # Determine middleware type
            middleware_type = middleware_node.properties.get('type', 'custom')
            if middleware_type in self.middleware_mappings:
                middleware_info['type'] = 'builtin'
                middleware_info['fastapi_equivalent'] = self.middleware_mappings[middleware_type]
            
            # Extract parameters
            params = middleware_node.properties.get('parameters', [])
            middleware_info['parameters'] = self._convert_middleware_parameters(params)
            
            # Generate Python middleware code
            middleware_info['python_code'] = self._generate_fastapi_middleware(middleware_info)
            
            return middleware_info
            
        except Exception as e:
            self.logger.error(f"Failed to convert middleware {middleware_node.identifier}: {str(e)}")
            return None
    
    def _convert_database_model(self, model_node: UIRNode) -> Optional[Dict[str, Any]]:
        """Convert Mongoose/Sequelize model to Pydantic model"""
        try:
            model_info = {
                'name': model_node.identifier,
                'fields': [],
                'methods': [],
                'python_code': ''
            }
            
            # Extract model fields
            fields = model_node.properties.get('fields', [])
            model_info['fields'] = self._convert_model_fields(fields)
            
            # Extract model methods
            methods = model_node.properties.get('methods', [])
            model_info['methods'] = self._convert_model_methods(methods)
            
            # Generate Pydantic model code
            model_info['python_code'] = self._generate_pydantic_model(model_info)
            
            return model_info
            
        except Exception as e:
            self.logger.error(f"Failed to convert model {model_node.identifier}: {str(e)}")
            return None
    
    def _convert_function(self, function_node: UIRNode) -> Optional[Dict[str, Any]]:
        """Convert JavaScript function to Python"""
        try:
            function_info = {
                'name': function_node.identifier,
                'parameters': [],
                'return_type': 'Any',
                'is_async': function_node.properties.get('async', False),
                'python_code': ''
            }
            
            # Convert parameters
            params = function_node.properties.get('parameters', [])
            function_info['parameters'] = self._convert_function_parameters(params)
            
            # Infer return type
            function_info['return_type'] = self._infer_python_return_type(function_node)
            
            # Generate Python function code
            function_info['python_code'] = self._generate_python_function(function_info)
            
            return function_info
            
        except Exception as e:
            self.logger.error(f"Failed to convert function {function_node.identifier}: {str(e)}")
            return None
    
    def _convert_route_parameters(self, params: List[Any], path: str) -> List[Dict[str, str]]:
        """Convert Express route parameters to FastAPI"""
        converted_params = []
        
        # Extract path parameters
        path_params = re.findall(r'\{(\w+)\}', path)
        for param in path_params:
            converted_params.append({
                'name': param,
                'type': 'str',
                'location': 'path',
                'required': True
            })
        
        # Convert query and body parameters
        for param in params:
            if isinstance(param, dict):
                param_info = {
                    'name': param.get('name', 'param'),
                    'type': self._convert_js_type_to_python(param.get('type', 'any')),
                    'location': param.get('location', 'query'),
                    'required': param.get('required', False)
                }
                converted_params.append(param_info)
        
        return converted_params
    
    def _convert_request_body_schema(self, schema: Dict[str, Any]) -> Dict[str, Any]:
        """Convert request body schema to Pydantic model"""
        return {
            'model_name': schema.get('name', 'RequestBody'),
            'fields': self._convert_schema_fields(schema.get('fields', []))
        }
    
    def _convert_response_schema(self, schema: Dict[str, Any]) -> Dict[str, Any]:
        """Convert response schema to Pydantic model"""
        return {
            'model_name': schema.get('name', 'ResponseBody'),
            'fields': self._convert_schema_fields(schema.get('fields', []))
        }
    
    def _convert_schema_fields(self, fields: List[Dict[str, Any]]) -> List[Dict[str, str]]:
        """Convert schema fields to Python types"""
        converted_fields = []
        
        for field in fields:
            field_info = {
                'name': field.get('name', 'field'),
                'type': self._convert_js_type_to_python(field.get('type', 'any')),
                'required': field.get('required', True),
                'description': field.get('description', '')
            }
            converted_fields.append(field_info)
        
        return converted_fields
    
    def _convert_middleware_call(self, middleware: str) -> Dict[str, str]:
        """Convert middleware call to FastAPI equivalent"""
        if middleware in self.middleware_mappings:
            return {
                'type': 'builtin',
                'name': self.middleware_mappings[middleware]
            }
        else:
            return {
                'type': 'custom',
                'name': middleware
            }
    
    def _convert_middleware_parameters(self, params: List[Any]) -> List[Dict[str, str]]:
        """Convert middleware parameters"""
        converted_params = []
        
        for param in params:
            if isinstance(param, dict):
                converted_params.append({
                    'name': param.get('name', 'param'),
                    'type': self._convert_js_type_to_python(param.get('type', 'any'))
                })
        
        return converted_params
    
    def _convert_model_fields(self, fields: List[Dict[str, Any]]) -> List[Dict[str, str]]:
        """Convert database model fields"""
        converted_fields = []
        
        for field in fields:
            field_info = {
                'name': field.get('name', 'field'),
                'type': self._convert_db_type_to_python(field.get('type', 'String')),
                'required': field.get('required', True),
                'default': field.get('default'),
                'description': field.get('description', '')
            }
            converted_fields.append(field_info)
        
        return converted_fields
    
    def _convert_model_methods(self, methods: List[Dict[str, Any]]) -> List[Dict[str, str]]:
        """Convert model methods"""
        converted_methods = []
        
        for method in methods:
            method_info = {
                'name': method.get('name', 'method'),
                'type': 'instance' if method.get('static', False) else 'static',
                'parameters': self._convert_function_parameters(method.get('parameters', [])),
                'return_type': self._convert_js_type_to_python(method.get('return_type', 'any'))
            }
            converted_methods.append(method_info)
        
        return converted_methods
    
    def _convert_function_parameters(self, params: List[Any]) -> List[Dict[str, str]]:
        """Convert function parameters to Python"""
        converted_params = []
        
        for param in params:
            if isinstance(param, dict):
                param_info = {
                    'name': param.get('name', 'param'),
                    'type': self._convert_js_type_to_python(param.get('type', 'any')),
                    'default': param.get('default')
                }
            elif isinstance(param, str):
                param_info = {
                    'name': param,
                    'type': 'Any',
                    'default': None
                }
            else:
                param_info = {
                    'name': str(param),
                    'type': 'Any',
                    'default': None
                }
            
            converted_params.append(param_info)
        
        return converted_params
    
    def _convert_js_type_to_python(self, js_type: str) -> str:
        """Convert JavaScript type to Python type"""
        return self.type_mappings.get(js_type.lower(), 'Any')
    
    def _convert_db_type_to_python(self, db_type: str) -> str:
        """Convert database type to Python type"""
        db_type_mappings = {
            'String': 'str',
            'Number': 'int',
            'Boolean': 'bool',
            'Date': 'datetime',
            'ObjectId': 'str',
            'Mixed': 'Any',
            'Buffer': 'bytes',
            'Array': 'List[Any]'
        }
        return db_type_mappings.get(db_type, 'Any')
    
    def _infer_python_return_type(self, function_node: UIRNode) -> str:
        """Infer Python return type from function"""
        function_name = function_node.identifier.lower()
        
        if 'get' in function_name or 'find' in function_name:
            return 'Dict[str, Any]'
        elif 'create' in function_name or 'save' in function_name:
            return 'Dict[str, Any]'
        elif 'delete' in function_name or 'remove' in function_name:
            return 'bool'
        elif 'update' in function_name:
            return 'Dict[str, Any]'
        elif 'validate' in function_name or 'check' in function_name:
            return 'bool'
        else:
            return 'Any'
    
    def _generate_fastapi_route(self, route_info: Dict[str, Any]) -> str:
        """Generate FastAPI route code"""
        method = route_info['method'].lower()
        path = route_info['path']
        function_name = route_info['function_name']
        parameters = route_info['parameters']
        request_body = route_info['request_body']
        
        # Generate function signature
        params = []
        imports = set(['FastAPI', 'HTTPException'])
        
        # Path parameters
        for param in parameters:
            if param['location'] == 'path':
                params.append(f"{param['name']}: {param['type']}")
        
        # Query parameters
        query_params = [p for p in parameters if p['location'] == 'query']
        if query_params:
            imports.add('Query')
            for param in query_params:
                default = " = None" if not param['required'] else ""
                params.append(f"{param['name']}: {param['type']}{default} = Query(...)")
        
        # Request body
        if request_body:
            imports.add('BaseModel')
            params.append(f"request_body: {request_body['model_name']}")
        
        param_str = ', '.join(params)
        
        # Generate decorator and function
        code = f"@app.{method}('{path}')\n"
        if route_info.get('response_model'):
            code += f"async def {function_name}({param_str}) -> {route_info['response_model']['model_name']}:\n"
        else:
            code += f"async def {function_name}({param_str}):\n"
        
        code += "    \"\"\"\n"
        code += f"    {method.upper()} {path}\n"
        code += "    Generated from Express.js route\n"
        code += "    \"\"\"\n"
        code += "    # Implementation needed\n"
        code += "    raise HTTPException(status_code=501, detail='Not implemented')\n"
        
        return code
    
    def _generate_fastapi_middleware(self, middleware_info: Dict[str, Any]) -> str:
        """Generate FastAPI middleware code"""
        name = middleware_info['name']
        
        if middleware_info['type'] == 'builtin':
            return f"# Use {middleware_info.get('fastapi_equivalent')} middleware\n"
        
        return f"""
@app.middleware("http")
async def {name}_middleware(request: Request, call_next):
    \"\"\"
    Generated middleware from Express.js
    \"\"\"
    # Implementation needed
    response = await call_next(request)
    return response
"""
    
    def _generate_pydantic_model(self, model_info: Dict[str, Any]) -> str:
        """Generate Pydantic model code"""
        name = model_info['name']
        fields = model_info['fields']
        
        code = f"class {name}(BaseModel):\n"
        code += f'    """{name} model generated from JavaScript"""\n'
        
        for field in fields:
            field_type = field['type']
            if not field['required']:
                field_type = f"Optional[{field_type}]"
            
            default = ""
            if field.get('default'):
                default = f" = {repr(field['default'])}"
            elif not field['required']:
                default = " = None"
            
            code += f"    {field['name']}: {field_type}{default}\n"
        
        return code
    
    def _generate_python_function(self, function_info: Dict[str, Any]) -> str:
        """Generate Python function code"""
        name = function_info['name']
        parameters = function_info['parameters']
        return_type = function_info['return_type']
        is_async = function_info['is_async']
        
        # Generate parameters
        params = []
        for param in parameters:
            param_str = f"{param['name']}: {param['type']}"
            if param.get('default'):
                param_str += f" = {repr(param['default'])}"
            params.append(param_str)
        
        param_str = ', '.join(params)
        
        # Generate function
        async_keyword = 'async ' if is_async else ''
        code = f"{async_keyword}def {name}({param_str}) -> {return_type}:\n"
        code += f'    """Generated function from JavaScript"""\n'
        code += "    # Implementation needed\n"
        code += "    pass\n"
        
        return code
    
    def _generate_fastapi_app(self, routes: List[Dict[str, Any]], middleware: List[Dict[str, Any]]) -> str:
        """Generate main FastAPI application code"""
        code = """from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List, Dict, Any, Union
import datetime

app = FastAPI(title="Generated API", description="Converted from Express.js")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

"""
        
        # Add generated routes
        for route in routes:
            code += "\n" + route['python_code'] + "\n"
        
        # Add middleware
        for mid in middleware:
            code += "\n" + mid['python_code'] + "\n"
        
        code += """
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
"""
        
        return code
    
    def _generate_pydantic_models(self, models: List[Dict[str, Any]]) -> str:
        """Generate all Pydantic models"""
        if not models:
            return ""
        
        code = "from pydantic import BaseModel\nfrom typing import Optional\nimport datetime\n\n"
        
        for model in models:
            code += model['python_code'] + "\n\n"
        
        return code
    
    def _generate_requirements(self, uir: UIRNode) -> List[str]:
        """Generate Python requirements from Node.js dependencies"""
        requirements = ['fastapi>=0.68.0', 'uvicorn>=0.15.0', 'pydantic>=1.8.0']
        
        # Extract dependencies from UIR
        for child in uir.children:
            if child.node_type == UIRNodeType.IMPORT:
                import_name = child.value or child.identifier
                if import_name in self.package_mappings:
                    python_package = self.package_mappings[import_name]
                    if python_package not in [r.split('>=')[0] for r in requirements]:
                        requirements.append(python_package)
        
        return requirements
