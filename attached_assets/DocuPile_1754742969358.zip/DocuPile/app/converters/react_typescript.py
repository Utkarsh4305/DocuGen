"""
React to TypeScript converter
Specialized converter for React JavaScript to TypeScript migration
"""

import logging
from typing import Dict, List, Any, Optional
from ..core.uir import UIRNode, UIRNodeType
from ..models import ConversionRequest, ConversionResult

logger = logging.getLogger(__name__)

class ReactTypeScriptConverter:
    """Converts React JavaScript projects to TypeScript"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        # Type inference rules for common patterns
        self.type_inference_rules = {
            'useState': self._infer_state_type,
            'useEffect': 'void',
            'useContext': self._infer_context_type,
            'useCallback': self._infer_callback_type,
            'useMemo': self._infer_memo_type,
            'useRef': self._infer_ref_type
        }
        
        # Common prop type mappings
        self.prop_type_mappings = {
            'string': 'string',
            'number': 'number',
            'boolean': 'boolean',
            'array': 'Array<any>',
            'object': 'Record<string, any>',
            'function': 'Function',
            'node': 'React.ReactNode',
            'element': 'React.ReactElement'
        }
    
    def convert(self, uir: UIRNode, request: ConversionRequest) -> ConversionResult:
        """Convert React JavaScript UIR to TypeScript"""
        try:
            self.logger.info("Starting React to TypeScript conversion")
            
            result = ConversionResult(
                success=False,
                project_id=request.project_id,
                output_path="",
                conversion_log=[],
                errors=[],
                warnings=[],
                conversion_stats={}
            )
            
            # Convert components
            converted_components = []
            component_count = 0
            
            for child in uir.children:
                if child.node_type == UIRNodeType.COMPONENT:
                    converted_component = self._convert_react_component(child)
                    if converted_component:
                        converted_components.append(converted_component)
                        component_count += 1
                        result.conversion_log.append(f"Converted component: {child.identifier}")
            
            # Convert utility functions
            converted_functions = []
            function_count = 0
            
            for child in uir.children:
                if child.node_type == UIRNodeType.FUNCTION:
                    converted_function = self._convert_function(child)
                    if converted_function:
                        converted_functions.append(converted_function)
                        function_count += 1
                        result.conversion_log.append(f"Converted function: {child.identifier}")
            
            # Generate TypeScript interfaces for props
            interfaces = self._generate_prop_interfaces(converted_components)
            
            result.success = True
            result.conversion_stats = {
                'components_converted': component_count,
                'functions_converted': function_count,
                'interfaces_generated': len(interfaces),
                'conversion_type': 'react_to_typescript'
            }
            
            self.logger.info(f"React to TypeScript conversion completed: {component_count} components, {function_count} functions")
            return result
            
        except Exception as e:
            self.logger.error(f"React to TypeScript conversion failed: {str(e)}")
            result.errors.append(str(e))
            return result
    
    def _convert_react_component(self, component_node: UIRNode) -> Optional[Dict[str, Any]]:
        """Convert a React component node to TypeScript"""
        try:
            component_info = {
                'name': component_node.identifier,
                'type': 'functional',  # Assume functional components
                'props': [],
                'state': [],
                'hooks': [],
                'methods': [],
                'typescript_code': ''
            }
            
            # Extract component properties
            props = component_node.properties.get('props', [])
            component_info['props'] = self._convert_props_to_typescript(props)
            
            # Extract state usage (from useState hooks)
            state_hooks = component_node.properties.get('state', [])
            component_info['state'] = self._convert_state_to_typescript(state_hooks)
            
            # Extract other hooks
            hooks = component_node.properties.get('hooks', [])
            component_info['hooks'] = self._convert_hooks_to_typescript(hooks)
            
            # Extract methods
            methods = component_node.properties.get('methods', [])
            component_info['methods'] = self._convert_methods_to_typescript(methods)
            
            # Generate TypeScript component code
            component_info['typescript_code'] = self._generate_typescript_component(component_info)
            
            return component_info
            
        except Exception as e:
            self.logger.error(f"Failed to convert component {component_node.identifier}: {str(e)}")
            return None
    
    def _convert_function(self, function_node: UIRNode) -> Optional[Dict[str, Any]]:
        """Convert a JavaScript function to TypeScript"""
        try:
            function_info = {
                'name': function_node.identifier,
                'parameters': [],
                'return_type': 'any',
                'typescript_code': ''
            }
            
            # Extract parameter information
            params = function_node.properties.get('parameters', [])
            function_info['parameters'] = self._infer_parameter_types(params)
            
            # Infer return type
            function_info['return_type'] = self._infer_return_type(function_node)
            
            # Generate TypeScript function code
            function_info['typescript_code'] = self._generate_typescript_function(function_info)
            
            return function_info
            
        except Exception as e:
            self.logger.error(f"Failed to convert function {function_node.identifier}: {str(e)}")
            return None
    
    def _convert_props_to_typescript(self, props: List[Any]) -> List[Dict[str, str]]:
        """Convert React props to TypeScript interface properties"""
        typescript_props = []
        
        for prop in props:
            if isinstance(prop, dict):
                prop_name = prop.get('name', 'unknown')
                prop_type = prop.get('type', 'any')
                required = prop.get('required', True)
                
                # Map JavaScript types to TypeScript
                ts_type = self.prop_type_mappings.get(prop_type, prop_type)
                
                typescript_props.append({
                    'name': prop_name,
                    'type': ts_type,
                    'optional': not required,
                    'description': prop.get('description', '')
                })
        
        return typescript_props
    
    def _convert_state_to_typescript(self, state_hooks: List[Any]) -> List[Dict[str, str]]:
        """Convert useState hooks to TypeScript"""
        typescript_state = []
        
        for state in state_hooks:
            if isinstance(state, dict):
                state_name = state.get('name', 'state')
                initial_value = state.get('initial_value')
                
                # Infer type from initial value
                state_type = self._infer_type_from_value(initial_value)
                
                typescript_state.append({
                    'name': state_name,
                    'type': state_type,
                    'setter': f"set{state_name.capitalize()}"
                })
        
        return typescript_state
    
    def _convert_hooks_to_typescript(self, hooks: List[Any]) -> List[Dict[str, str]]:
        """Convert React hooks to TypeScript"""
        typescript_hooks = []
        
        for hook in hooks:
            if isinstance(hook, dict):
                hook_name = hook.get('name', '')
                hook_type = hook.get('type', '')
                
                if hook_name in self.type_inference_rules:
                    inferred_type = self.type_inference_rules[hook_name]
                    if callable(inferred_type):
                        inferred_type = inferred_type(hook)
                    
                    typescript_hooks.append({
                        'name': hook_name,
                        'type': inferred_type,
                        'dependencies': hook.get('dependencies', [])
                    })
        
        return typescript_hooks
    
    def _convert_methods_to_typescript(self, methods: List[Any]) -> List[Dict[str, str]]:
        """Convert component methods to TypeScript"""
        typescript_methods = []
        
        for method in methods:
            if isinstance(method, dict):
                method_name = method.get('name', '')
                parameters = method.get('parameters', [])
                return_type = self._infer_return_type_from_method(method)
                
                ts_params = []
                for param in parameters:
                    param_type = self._infer_parameter_type(param)
                    ts_params.append({
                        'name': param.get('name', 'param'),
                        'type': param_type
                    })
                
                typescript_methods.append({
                    'name': method_name,
                    'parameters': ts_params,
                    'return_type': return_type
                })
        
        return typescript_methods
    
    def _generate_prop_interfaces(self, components: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Generate TypeScript interfaces for component props"""
        interfaces = []
        
        for component in components:
            if component['props']:
                interface_name = f"{component['name']}Props"
                
                interface_def = {
                    'name': interface_name,
                    'properties': component['props']
                }
                
                interfaces.append(interface_def)
        
        return interfaces
    
    def _generate_typescript_component(self, component_info: Dict[str, Any]) -> str:
        """Generate TypeScript code for React component"""
        name = component_info['name']
        props = component_info['props']
        state = component_info['state']
        hooks = component_info['hooks']
        methods = component_info['methods']
        
        # Generate imports
        imports = ["import React"]
        if state:
            imports.append("{ useState }")
        if any(hook['name'] == 'useEffect' for hook in hooks):
            imports.append("{ useEffect }")
        
        import_statement = f"import {', '.join(imports)} from 'react';\n\n"
        
        # Generate props interface
        props_interface = ""
        if props:
            props_interface = f"interface {name}Props {{\n"
            for prop in props:
                optional = "?" if prop['optional'] else ""
                props_interface += f"  {prop['name']}{optional}: {prop['type']};\n"
            props_interface += "}\n\n"
        
        # Generate component
        component_code = f"const {name}: React.FC"
        if props:
            component_code += f"<{name}Props>"
        component_code += f" = ({{{', '.join([p['name'] for p in props])}}}) => {{\n"
        
        # Add state declarations
        for state_item in state:
            component_code += f"  const [{state_item['name']}, {state_item['setter']}] = useState<{state_item['type']}>();\n"
        
        # Add methods
        for method in methods:
            params = ', '.join([f"{p['name']}: {p['type']}" for p in method['parameters']])
            component_code += f"\n  const {method['name']} = ({params}): {method['return_type']} => {{\n"
            component_code += "    // Implementation needed\n"
            component_code += "  };\n"
        
        component_code += "\n  return (\n    <div>\n      {/* Component JSX */}\n    </div>\n  );\n};\n\n"
        component_code += f"export default {name};"
        
        return import_statement + props_interface + component_code
    
    def _generate_typescript_function(self, function_info: Dict[str, Any]) -> str:
        """Generate TypeScript code for a function"""
        name = function_info['name']
        parameters = function_info['parameters']
        return_type = function_info['return_type']
        
        param_strings = []
        for param in parameters:
            param_strings.append(f"{param['name']}: {param['type']}")
        
        params = ', '.join(param_strings)
        
        return f"export const {name} = ({params}): {return_type} => {{\n  // Implementation needed\n}};"
    
    def _infer_state_type(self, hook_info: Dict[str, Any]) -> str:
        """Infer useState type from usage"""
        initial_value = hook_info.get('initial_value')
        return self._infer_type_from_value(initial_value)
    
    def _infer_context_type(self, hook_info: Dict[str, Any]) -> str:
        """Infer useContext type"""
        context_name = hook_info.get('context', 'unknown')
        return f"{context_name}Type"
    
    def _infer_callback_type(self, hook_info: Dict[str, Any]) -> str:
        """Infer useCallback type"""
        return "(...args: any[]) => any"
    
    def _infer_memo_type(self, hook_info: Dict[str, Any]) -> str:
        """Infer useMemo type"""
        return "any"
    
    def _infer_ref_type(self, hook_info: Dict[str, Any]) -> str:
        """Infer useRef type"""
        element_type = hook_info.get('element_type', 'HTMLElement')
        return f"React.RefObject<{element_type}>"
    
    def _infer_type_from_value(self, value: Any) -> str:
        """Infer TypeScript type from JavaScript value"""
        if value is None:
            return "any"
        elif isinstance(value, bool):
            return "boolean"
        elif isinstance(value, int):
            return "number"
        elif isinstance(value, float):
            return "number"
        elif isinstance(value, str):
            return "string"
        elif isinstance(value, list):
            return "any[]"
        elif isinstance(value, dict):
            return "Record<string, any>"
        else:
            return "any"
    
    def _infer_parameter_types(self, params: List[Any]) -> List[Dict[str, str]]:
        """Infer parameter types for function"""
        typed_params = []
        
        for param in params:
            if isinstance(param, dict):
                param_name = param.get('name', 'param')
                param_type = param.get('type', 'any')
            elif isinstance(param, str):
                param_name = param
                param_type = 'any'
            else:
                param_name = str(param)
                param_type = 'any'
            
            typed_params.append({
                'name': param_name,
                'type': param_type
            })
        
        return typed_params
    
    def _infer_parameter_type(self, param: Any) -> str:
        """Infer type for a single parameter"""
        if isinstance(param, dict):
            return param.get('type', 'any')
        else:
            return 'any'
    
    def _infer_return_type(self, function_node: UIRNode) -> str:
        """Infer function return type"""
        # Simple heuristics for return type inference
        return_hints = function_node.properties.get('return_hints', [])
        
        if 'jsx' in return_hints or 'component' in return_hints:
            return 'React.ReactElement'
        elif 'promise' in return_hints or 'async' in return_hints:
            return 'Promise<any>'
        elif 'void' in return_hints:
            return 'void'
        else:
            return 'any'
    
    def _infer_return_type_from_method(self, method: Dict[str, Any]) -> str:
        """Infer return type for a method"""
        method_name = method.get('name', '').lower()
        
        if 'handle' in method_name or 'on' in method_name:
            return 'void'
        elif 'get' in method_name or 'fetch' in method_name:
            return 'Promise<any>'
        elif 'is' in method_name or 'has' in method_name:
            return 'boolean'
        else:
            return 'any'
