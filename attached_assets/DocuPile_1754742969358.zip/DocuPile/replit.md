# Universal Code Transpiler

## Overview

A production-ready AST-based code transpilation system designed for cross-language project migration. The application enables users to upload complete project folders (React frontend + Python backend + Firebase, etc.) and selectively migrate components between different programming languages and frameworks while preserving functionality, UI, logic, state management, and API integrations.

The system supports bidirectional conversions between popular tech stacks including React ↔ React Native ↔ Flutter ↔ Kotlin (Jetpack Compose) ↔ SwiftUI for frontend/mobile, and Node.js ↔ Python ↔ Go for backend services, with SQL ↔ NoSQL database migration capabilities.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Backend Architecture
**FastAPI Framework**: Core API built with FastAPI providing RESTful endpoints for project upload, analysis, conversion, and download operations. Includes comprehensive CORS middleware, static file serving, and structured API documentation at `/api/docs`.

**Universal Intermediate Representation (UIR)**: Central abstraction layer that converts parsed AST into language-agnostic intermediate format. This allows decoupling of source language parsing from target language generation, enabling extensible conversion support.

**Multi-Language AST Parser**: Supports parsing of Python, JavaScript, TypeScript, Java, Go, and SQL source files into Abstract Syntax Trees using language-specific parsers.

**Template-Based Code Generation**: Uses Jinja2 templating engine for generating target language code from UIR, with language-specific templates for functions, classes, components, and frameworks.

**Modular Converter Architecture**: Specialized converter classes for specific language pairs (ReactTypeScriptConverter, NodeJsPythonConverter) with extensible design for adding new conversion paths.

### Frontend Architecture
**Static HTML/CSS/JavaScript**: Traditional web frontend using Tailwind CSS for styling, Chart.js for language statistics visualization, and vanilla JavaScript for interactive functionality.

**File Upload System**: Drag-and-drop interface with support for project folders and ZIP archives, including real-time upload progress tracking.

**Project Analysis Dashboard**: Visual representation of detected languages, frameworks, file statistics, and technology stack composition with percentage breakdowns.

**Conversion Configuration Interface**: UI for selecting target languages/frameworks and configuring conversion parameters with real-time validation.

### File Processing System
**Multi-Format Support**: Handles various project structures including ZIP archives, individual files, and folder hierarchies with intelligent file type detection.

**Language Detection Engine**: Analyzes file extensions, content patterns, and configuration files to identify programming languages, frameworks, and project types with categorization into frontend, backend, mobile, and database components.

**Project Structure Analysis**: Provides comprehensive statistics including lines of code, file counts, language distribution, and framework detection across the entire project.

### Core Processing Pipeline
**Three-Stage Transpilation**: 
1. **Parse**: Convert source code to AST using language-specific parsers
2. **Transform**: Generate UIR from AST maintaining semantic meaning
3. **Generate**: Produce target language code from UIR using templates

**Background Processing**: Asynchronous conversion processing with progress tracking and status updates for long-running transpilation tasks.

**Error Handling and Logging**: Comprehensive error handling with detailed logging throughout the conversion pipeline for debugging and monitoring.

## External Dependencies

**FastAPI Framework**: Web framework for building the REST API with automatic OpenAPI documentation generation.

**Pydantic**: Data validation and serialization for API request/response models with type safety.

**Jinja2**: Template engine for generating target language code from UIR with flexible template inheritance.

**Chart.js**: JavaScript charting library for visualizing language statistics and project composition in the frontend.

**Tailwind CSS**: Utility-first CSS framework for responsive and modern UI design.

**Font Awesome**: Icon library for consistent iconography throughout the application interface.

**Python Standard Libraries**: 
- `ast` for Python AST parsing
- `json` for configuration and data processing
- `pathlib` for cross-platform file path handling
- `tempfile` for secure temporary file operations
- `zipfile` for archive processing
- `logging` for application monitoring

**Uvicorn**: ASGI server for running the FastAPI application in production with high performance and scalability.

Note: The application uses in-memory storage for conversion progress tracking, which should be replaced with Redis or database persistence in production environments for scalability and reliability.