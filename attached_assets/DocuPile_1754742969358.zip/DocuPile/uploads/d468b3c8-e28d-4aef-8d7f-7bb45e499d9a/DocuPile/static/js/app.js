class UniversalCodeTranspiler {
    constructor() {
        this.currentProjectId = null;
        this.analysisData = null;
        this.conversionPollingInterval = null;
        this.supportedLanguages = [];
        this.supportedFrameworks = [];
        
        this.initializeEventListeners();
        this.loadSupportedLanguages();
        this.checkHealth();
    }

    // Initialize all event listeners
    initializeEventListeners() {
        // File upload events
        const dropzone = document.getElementById('dropzone');
        const fileInput = document.getElementById('file-input');
        const uploadButton = document.getElementById('upload-button');

        // Dropzone events
        dropzone.addEventListener('click', () => fileInput.click());
        dropzone.addEventListener('dragover', this.handleDragOver.bind(this));
        dropzone.addEventListener('drop', this.handleFileDrop.bind(this));
        
        // File input change
        fileInput.addEventListener('change', this.handleFileSelect.bind(this));
        
        // Upload button
        uploadButton.addEventListener('click', this.uploadProject.bind(this));

        // Conversion events
        const startConversionButton = document.getElementById('start-conversion');
        const downloadButton = document.getElementById('download-button');
        const retryButton = document.getElementById('retry-button');

        startConversionButton.addEventListener('click', this.startConversion.bind(this));
        downloadButton.addEventListener('click', this.downloadProject.bind(this));
        retryButton.addEventListener('click', this.resetApplication.bind(this));

        // Language/framework selection events
        document.getElementById('target-language').addEventListener('change', this.handleTargetLanguageChange.bind(this));
    }

    // Check API health
    async checkHealth() {
        try {
            const response = await fetch('/api/health');
            const health = await response.json();
            
            const indicator = document.getElementById('health-indicator');
            if (health.status === 'healthy') {
                indicator.className = 'w-3 h-3 bg-green-400 rounded-full';
            } else {
                indicator.className = 'w-3 h-3 bg-red-400 rounded-full';
            }
        } catch (error) {
            console.error('Health check failed:', error);
            document.getElementById('health-indicator').className = 'w-3 h-3 bg-red-400 rounded-full';
        }
    }

    // Load supported languages and frameworks
    async loadSupportedLanguages() {
        try {
            const response = await fetch('/api/languages');
            const data = await response.json();
            
            this.supportedLanguages = data.languages || [];
            this.supportedFrameworks = data.frameworks || [];
            
            this.populateLanguageSelects();
        } catch (error) {
            console.error('Failed to load supported languages:', error);
            this.showError('Failed to load supported languages and frameworks');
        }
    }

    // Populate language select elements
    populateLanguageSelects() {
        const sourceLanguageSelect = document.getElementById('source-language');
        const targetLanguageSelect = document.getElementById('target-language');
        
        // Populate target language options
        this.supportedLanguages.forEach(language => {
            const option = document.createElement('option');
            option.value = language;
            option.textContent = language.charAt(0).toUpperCase() + language.slice(1);
            targetLanguageSelect.appendChild(option);
        });
    }

    // Handle drag over event
    handleDragOver(event) {
        event.preventDefault();
        event.dataTransfer.dropEffect = 'copy';
        event.currentTarget.classList.add('border-indigo-500', 'bg-indigo-50');
    }

    // Handle file drop event
    handleFileDrop(event) {
        event.preventDefault();
        const dropzone = event.currentTarget;
        dropzone.classList.remove('border-indigo-500', 'bg-indigo-50');
        
        const files = Array.from(event.dataTransfer.files);
        this.handleFiles(files);
    }

    // Handle file selection
    handleFileSelect(event) {
        const files = Array.from(event.target.files);
        this.handleFiles(files);
    }

    // Handle selected files
    handleFiles(files) {
        if (files.length === 0) return;

        // Update UI to show selected files
        const dropzone = document.getElementById('dropzone');
        const fileList = files.map(f => f.name).join(', ');
        
        dropzone.innerHTML = `
            <div class="space-y-4">
                <div class="text-4xl text-green-500">
                    <i class="fas fa-check-circle"></i>
                </div>
                <div>
                    <p class="text-xl text-gray-700 font-medium">Files Selected</p>
                    <p class="text-gray-500 truncate">${fileList}</p>
                </div>
                <div class="text-sm text-gray-400">
                    ${files.length} file(s) - Click "Analyze Project" to continue
                </div>
            </div>
        `;

        // Enable upload button
        document.getElementById('upload-button').disabled = false;
        
        // Store files for upload
        this.selectedFiles = files;
    }

    // Upload and analyze project
    async uploadProject() {
        if (!this.selectedFiles || this.selectedFiles.length === 0) {
            this.showError('Please select files to upload');
            return;
        }

        this.showLoading(true);
        
        try {
            const formData = new FormData();
            
            // For multiple files, create a zip or handle appropriately
            if (this.selectedFiles.length === 1) {
                formData.append('file', this.selectedFiles[0]);
            } else {
                // For multiple files, we'll send the first one for now
                // In production, you'd want to create a zip file
                formData.append('file', this.selectedFiles[0]);
            }

            const response = await fetch('/api/upload', {
                method: 'POST',
                body: formData
            });

            if (!response.ok) {
                throw new Error(`Upload failed: ${response.statusText}`);
            }

            const result = await response.json();
            this.currentProjectId = result.project_id;
            this.analysisData = result.analysis;
            
            this.displayAnalysis(result);
            this.showConversionOptions(result.supported_conversions);
            
            // Hide upload section and show analysis
            document.getElementById('upload-section').classList.add('hidden');
            document.getElementById('analysis-section').classList.remove('hidden');
            document.getElementById('conversion-section').classList.remove('hidden');
            
        } catch (error) {
            console.error('Upload failed:', error);
            this.showError(`Upload failed: ${error.message}`);
        } finally {
            this.showLoading(false);
        }
    }

    // Display project analysis results
    displayAnalysis(analysisResult) {
        const analysis = analysisResult.analysis;
        
        // Display project stats
        const statsContainer = document.getElementById('project-stats');
        statsContainer.innerHTML = `
            <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <span class="text-gray-700">Total Files</span>
                <span class="font-semibold text-gray-900">${analysis.total_files}</span>
            </div>
            <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <span class="text-gray-700">Lines of Code</span>
                <span class="font-semibold text-gray-900">${analysis.total_lines.toLocaleString()}</span>
            </div>
            <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <span class="text-gray-700">Project Type</span>
                <span class="font-semibold text-gray-900 capitalize">${analysis.project_type.replace('_', ' ')}</span>
            </div>
            <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <span class="text-gray-700">Languages Detected</span>
                <span class="font-semibold text-gray-900">${analysis.languages.length}</span>
            </div>
        `;

        // Display language distribution chart
        this.createLanguageChart(analysis.languages);

        // Display technology stack
        this.displayTechnologyStack(analysis.frameworks);

        // Display dependencies
        this.displayDependencies(analysis.dependencies);
    }

    // Create language distribution pie chart
    createLanguageChart(languages) {
        const ctx = document.getElementById('language-chart').getContext('2d');
        
        const colors = [
            '#3B82F6', '#EF4444', '#10B981', '#F59E0B', 
            '#8B5CF6', '#06B6D4', '#84CC16', '#F97316'
        ];

        new Chart(ctx, {
            type: 'pie',
            data: {
                labels: languages.map(lang => lang.language.charAt(0).toUpperCase() + lang.language.slice(1)),
                datasets: [{
                    data: languages.map(lang => lang.percentage),
                    backgroundColor: colors.slice(0, languages.length),
                    borderWidth: 2,
                    borderColor: '#ffffff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            usePointStyle: true
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return `${context.label}: ${context.parsed.toFixed(1)}%`;
                            }
                        }
                    }
                }
            }
        });
    }

    // Display technology stack
    displayTechnologyStack(frameworks) {
        const stackContainer = document.getElementById('tech-stack');
        
        if (frameworks.length === 0) {
            stackContainer.innerHTML = '<p class="text-gray-500 text-center py-4">No frameworks detected</p>';
            return;
        }

        const frameworkIcons = {
            'react': 'fab fa-react text-blue-500',
            'vue': 'fab fa-vuejs text-green-500',
            'angular': 'fab fa-angular text-red-500',
            'express': 'fab fa-node-js text-green-600',
            'django': 'fab fa-python text-blue-600',
            'flask': 'fab fa-python text-blue-600',
            'fastapi': 'fab fa-python text-green-600',
            'spring': 'fab fa-java text-orange-600'
        };

        stackContainer.innerHTML = frameworks.map(framework => `
            <div class="flex items-center p-3 bg-gray-50 rounded-lg">
                <i class="${frameworkIcons[framework] || 'fas fa-code text-gray-500'} text-xl mr-3"></i>
                <span class="font-medium text-gray-900 capitalize">${framework}</span>
            </div>
        `).join('');
    }

    // Display project dependencies
    displayDependencies(dependencies) {
        const depsContainer = document.getElementById('dependencies');
        
        if (Object.keys(dependencies).length === 0) {
            depsContainer.innerHTML = '<p class="text-gray-500 text-center py-4">No dependencies found</p>';
            return;
        }

        let depsHtml = '';
        for (const [manager, deps] of Object.entries(dependencies)) {
            depsHtml += `
                <div class="p-3 bg-gray-50 rounded-lg">
                    <div class="font-medium text-gray-900 mb-2">${manager.toUpperCase()}</div>
                    <div class="text-sm text-gray-600">
                        ${deps.slice(0, 5).join(', ')}
                        ${deps.length > 5 ? ` (+${deps.length - 5} more)` : ''}
                    </div>
                </div>
            `;
        }
        depsContainer.innerHTML = depsHtml;
    }

    // Show conversion options
    showConversionOptions(supportedConversions) {
        // Populate source language/framework from analysis
        if (this.analysisData && this.analysisData.languages.length > 0) {
            const primaryLanguage = this.analysisData.languages[0].language;
            const sourceLanguageSelect = document.getElementById('source-language');
            sourceLanguageSelect.value = primaryLanguage;
            
            // Populate source framework
            if (this.analysisData.frameworks.length > 0) {
                const sourceFrameworkSelect = document.getElementById('source-framework');
                sourceFrameworkSelect.value = this.analysisData.frameworks[0];
            }
        }

        // Show recommendations if available
        if (supportedConversions && supportedConversions.length > 0) {
            this.displayRecommendations(supportedConversions);
        }
    }

    // Display conversion recommendations
    displayRecommendations(conversions) {
        const recommendationsSection = document.getElementById('recommendations');
        const cardsContainer = document.getElementById('recommendation-cards');
        
        recommendationsSection.classList.remove('hidden');
        
        cardsContainer.innerHTML = conversions.map(conversion => `
            <div class="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer conversion-card"
                 data-source-lang="${conversion.source.language}"
                 data-source-framework="${conversion.source.framework || ''}"
                 data-target-lang="${conversion.target.language}"
                 data-target-framework="${conversion.target.framework || ''}">
                <div class="flex items-center justify-between mb-2">
                    <h5 class="font-medium text-gray-900">
                        ${conversion.source.language.charAt(0).toUpperCase() + conversion.source.language.slice(1)}
                        ${conversion.source.framework ? `(${conversion.source.framework})` : ''}
                        →
                        ${conversion.target.language.charAt(0).toUpperCase() + conversion.target.language.slice(1)}
                        ${conversion.target.framework ? `(${conversion.target.framework})` : ''}
                    </h5>
                    <span class="px-2 py-1 text-xs rounded-full ${this.getDifficultyColor(conversion.difficulty)}">
                        ${conversion.difficulty}
                    </span>
                </div>
                <p class="text-sm text-gray-600 mb-3">
                    Features preserved: ${conversion.features_preserved.join(', ')}
                </p>
                <button class="text-indigo-600 hover:text-indigo-800 text-sm font-medium">
                    Select this conversion →
                </button>
            </div>
        `).join('');

        // Add click handlers for recommendation cards
        document.querySelectorAll('.conversion-card').forEach(card => {
            card.addEventListener('click', () => {
                const targetLang = card.dataset.targetLang;
                const targetFramework = card.dataset.targetFramework;
                
                document.getElementById('target-language').value = targetLang;
                if (targetFramework) {
                    this.populateTargetFrameworks(targetLang);
                    setTimeout(() => {
                        document.getElementById('target-framework').value = targetFramework;
                    }, 100);
                }
            });
        });
    }

    // Get difficulty color class
    getDifficultyColor(difficulty) {
        switch (difficulty.toLowerCase()) {
            case 'easy':
                return 'bg-green-100 text-green-800';
            case 'medium':
                return 'bg-yellow-100 text-yellow-800';
            case 'hard':
                return 'bg-red-100 text-red-800';
            default:
                return 'bg-gray-100 text-gray-800';
        }
    }

    // Handle target language change
    handleTargetLanguageChange(event) {
        const targetLanguage = event.target.value;
        this.populateTargetFrameworks(targetLanguage);
    }

    // Populate target frameworks based on selected language
    populateTargetFrameworks(language) {
        const targetFrameworkSelect = document.getElementById('target-framework');
        targetFrameworkSelect.innerHTML = '<option value="">Select framework</option>';
        
        // Framework mappings
        const languageFrameworks = {
            'javascript': ['express', 'react', 'vue', 'angular'],
            'typescript': ['express', 'react', 'angular', 'nestjs'],
            'python': ['django', 'fastapi', 'flask'],
            'java': ['spring', 'hibernate'],
            'kotlin': ['jetpack-compose', 'ktor'],
            'swift': ['swiftui', 'vapor'],
            'dart': ['flutter'],
            'go': ['gin', 'echo', 'fiber']
        };
        
        const frameworks = languageFrameworks[language] || [];
        frameworks.forEach(framework => {
            const option = document.createElement('option');
            option.value = framework;
            option.textContent = framework.charAt(0).toUpperCase() + framework.slice(1);
            targetFrameworkSelect.appendChild(option);
        });
    }

    // Start conversion process
    async startConversion() {
        const sourceLanguage = document.getElementById('source-language').value;
        const targetLanguage = document.getElementById('target-language').value;
        const targetFramework = document.getElementById('target-framework').value;
        
        if (!targetLanguage) {
            this.showError('Please select a target language');
            return;
        }

        // Get conversion scope
        const conversionScope = [];
        if (document.getElementById('convert-frontend').checked) conversionScope.push('frontend');
        if (document.getElementById('convert-backend').checked) conversionScope.push('backend');
        if (document.getElementById('convert-database').checked) conversionScope.push('database');

        const conversionRequest = {
            project_id: this.currentProjectId,
            source_language: sourceLanguage || this.analysisData.languages[0].language,
            target_language: targetLanguage,
            source_framework: this.analysisData.frameworks[0] || null,
            target_framework: targetFramework || null,
            conversion_scope: conversionScope,
            preserve_structure: document.getElementById('preserve-structure').checked,
            include_tests: false
        };

        try {
            const response = await fetch('/api/convert', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(conversionRequest)
            });

            if (!response.ok) {
                throw new Error(`Conversion failed: ${response.statusText}`);
            }

            // Show progress section and start polling
            document.getElementById('conversion-section').classList.add('hidden');
            document.getElementById('progress-section').classList.remove('hidden');
            
            this.startProgressPolling();
            
        } catch (error) {
            console.error('Conversion start failed:', error);
            this.showError(`Failed to start conversion: ${error.message}`);
        }
    }

    // Start polling for conversion progress
    startProgressPolling() {
        this.conversionPollingInterval = setInterval(async () => {
            try {
                const response = await fetch(`/api/convert/${this.currentProjectId}/progress`);
                const progress = await response.json();
                
                this.updateProgress(progress);
                
                if (progress.status === 'completed') {
                    this.conversionCompleted();
                } else if (progress.status === 'failed') {
                    this.conversionFailed(progress.errors);
                }
                
            } catch (error) {
                console.error('Progress polling failed:', error);
                this.conversionFailed(['Failed to get conversion progress']);
            }
        }, 2000);
    }

    // Update progress display
    updateProgress(progress) {
        document.getElementById('progress-step').textContent = progress.current_step;
        document.getElementById('progress-percentage').textContent = `${Math.round(progress.progress_percentage)}%`;
        document.getElementById('progress-bar').style.width = `${progress.progress_percentage}%`;
        
        // Add log entry
        const logContainer = document.getElementById('conversion-log');
        const logEntry = document.createElement('div');
        logEntry.textContent = `${new Date().toLocaleTimeString()} - ${progress.current_step}`;
        logContainer.appendChild(logEntry);
        
        // Scroll to bottom
        logContainer.scrollTop = logContainer.scrollHeight;
    }

    // Handle conversion completion
    conversionCompleted() {
        if (this.conversionPollingInterval) {
            clearInterval(this.conversionPollingInterval);
            this.conversionPollingInterval = null;
        }
        
        document.getElementById('conversion-complete').classList.remove('hidden');
    }

    // Handle conversion failure
    conversionFailed(errors) {
        if (this.conversionPollingInterval) {
            clearInterval(this.conversionPollingInterval);
            this.conversionPollingInterval = null;
        }
        
        document.getElementById('progress-section').classList.add('hidden');
        this.showError(`Conversion failed: ${errors.join(', ')}`);
    }

    // Download converted project
    async downloadProject() {
        try {
            const response = await fetch(`/api/convert/${this.currentProjectId}/download`);
            
            if (!response.ok) {
                throw new Error('Download failed');
            }
            
            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `transpiled_${this.currentProjectId}.zip`;
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);
            
        } catch (error) {
            console.error('Download failed:', error);
            this.showError('Failed to download converted project');
        }
    }

    // Show error message
    showError(message) {
        document.getElementById('error-message').textContent = message;
        document.getElementById('error-section').classList.remove('hidden');
        
        // Hide other sections
        document.getElementById('progress-section').classList.add('hidden');
    }

    // Show/hide loading overlay
    showLoading(show) {
        const overlay = document.getElementById('loading-overlay');
        if (show) {
            overlay.classList.remove('hidden');
        } else {
            overlay.classList.add('hidden');
        }
    }

    // Reset application to initial state
    resetApplication() {
        // Clear data
        this.currentProjectId = null;
        this.analysisData = null;
        this.selectedFiles = null;
        
        // Stop polling if active
        if (this.conversionPollingInterval) {
            clearInterval(this.conversionPollingInterval);
            this.conversionPollingInterval = null;
        }
        
        // Reset UI
        document.getElementById('upload-section').classList.remove('hidden');
        document.getElementById('analysis-section').classList.add('hidden');
        document.getElementById('conversion-section').classList.add('hidden');
        document.getElementById('progress-section').classList.add('hidden');
        document.getElementById('error-section').classList.add('hidden');
        
        // Reset upload button and dropzone
        document.getElementById('upload-button').disabled = true;
        document.getElementById('dropzone').innerHTML = `
            <div class="space-y-4">
                <div class="text-4xl text-indigo-400">
                    <i class="fas fa-file-upload"></i>
                </div>
                <div>
                    <p class="text-xl text-gray-700 font-medium">Drop your project files here</p>
                    <p class="text-gray-500">or click to browse</p>
                </div>
                <div class="text-sm text-gray-400">
                    Supports: ZIP files, individual source files, project folders<br>
                    Max size: 100MB
                </div>
            </div>
        `;
        
        // Clear file input
        document.getElementById('file-input').value = '';
    }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.transpiler = new UniversalCodeTranspiler();
});
