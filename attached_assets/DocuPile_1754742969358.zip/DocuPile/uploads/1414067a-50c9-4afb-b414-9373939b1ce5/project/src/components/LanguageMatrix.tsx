import React, { useState, useEffect } from 'react';
import { Code, ArrowRight, Star, TrendingUp, Users, Zap } from 'lucide-react';

interface Language {
  name: string;
  extensions: string[];
  frameworks: string[];
  ecosystem: string;
  difficulty: string;
  popularity: number;
  platform?: string;
}

interface Category {
  name: string;
  description: string;
  languages: Language[];
}

const LanguageMatrix: React.FC = () => {
  const [categories, setCategories] = useState<Record<string, Category>>({});
  const [selectedCategory, setSelectedCategory] = useState<string>('frontend_web');
  const [conversions, setConversions] = useState<Array<{from: string; to: string; difficulty: string; accuracy: number}>>([]);

  useEffect(() => {
    const loadLanguageData = async () => {
      try {
        const response = await fetch('/api/languages');
        const data = await response.json();
        setCategories(data.categories);
        setConversions(data.conversion_matrix.supported_conversions);
      } catch (error) {
        console.error('Failed to load language data:', error);
      }
    };

    loadLanguageData();
  }, []);

  const categoryIcons: Record<string, any> = {
    frontend_web: Code,
    mobile: Users,
    backend: Zap,
    database: TrendingUp,
    systems: Star,
    data_science: TrendingUp,
    legacy: Code
  };

  const difficultyColors = {
    'low': 'bg-green-500/20 text-green-300',
    'medium': 'bg-yellow-500/20 text-yellow-300', 
    'medium-high': 'bg-orange-500/20 text-orange-300',
    'high': 'bg-red-500/20 text-red-300',
    'very high': 'bg-red-600/20 text-red-300'
  };

  const ecosystemColors = {
    'mature': 'text-green-400',
    'growing': 'text-blue-400',
    'emerging': 'text-yellow-400',
    'legacy': 'text-gray-400',
    'specialized': 'text-purple-400'
  };

  if (Object.keys(categories).length === 0) {
    return (
      <div className="bg-white/10 backdrop-blur-sm rounded-2xl border border-white/20 p-8">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-400 mx-auto mb-4"></div>
          <p className="text-blue-200">Loading language matrix...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white/10 backdrop-blur-sm rounded-2xl border border-white/20 p-8">
      <div className="text-center mb-8">
        <Code className="w-12 h-12 text-blue-400 mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-white mb-2">Supported Languages & Frameworks</h2>
        <p className="text-blue-200">
          Comprehensive support for modern development stacks with intelligent conversion capabilities
        </p>
      </div>

      {/* Category Tabs */}
      <div className="flex flex-wrap justify-center gap-2 mb-8">
        {Object.entries(categories).map(([key, category]) => {
          const Icon = categoryIcons[key] || Code;
          return (
            <button
              key={key}
              onClick={() => setSelectedCategory(key)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-xl font-medium transition-all duration-200 ${
                selectedCategory === key
                  ? 'bg-blue-600 text-white shadow-lg'
                  : 'bg-white/10 text-blue-200 hover:bg-white/20'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span className="hidden sm:inline">{category.name}</span>
              <span className="sm:hidden">{category.name.split(' ')[0]}</span>
            </button>
          );
        })}
      </div>

      {/* Selected Category */}
      {categories[selectedCategory] && (
        <div className="space-y-6">
          <div className="text-center">
            <h3 className="text-xl font-bold text-white mb-2">
              {categories[selectedCategory].name}
            </h3>
            <p className="text-blue-200 text-sm">
              {categories[selectedCategory].description}
            </p>
          </div>

          {/* Languages Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {categories[selectedCategory].languages.map((language, index) => (
              <div key={index} className="bg-white/5 rounded-xl p-4 border border-white/10 hover:bg-white/10 transition-all duration-200">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-bold text-white">{language.name}</h4>
                  <div className="flex items-center space-x-1">
                    <Star className="w-4 h-4 text-yellow-400" />
                    <span className="text-sm text-yellow-400">{language.popularity}</span>
                  </div>
                </div>

                <div className="space-y-2 text-sm">
                  <div>
                    <span className="text-blue-200">Extensions:</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {language.extensions.map(ext => (
                        <span key={ext} className="px-2 py-1 bg-slate-700/50 rounded text-xs text-gray-300">
                          {ext}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div>
                    <span className="text-blue-200">Frameworks:</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {language.frameworks.slice(0, 3).map(framework => (
                        <span key={framework} className="px-2 py-1 bg-blue-600/20 rounded text-xs text-blue-300">
                          {framework}
                        </span>
                      ))}
                      {language.frameworks.length > 3 && (
                        <span className="px-2 py-1 bg-gray-600/20 rounded text-xs text-gray-400">
                          +{language.frameworks.length - 3} more
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2">
                    <div className="flex items-center space-x-2">
                      <span className={`px-2 py-1 rounded-full text-xs ${difficultyColors[language.difficulty as keyof typeof difficultyColors] || difficultyColors.medium}`}>
                        {language.difficulty}
                      </span>
                      <span className={`text-xs ${ecosystemColors[language.ecosystem as keyof typeof ecosystemColors] || 'text-gray-400'}`}>
                        {language.ecosystem}
                      </span>
                    </div>
                    {language.platform && (
                      <span className="text-xs text-purple-300 bg-purple-500/20 px-2 py-1 rounded">
                        {language.platform}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Supported Conversions Preview */}
      <div className="mt-12 pt-8 border-t border-white/20">
        <h3 className="text-xl font-bold text-white mb-6 text-center">
          Popular Conversion Paths
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {conversions.slice(0, 6).map((conversion, index) => (
            <div key={index} className="flex items-center justify-between bg-white/5 rounded-lg p-4 border border-white/10">
              <div className="flex items-center space-x-3">
                <span className="text-white font-medium capitalize">{conversion.from.replace('_', ' ')}</span>
                <ArrowRight className="w-4 h-4 text-blue-400" />
                <span className="text-white font-medium capitalize">{conversion.to.replace('_', ' ')}</span>
              </div>
              <div className="flex items-center space-x-2 text-sm">
                <span className={`px-2 py-1 rounded ${difficultyColors[conversion.difficulty as keyof typeof difficultyColors] || difficultyColors.medium}`}>
                  {conversion.difficulty}
                </span>
                <span className="text-green-400">{conversion.accuracy}%</span>
              </div>
            </div>
          ))}
        </div>
        <div className="text-center mt-6">
          <p className="text-blue-200 text-sm">
            And many more bidirectional conversions supported!
          </p>
        </div>
      </div>
    </div>
  );
};

export default LanguageMatrix;