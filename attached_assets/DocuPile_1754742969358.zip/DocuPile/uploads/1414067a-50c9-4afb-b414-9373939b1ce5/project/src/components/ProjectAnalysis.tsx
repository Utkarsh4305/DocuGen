import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend } from 'recharts';
import { Code, Database, Globe, Smartphone, Zap, RefreshCw, TrendingUp, AlertTriangle, CheckCircle } from 'lucide-react';

interface Analysis {
  techStack: {
    frontend: string[];
    backend: string[];
    database: string[];
    mobile: string[];
    tools: string[];
  };
  languageDistribution: Record<string, {
    lines: number;
    files: number;
    percentage: number;
    extensions: string[];
  }>;
  dependencies: any;
  structure: any;
  recommendations: Array<{
    type: string;
    title: string;
    description: string;
    difficulty: string;
    impact: string;
  }>;
}

interface ProjectAnalysisProps {
  analysis: Analysis;
  onReset: () => void;
}

const ProjectAnalysis: React.FC<ProjectAnalysisProps> = ({ analysis, onReset }) => {
  const { techStack, languageDistribution, structure, recommendations } = analysis;

  // Prepare data for charts
  const languageData = Object.entries(languageDistribution).map(([lang, data]) => ({
    name: lang,
    value: data.percentage,
    lines: data.lines,
    files: data.files
  }));

  const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899', '#06B6D4', '#84CC16'];

  const categoryIcons = {
    frontend: Globe,
    backend: Database,
    mobile: Smartphone,
    database: Database,
    tools: Zap
  };

  const difficultyColors = {
    low: 'bg-green-500/20 text-green-300 border-green-400/30',
    medium: 'bg-yellow-500/20 text-yellow-300 border-yellow-400/30',
    'medium-high': 'bg-orange-500/20 text-orange-300 border-orange-400/30',
    high: 'bg-red-500/20 text-red-300 border-red-400/30'
  };

  const impactColors = {
    low: 'text-gray-400',
    medium: 'text-yellow-400',
    high: 'text-green-400'
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="bg-white/10 backdrop-blur-sm rounded-2xl border border-white/20 p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="p-3 rounded-full bg-green-500/20">
              <CheckCircle className="w-6 h-6 text-green-400" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white">Project Analysis Complete</h2>
              <p className="text-blue-200">
                Found {Object.keys(languageDistribution).length} languages across {structure.files?.length || 0} files
              </p>
            </div>
          </div>
          <button
            onClick={onReset}
            className="flex items-center space-x-2 px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl transition-all duration-200"
          >
            <RefreshCw className="w-4 h-4" />
            <span>New Project</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Language Distribution Chart */}
        <div className="bg-white/10 backdrop-blur-sm rounded-2xl border border-white/20 p-6">
          <h3 className="text-xl font-bold text-white mb-6 flex items-center">
            <TrendingUp className="w-6 h-6 mr-2 text-blue-400" />
            Language Distribution
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={languageData}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  dataKey="value"
                  label={({ name, value }) => `${name}: ${value}%`}
                  labelLine={false}
                >
                  {languageData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  formatter={(value: any, name: any, props: any) => [
                    [`${value}% (${props.payload.lines} lines, ${props.payload.files} files)`],
                    name
                  ]}
                  contentStyle={{
                    backgroundColor: 'rgba(15, 23, 42, 0.9)',
                    border: '1px solid rgba(148, 163, 184, 0.3)',
                    borderRadius: '12px',
                    color: 'white'
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Tech Stack Overview */}
        <div className="bg-white/10 backdrop-blur-sm rounded-2xl border border-white/20 p-6">
          <h3 className="text-xl font-bold text-white mb-6 flex items-center">
            <Code className="w-6 h-6 mr-2 text-blue-400" />
            Detected Technologies
          </h3>
          <div className="space-y-4">
            {Object.entries(techStack).map(([category, technologies]) => {
              if (!technologies.length) return null;
              const Icon = categoryIcons[category as keyof typeof categoryIcons];
              
              return (
                <div key={category} className="flex items-start space-x-3">
                  <div className="p-2 rounded-lg bg-blue-500/20">
                    <Icon className="w-5 h-5 text-blue-400" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-white capitalize">{category}</h4>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {technologies.map((tech, index) => (
                        <span
                          key={index}
                          className="px-3 py-1 bg-white/10 rounded-full text-sm text-blue-200 backdrop-blur-sm"
                        >
                          {tech}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Language Details */}
      <div className="bg-white/10 backdrop-blur-sm rounded-2xl border border-white/20 p-6">
        <h3 className="text-xl font-bold text-white mb-6">Language Breakdown</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {Object.entries(languageDistribution).map(([language, data], index) => (
            <div key={language} className="bg-white/5 rounded-xl p-4 border border-white/10">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-semibold text-white">{language}</h4>
                <span 
                  className="px-2 py-1 rounded-full text-xs font-medium"
                  style={{ 
                    backgroundColor: COLORS[index % COLORS.length] + '33',
                    color: COLORS[index % COLORS.length]
                  }}
                >
                  {data.percentage}%
                </span>
              </div>
              <div className="space-y-2 text-sm text-blue-200">
                <div className="flex justify-between">
                  <span>Lines:</span>
                  <span className="text-white font-medium">{data.lines.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span>Files:</span>
                  <span className="text-white font-medium">{data.files}</span>
                </div>
                <div className="flex justify-between">
                  <span>Extensions:</span>
                  <span className="text-white font-medium">{data.extensions.join(', ')}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recommendations */}
      {recommendations.length > 0 && (
        <div className="bg-white/10 backdrop-blur-sm rounded-2xl border border-white/20 p-6">
          <h3 className="text-xl font-bold text-white mb-6 flex items-center">
            <AlertTriangle className="w-6 h-6 mr-2 text-yellow-400" />
            Migration Recommendations
          </h3>
          <div className="grid gap-4">
            {recommendations.map((rec, index) => (
              <div key={index} className="bg-white/5 rounded-xl p-4 border border-white/10">
                <div className="flex items-start justify-between mb-2">
                  <h4 className="font-semibold text-white">{rec.title}</h4>
                  <div className="flex items-center space-x-2">
                    <span className={`px-2 py-1 rounded-full text-xs border ${difficultyColors[rec.difficulty as keyof typeof difficultyColors] || difficultyColors.medium}`}>
                      {rec.difficulty} difficulty
                    </span>
                    <span className={`text-xs font-medium ${impactColors[rec.impact as keyof typeof impactColors] || impactColors.medium}`}>
                      {rec.impact} impact
                    </span>
                  </div>
                </div>
                <p className="text-blue-200 text-sm">{rec.description}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default ProjectAnalysis;