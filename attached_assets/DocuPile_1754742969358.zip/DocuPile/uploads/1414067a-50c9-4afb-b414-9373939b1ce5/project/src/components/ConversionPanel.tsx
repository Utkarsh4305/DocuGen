import React from 'react';
import { ArrowRight, Settings, Zap, Code2 } from 'lucide-react';

interface Analysis {
  techStack: {
    frontend: string[];
    backend: string[];
    database: string[];
    mobile: string[];
    tools: string[];
  };
  languageDistribution: Record<string, any>;
}

interface ConversionPanelProps {
  analysis: Analysis | null;
  conversions: Record<string, { from: string; to: string }>;
  onConversionChange: (component: string, from: string, to: string) => void;
  onTranspile: () => void;
  isTranspiling: boolean;
}

const ConversionPanel: React.FC<ConversionPanelProps> = ({
  analysis,
  conversions,
  onConversionChange,
  onTranspile,
  isTranspiling
}) => {
  if (!analysis) return null;

  const conversionOptions = {
    frontend: {
      react: ['react_native', 'flutter', 'kotlin', 'vue', 'angular'],
      vue: ['react', 'angular', 'svelte'],
      angular: ['react', 'vue', 'svelte'],
      flutter: ['react_native', 'kotlin', 'swiftui'],
      react_native: ['react', 'flutter', 'kotlin'],
      kotlin: ['flutter', 'swiftui', 'react_native'],
      swiftui: ['flutter', 'kotlin', 'react_native']
    },
    backend: {
      nodejs: ['python', 'go', 'java', 'rust'],
      python: ['nodejs', 'go', 'java', 'rust'],
      go: ['nodejs', 'python', 'java', 'rust'],
      java: ['nodejs', 'python', 'go', 'kotlin'],
      rust: ['nodejs', 'python', 'go']
    },
    database: {
      sql: ['mongodb', 'firebase', 'dynamodb'],
      mysql: ['postgresql', 'mongodb', 'sqlite'],
      postgresql: ['mysql', 'mongodb', 'sqlite'],
      mongodb: ['postgresql', 'mysql', 'sqlite'],
      sqlite: ['postgresql', 'mysql', 'mongodb']
    }
  };

  const prettyNames: Record<string, string> = {
    react: 'React',
    react_native: 'React Native',
    flutter: 'Flutter',
    kotlin: 'Kotlin (Jetpack Compose)',
    swiftui: 'SwiftUI',
    vue: 'Vue.js',
    angular: 'Angular',
    svelte: 'Svelte',
    nodejs: 'Node.js (Express)',
    python: 'Python (FastAPI)',
    go: 'Go (Gin)',
    java: 'Java (Spring Boot)',
    rust: 'Rust (Actix)',
    sql: 'SQL',
    mysql: 'MySQL',
    postgresql: 'PostgreSQL',
    mongodb: 'MongoDB',
    sqlite: 'SQLite',
    firebase: 'Firebase',
    dynamodb: 'DynamoDB'
  };

  const detectCurrentTech = (category: keyof typeof analysis.techStack) => {
    const techs = analysis.techStack[category];
    if (!techs.length) return null;
    
    // Map detected tech to our conversion keys
    const techMap: Record<string, string> = {
      'React': 'react',
      'React Native': 'react_native',
      'Flutter': 'flutter',
      'Vue.js': 'vue',
      'Angular': 'angular',
      'Svelte': 'svelte',
      'Node.js': 'nodejs',
      'Express': 'nodejs',
      'Python': 'python',
      'FastAPI': 'python',
      'Django': 'python',
      'Go': 'go',
      'Gin': 'go',
      'Java': 'java',
      'Spring Boot': 'java',
      'PostgreSQL': 'postgresql',
      'MySQL': 'mysql',
      'MongoDB': 'mongodb',
      'SQLite': 'sqlite'
    };

    return techMap[techs[0]] || techs[0].toLowerCase();
  };

  const getConversionDifficulty = (from: string, to: string) => {
    const difficultyMatrix: Record<string, Record<string, 'easy' | 'medium' | 'hard'>> = {
      react: {
        react_native: 'medium',
        flutter: 'hard',
        kotlin: 'hard',
        vue: 'medium',
        angular: 'medium'
      },
      nodejs: {
        python: 'medium',
        go: 'medium',
        java: 'hard'
      },
      python: {
        nodejs: 'medium',
        go: 'medium',
        java: 'hard'
      }
    };

    return difficultyMatrix[from]?.[to] || 'medium';
  };

  const categories = ['frontend', 'backend', 'database'] as const;
  const activeCategories = categories.filter(cat => {
    const currentTech = detectCurrentTech(cat);
    return currentTech && conversionOptions[cat]?.[currentTech];
  });

  const hasConversions = Object.keys(conversions).length > 0;

  return (
    <div className="space-y-8">
      <div className="bg-white/10 backdrop-blur-sm rounded-2xl border border-white/20 p-8">
        <div className="text-center mb-8">
          <Settings className="w-12 h-12 text-blue-400 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-2">Configure Conversions</h2>
          <p className="text-blue-200">
            Select which technologies you want to convert to
          </p>
        </div>

        <div className="space-y-6">
          {activeCategories.map((category) => {
            const currentTech = detectCurrentTech(category);
            if (!currentTech) return null;

            const options = conversionOptions[category]?.[currentTech] || [];
            const conversion = conversions[category];

            return (
              <div key={category} className="bg-white/5 rounded-xl p-6 border border-white/10">
                <h3 className="text-lg font-semibold text-white mb-4 capitalize">
                  {category} Conversion
                </h3>
                
                <div className="flex items-center space-x-4">
                  {/* From */}
                  <div className="flex-1">
                    <label className="block text-sm font-medium text-blue-200 mb-2">From</label>
                    <div className="p-3 bg-slate-700/50 rounded-lg border border-slate-600">
                      <span className="text-white font-medium">
                        {prettyNames[currentTech] || currentTech}
                      </span>
                    </div>
                  </div>

                  {/* Arrow */}
                  <div className="pt-6">
                    <ArrowRight className="w-6 h-6 text-blue-400" />
                  </div>

                  {/* To */}
                  <div className="flex-1">
                    <label className="block text-sm font-medium text-blue-200 mb-2">To</label>
                    <select
                      value={conversion?.to || ''}
                      onChange={(e) => onConversionChange(category, currentTech, e.target.value)}
                      className="w-full p-3 bg-slate-700/50 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="">Select target technology...</option>
                      {options.map((option) => (
                        <option key={option} value={option}>
                          {prettyNames[option] || option}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Difficulty Badge */}
                {conversion && (
                  <div className="mt-4 flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <span className="text-sm text-blue-200">Conversion Difficulty:</span>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        getConversionDifficulty(conversion.from, conversion.to) === 'easy' 
                          ? 'bg-green-500/20 text-green-300'
                          : getConversionDifficulty(conversion.from, conversion.to) === 'medium'
                          ? 'bg-yellow-500/20 text-yellow-300'
                          : 'bg-red-500/20 text-red-300'
                      }`}>
                        {getConversionDifficulty(conversion.from, conversion.to)}
                      </span>
                    </div>
                    <div className="text-sm text-blue-300">
                      ~85% accuracy expected
                    </div>
                  </div>
                )}
              </div>
            );
          })}

          {activeCategories.length === 0 && (
            <div className="text-center py-8">
              <Code2 className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-300">
                No convertible technologies detected in your project
              </p>
            </div>
          )}
        </div>

        {/* Transpile Button */}
        {hasConversions && (
          <div className="mt-8 text-center">
            <button
              onClick={onTranspile}
              disabled={isTranspiling}
              className={`inline-flex items-center px-8 py-3 text-white font-semibold rounded-xl transition-all duration-200 transform hover:scale-105 shadow-lg ${
                isTranspiling
                  ? 'bg-gray-600 cursor-not-allowed'
                  : 'bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700'
              }`}
            >
              <Zap className={`w-5 h-5 mr-2 ${isTranspiling ? 'animate-spin' : ''}`} />
              {isTranspiling ? 'Transpiling...' : 'Start Transpilation'}
            </button>
            
            {hasConversions && (
              <p className="text-sm text-blue-200 mt-3">
                {Object.keys(conversions).length} conversion{Object.keys(conversions).length !== 1 ? 's' : ''} configured
              </p>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default ConversionPanel;