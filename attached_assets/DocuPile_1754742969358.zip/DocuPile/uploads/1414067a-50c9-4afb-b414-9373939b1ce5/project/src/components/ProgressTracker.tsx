import React from 'react';
import { CheckCircle, Clock, AlertCircle, Loader, Upload, Search, Zap, TestTube } from 'lucide-react';

interface ConversionStatus {
  phase: 'idle' | 'uploading' | 'analyzing' | 'converting' | 'testing' | 'complete' | 'error';
  progress: number;
  message: string;
}

interface ProgressTrackerProps {
  status: ConversionStatus;
}

const ProgressTracker: React.FC<ProgressTrackerProps> = ({ status }) => {
  const phases = [
    { key: 'uploading', label: 'Upload', icon: Upload },
    { key: 'analyzing', label: 'Analyze', icon: Search },
    { key: 'converting', label: 'Convert', icon: Zap },
    { key: 'testing', label: 'Test', icon: TestTube },
    { key: 'complete', label: 'Complete', icon: CheckCircle }
  ];

  const getPhaseStatus = (phaseKey: string, currentPhase: string, progress: number) => {
    const phaseIndex = phases.findIndex(p => p.key === phaseKey);
    const currentIndex = phases.findIndex(p => p.key === currentPhase);
    
    if (currentPhase === 'error') {
      return currentIndex >= phaseIndex ? 'error' : 'pending';
    }
    
    if (phaseIndex < currentIndex || currentPhase === 'complete') {
      return 'complete';
    } else if (phaseIndex === currentIndex) {
      return 'active';
    } else {
      return 'pending';
    }
  };

  if (status.phase === 'idle') {
    return null;
  }

  return (
    <div className="bg-white/10 backdrop-blur-sm rounded-2xl border border-white/20 p-6">
      <div className="mb-6">
        <h3 className="text-xl font-bold text-white mb-2">Progress Tracker</h3>
        <p className="text-blue-200">{status.message}</p>
      </div>

      {/* Progress Bar */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm text-blue-200">Overall Progress</span>
          <span className="text-sm text-white font-medium">{status.progress}%</span>
        </div>
        <div className="w-full bg-slate-700/50 rounded-full h-2">
          <div 
            className={`h-2 rounded-full transition-all duration-500 ${
              status.phase === 'error' ? 'bg-red-500' : 'bg-gradient-to-r from-blue-500 to-purple-500'
            }`}
            style={{ width: `${status.progress}%` }}
          />
        </div>
      </div>

      {/* Phase Steps */}
      <div className="flex items-center justify-between">
        {phases.map((phase, index) => {
          const phaseStatus = getPhaseStatus(phase.key, status.phase, status.progress);
          const Icon = phase.icon;
          
          return (
            <div key={phase.key} className="flex flex-col items-center">
              <div className={`relative p-3 rounded-full border-2 transition-all duration-300 ${
                phaseStatus === 'complete' 
                  ? 'bg-green-500/20 border-green-400 text-green-400'
                  : phaseStatus === 'active'
                  ? 'bg-blue-500/20 border-blue-400 text-blue-400'
                  : phaseStatus === 'error'
                  ? 'bg-red-500/20 border-red-400 text-red-400'
                  : 'bg-slate-700/50 border-slate-600 text-slate-400'
              }`}>
                {phaseStatus === 'active' && status.phase !== 'complete' ? (
                  <Loader className="w-5 h-5 animate-spin" />
                ) : phaseStatus === 'error' ? (
                  <AlertCircle className="w-5 h-5" />
                ) : (
                  <Icon className="w-5 h-5" />
                )}
                
                {phaseStatus === 'complete' && (
                  <div className="absolute -top-1 -right-1 w-4 h-4 bg-green-500 rounded-full flex items-center justify-center">
                    <CheckCircle className="w-3 h-3 text-white" />
                  </div>
                )}
              </div>
              
              <span className={`mt-2 text-sm font-medium ${
                phaseStatus === 'complete'
                  ? 'text-green-300'
                  : phaseStatus === 'active'
                  ? 'text-blue-300'
                  : phaseStatus === 'error'
                  ? 'text-red-300'
                  : 'text-slate-400'
              }`}>
                {phase.label}
              </span>
              
              {/* Connector Line */}
              {index < phases.length - 1 && (
                <div className={`absolute top-6 left-1/2 w-16 h-0.5 ${
                  getPhaseStatus(phases[index + 1].key, status.phase, status.progress) === 'complete' ||
                  (phaseStatus === 'complete' && getPhaseStatus(phases[index + 1].key, status.phase, status.progress) === 'active')
                    ? 'bg-green-400'
                    : 'bg-slate-600'
                }`} 
                style={{ 
                  transform: 'translateX(-50%)',
                  marginLeft: '3rem'
                }}
                />
              )}
            </div>
          );
        })}
      </div>

      {/* Error Message */}
      {status.phase === 'error' && (
        <div className="mt-6 p-4 bg-red-500/20 border border-red-400/30 rounded-xl">
          <div className="flex items-center space-x-2">
            <AlertCircle className="w-5 h-5 text-red-400" />
            <p className="text-red-200 font-medium">Transpilation Failed</p>
          </div>
          <p className="text-red-300 text-sm mt-1">{status.message}</p>
        </div>
      )}
    </div>
  );
};

export default ProgressTracker;