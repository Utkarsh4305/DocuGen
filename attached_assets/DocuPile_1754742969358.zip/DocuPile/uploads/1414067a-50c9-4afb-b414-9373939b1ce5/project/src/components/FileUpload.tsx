import React, { useState, useRef } from 'react';
import { Upload, File, AlertCircle, CheckCircle, Loader } from 'lucide-react';

interface FileUploadProps {
  onUploadComplete: (projectId: string, analysis: any) => void;
}

const FileUpload: React.FC<FileUploadProps> = ({ onUploadComplete }) => {
  const [isDragOver, setIsDragOver] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = async (file: File) => {
    if (!file.name.endsWith('.zip')) {
      setUploadError('Please upload a ZIP file containing your project');
      return;
    }

    if (file.size > 50 * 1024 * 1024) { // 50MB limit
      setUploadError('File size must be less than 50MB');
      return;
    }

    setIsUploading(true);
    setUploadError(null);

    const formData = new FormData();
    formData.append('project', file);

    try {
      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Upload failed');
      }

      const result = await response.json();
      onUploadComplete(result.projectId, result.analysis);
    } catch (error) {
      console.error('Upload error:', error);
      setUploadError(error instanceof Error ? error.message : 'Upload failed');
    } finally {
      setIsUploading(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleFileSelect(files[0]);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      handleFileSelect(files[0]);
    }
  };

  const openFileDialog = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div
        className={`relative border-2 border-dashed rounded-2xl p-12 text-center transition-all duration-200 ${
          isDragOver 
            ? 'border-blue-400 bg-blue-500/10 scale-105' 
            : 'border-white/30 bg-white/5 hover:border-blue-400/50 hover:bg-white/10'
        } ${isUploading ? 'pointer-events-none opacity-50' : 'cursor-pointer'}`}
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onClick={openFileDialog}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept=".zip"
          onChange={handleFileInputChange}
          className="hidden"
        />
        
        <div className="space-y-4">
          {isUploading ? (
            <div className="flex flex-col items-center">
              <Loader className="w-16 h-16 text-blue-400 animate-spin mb-4" />
              <h3 className="text-xl font-semibold text-white">Uploading & Analyzing</h3>
              <p className="text-blue-200">Please wait while we process your project...</p>
            </div>
          ) : (
            <>
              <div className="flex justify-center">
                <div className="p-4 rounded-full bg-blue-500/20 backdrop-blur-sm">
                  <Upload className="w-12 h-12 text-blue-400" />
                </div>
              </div>
              
              <div>
                <h3 className="text-xl font-semibold text-white mb-2">
                  Drop your project ZIP file here
                </h3>
                <p className="text-blue-200 mb-4">
                  or click to browse your files
                </p>
                <button className="inline-flex items-center px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl transition-all duration-200 transform hover:scale-105 shadow-lg">
                  <File className="w-5 h-5 mr-2" />
                  Choose File
                </button>
              </div>

              <div className="text-sm text-blue-300 space-y-1">
                <p>• Supported: React, Vue, Angular, Flutter, Swift, Kotlin</p>
                <p>• Backend: Node.js, Python, Go, Java</p>
                <p>• Database: SQL, MongoDB, PostgreSQL</p>
                <p>• Maximum file size: 50MB</p>
              </div>
            </>
          )}
        </div>
      </div>

      {uploadError && (
        <div className="mt-6 p-4 bg-red-500/20 border border-red-400/30 rounded-xl backdrop-blur-sm">
          <div className="flex items-center space-x-2">
            <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0" />
            <p className="text-red-200">{uploadError}</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default FileUpload;