import React, { useState } from 'react';
import { Upload, Download, Zap, Code, Cpu, Database, Smartphone, Globe, ArrowRight, CheckCircle, AlertCircle, Clock } from 'lucide-react';
import FileUpload from './components/FileUpload';
import ProjectAnalysis from './components/ProjectAnalysis';
import ConversionPanel from './components/ConversionPanel';
import ProgressTracker from './components/ProgressTracker';
import LanguageMatrix from './components/LanguageMatrix';

interface Analysis {
  techStack: {
    frontend: string[];
    backend: string[];
    database: string[];
    mobile: string[];
    tools: string[];
  };
  languageDistribution: Record<string, {
    lines: number;
    files: number;
    percentage: number;
    extensions: string[];
  }>;
  dependencies: any;
  structure: any;
  recommendations: Array<{
    type: string;
    title: string;
    description: string;
    difficulty: string;
    impact: string;
  }>;
}

interface ConversionStatus {
  phase: 'idle' | 'uploading' | 'analyzing' | 'converting' | 'testing' | 'complete' | 'error';
  progress: number;
  message: string;
}

function App() {
  const [projectId, setProjectId] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<Analysis | null>(null);
  const [conversions, setConversions] = useState<Record<string, { from: string; to: string }>>({});
  const [status, setStatus] = useState<ConversionStatus>({
    phase: 'idle',
    progress: 0,
    message: 'Ready to start'
  });
  const [downloadUrl, setDownloadUrl] = useState<string | null>(null);

  const handleProjectUpload = (uploadedProjectId: string, uploadedAnalysis: Analysis) => {
    setProjectId(uploadedProjectId);
    setAnalysis(uploadedAnalysis);
    setStatus({
      phase: 'complete',
      progress: 100,
      message: 'Project analyzed successfully'
    });
  };

  const handleConversionChange = (component: string, from: string, to: string) => {
    setConversions(prev => ({
      ...prev,
      [component]: { from, to }
    }));
  };

  const handleTranspile = async () => {
    if (!projectId || Object.keys(conversions).length === 0) return;

    setStatus({ phase: 'converting', progress: 20, message: 'Starting transpilation...' });

    try {
      // Simulate progress updates
      const progressSteps = [
        { phase: 'analyzing' as const, progress: 30, message: 'Generating UIR representation...' },
        { phase: 'converting' as const, progress: 50, message: 'Converting code structure...' },
        { phase: 'testing' as const, progress: 70, message: 'Generating tests...' },
        { phase: 'complete' as const, progress: 90, message: 'Finalizing output...' }
      ];

      for (const step of progressSteps) {
        setStatus(step);
        await new Promise(resolve => setTimeout(resolve, 1000));
      }

      const response = await fetch('/api/transpile', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          projectId,
          conversions
        }),
      });

      if (!response.ok) {
        throw new Error('Transpilation failed');
      }

      const result = await response.json();
      setDownloadUrl(result.downloadUrl);
      setStatus({
        phase: 'complete',
        progress: 100,
        message: 'Transpilation complete!'
      });

    } catch (error) {
      console.error('Transpilation error:', error);
      setStatus({
        phase: 'error',
        progress: 0,
        message: 'Transpilation failed. Please try again.'
      });
    }
  };

  const resetProject = () => {
    setProjectId(null);
    setAnalysis(null);
    setConversions({});
    setDownloadUrl(null);
    setStatus({
      phase: 'idle',
      progress: 0,
      message: 'Ready to start'
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900">
      {/* Header */}
      <header className="relative overflow-hidden bg-gradient-to-r from-blue-600 to-purple-700 shadow-2xl">
        <div className="absolute inset-0 bg-black/20" />
        <div className="relative max-w-7xl mx-auto px-6 py-12">
          <div className="text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-white/10 backdrop-blur-sm mb-6">
              <Zap className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-4">
              Universal Code Transpiler
            </h1>
            <p className="text-xl text-blue-100 max-w-3xl mx-auto leading-relaxed">
              Transform any codebase across languages and frameworks with AST parsing and intelligent conversion
            </p>
            <div className="flex flex-wrap justify-center gap-4 mt-8">
              {[
                { icon: Code, label: 'AST Parsing' },
                { icon: Cpu, label: 'UIR Engine' },
                { icon: Database, label: 'Multi-Stack' },
                { icon: Smartphone, label: 'Cross-Platform' }
              ].map(({ icon: Icon, label }) => (
                <div key={label} className="flex items-center space-x-2 bg-white/10 backdrop-blur-sm rounded-full px-4 py-2">
                  <Icon className="w-5 h-5 text-blue-200" />
                  <span className="text-sm font-medium text-blue-100">{label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-12">
        <div className="space-y-12">
          {/* Progress Tracker */}
          <ProgressTracker status={status} />

          {!projectId ? (
            <>
              {/* Upload Section */}
              <div className="bg-white/10 backdrop-blur-sm rounded-2xl border border-white/20 p-8">
                <div className="text-center mb-8">
                  <Upload className="w-12 h-12 text-blue-400 mx-auto mb-4" />
                  <h2 className="text-2xl font-bold text-white mb-2">Upload Your Project</h2>
                  <p className="text-blue-200">
                    Upload a ZIP file containing your full project (frontend, backend, database)
                  </p>
                </div>
                <FileUpload onUploadComplete={handleProjectUpload} />
              </div>

              {/* Language Matrix */}
              <LanguageMatrix />
            </>
          ) : (
            <>
              {/* Project Analysis */}
              {analysis && (
                <ProjectAnalysis 
                  analysis={analysis} 
                  onReset={resetProject}
                />
              )}

              {/* Conversion Panel */}
              <ConversionPanel
                analysis={analysis}
                conversions={conversions}
                onConversionChange={handleConversionChange}
                onTranspile={handleTranspile}
                isTranspiling={status.phase === 'converting' || status.phase === 'analyzing' || status.phase === 'testing'}
              />

              {/* Download Section */}
              {downloadUrl && (
                <div className="bg-gradient-to-r from-green-500/20 to-emerald-600/20 backdrop-blur-sm rounded-2xl border border-green-400/30 p-8">
                  <div className="text-center">
                    <CheckCircle className="w-16 h-16 text-green-400 mx-auto mb-4" />
                    <h2 className="text-2xl font-bold text-white mb-2">Transpilation Complete!</h2>
                    <p className="text-green-200 mb-6">
                      Your project has been successfully converted and is ready for download
                    </p>
                    <div className="flex flex-col sm:flex-row gap-4 justify-center">
                      <a
                        href={downloadUrl}
                        className="inline-flex items-center justify-center px-8 py-3 bg-green-500 hover:bg-green-600 text-white font-semibold rounded-xl transition-all duration-200 transform hover:scale-105 shadow-lg"
                      >
                        <Download className="w-5 h-5 mr-2" />
                        Download Converted Project
                      </a>
                      <button
                        onClick={resetProject}
                        className="px-8 py-3 bg-white/10 hover:bg-white/20 text-white font-semibold rounded-xl transition-all duration-200 backdrop-blur-sm border border-white/20"
                      >
                        Start New Project
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </main>

      {/* Footer */}
      <footer className="mt-20 bg-black/30 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="text-center">
            <p className="text-blue-200">
              Built with AST parsing, Universal Intermediate Representation, and intelligent code generation
            </p>
            <p className="text-blue-300 text-sm mt-2">
              Supporting bidirectional conversions across React, Flutter, Swift, Kotlin, Node.js, Python, Go, and more
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;