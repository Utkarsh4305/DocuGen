import express from 'express';
import cors from 'cors';
import multer from 'multer';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import { TranspilerEngine } from './core/TranspilerEngine.js';
import { ProjectAnalyzer } from './analyzers/ProjectAnalyzer.js';
import { FileHandler } from './utils/FileHandler.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../dist')));

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = path.join(__dirname, 'uploads');
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}-${file.originalname}`);
  }
});

const upload = multer({ 
  storage,
  limits: { fileSize: 50 * 1024 * 1024 } // 50MB limit
});

// Initialize core components
const transpilerEngine = new TranspilerEngine();
const projectAnalyzer = new ProjectAnalyzer();
const fileHandler = new FileHandler();

// Routes
app.post('/api/upload', upload.single('project'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    const projectPath = await fileHandler.extractProject(req.file.path);
    const analysis = await projectAnalyzer.analyzeProject(projectPath);
    
    res.json({
      success: true,
      projectId: path.basename(projectPath),
      analysis
    });
  } catch (error) {
    console.error('Upload error:', error);
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/transpile', async (req, res) => {
  try {
    const { projectId, conversions } = req.body;
    
    if (!projectId || !conversions) {
      return res.status(400).json({ error: 'Missing required parameters' });
    }

    const projectPath = path.join(__dirname, 'uploads', `extracted-${projectId}`);
    const result = await transpilerEngine.transpileProject(projectPath, conversions);
    
    res.json({
      success: true,
      downloadUrl: `/api/download/${result.outputId}`
    });
  } catch (error) {
    console.error('Transpilation error:', error);
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/download/:outputId', async (req, res) => {
  try {
    const { outputId } = req.params;
    const zipPath = await fileHandler.createDownloadZip(outputId);
    
    res.download(zipPath, `transpiled-project-${outputId}.zip`, (err) => {
      if (err) {
        console.error('Download error:', err);
        res.status(500).send('Download failed');
      }
      // Clean up the zip file after download
      setTimeout(() => {
        try {
          fs.unlinkSync(zipPath);
        } catch (cleanupErr) {
          console.error('Cleanup error:', cleanupErr);
        }
      }, 5000);
    });
  } catch (error) {
    console.error('Download error:', error);
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/languages', (req, res) => {
  try {
    const languagesPath = path.join(__dirname, 'data', 'languages.json');
    const languages = JSON.parse(fs.readFileSync(languagesPath, 'utf8'));
    res.json(languages);
  } catch (error) {
    console.error('Languages error:', error);
    res.status(500).json({ error: 'Failed to load language data' });
  }
});

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../dist/index.html'));
});

app.listen(PORT, () => {
  console.log(`Universal Code Transpiler running on port ${PORT}`);
});