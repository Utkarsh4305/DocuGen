import yauzl from 'yauzl';
import archiver from 'archiver';
import path from 'path';
import fs from 'fs';
import { promisify } from 'util';

export class FileHandler {
  async extractProject(zipPath) {
    return new Promise((resolve, reject) => {
      const extractPath = path.join(path.dirname(zipPath), `extracted-${Date.now()}`);
      
      // Create extraction directory
      if (!fs.existsSync(extractPath)) {
        fs.mkdirSync(extractPath, { recursive: true });
      }

      yauzl.open(zipPath, { lazyEntries: true }, (err, zipfile) => {
        if (err) return reject(err);

        zipfile.readEntry();
        
        zipfile.on('entry', (entry) => {
          if (/\/$/.test(entry.fileName)) {
            // Directory entry
            const dirPath = path.join(extractPath, entry.fileName);
            fs.mkdirSync(dirPath, { recursive: true });
            zipfile.readEntry();
          } else {
            // File entry
            zipfile.openReadStream(entry, (err, readStream) => {
              if (err) return reject(err);

              const filePath = path.join(extractPath, entry.fileName);
              const dirPath = path.dirname(filePath);
              
              // Ensure directory exists
              if (!fs.existsSync(dirPath)) {
                fs.mkdirSync(dirPath, { recursive: true });
              }

              const writeStream = fs.createWriteStream(filePath);
              readStream.pipe(writeStream);
              
              writeStream.on('close', () => {
                zipfile.readEntry();
              });
            });
          }
        });

        zipfile.on('end', () => {
          // Clean up original zip file
          try {
            fs.unlinkSync(zipPath);
          } catch (cleanupErr) {
            console.warn('Failed to cleanup zip file:', cleanupErr);
          }
          resolve(extractPath);
        });

        zipfile.on('error', reject);
      });
    });
  }

  async createDownloadZip(outputId) {
    return new Promise((resolve, reject) => {
      const outputDir = path.join(path.dirname(__filename), '..', 'uploads', `output-${outputId}`);
      const zipPath = path.join(path.dirname(__filename), '..', 'uploads', `download-${outputId}.zip`);

      if (!fs.existsSync(outputDir)) {
        return reject(new Error('Output directory not found'));
      }

      const output = fs.createWriteStream(zipPath);
      const archive = archiver('zip', {
        zlib: { level: 9 } // Best compression
      });

      output.on('close', () => {
        console.log(`ZIP created: ${archive.pointer()} bytes`);
        resolve(zipPath);
      });

      archive.on('warning', (err) => {
        if (err.code === 'ENOENT') {
          console.warn('Archive warning:', err);
        } else {
          reject(err);
        }
      });

      archive.on('error', reject);

      archive.pipe(output);
      
      // Add all files from the output directory
      this.addDirectoryToArchive(archive, outputDir, '');
      
      archive.finalize();
    });
  }

  addDirectoryToArchive(archive, dirPath, archivePath) {
    const items = fs.readdirSync(dirPath);
    
    for (const item of items) {
      const itemPath = path.join(dirPath, item);
      const itemArchivePath = path.join(archivePath, item);
      const stats = fs.statSync(itemPath);
      
      if (stats.isDirectory()) {
        this.addDirectoryToArchive(archive, itemPath, itemArchivePath);
      } else {
        archive.file(itemPath, { name: itemArchivePath });
      }
    }
  }

  async cleanupOldFiles() {
    const uploadsDir = path.join(path.dirname(__filename), '..', 'uploads');
    const now = Date.now();
    const maxAge = 24 * 60 * 60 * 1000; // 24 hours

    try {
      const items = fs.readdirSync(uploadsDir);
      
      for (const item of items) {
        const itemPath = path.join(uploadsDir, item);
        const stats = fs.statSync(itemPath);
        
        if (now - stats.mtime.getTime() > maxAge) {
          if (stats.isDirectory()) {
            this.removeDirectory(itemPath);
          } else {
            fs.unlinkSync(itemPath);
          }
          console.log(`Cleaned up old file/directory: ${item}`);
        }
      }
    } catch (error) {
      console.error('Cleanup error:', error);
    }
  }

  removeDirectory(dirPath) {
    if (fs.existsSync(dirPath)) {
      const items = fs.readdirSync(dirPath);
      
      for (const item of items) {
        const itemPath = path.join(dirPath, item);
        const stats = fs.statSync(itemPath);
        
        if (stats.isDirectory()) {
          this.removeDirectory(itemPath);
        } else {
          fs.unlinkSync(itemPath);
        }
      }
      
      fs.rmdirSync(dirPath);
    }
  }
}

// Run cleanup periodically
const fileHandler = new FileHandler();
setInterval(() => {
  fileHandler.cleanupOldFiles();
}, 60 * 60 * 1000); // Run every hour