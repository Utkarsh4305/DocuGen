import fs from 'fs';

export class PythonParser {
  async parseFile(filePath) {
    try {
      const content = fs.readFileSync(filePath, 'utf8');
      const nodes = [];
      
      // Simple regex-based parsing for Python (in production, use a proper AST parser)
      const lines = content.split('\n');
      let currentClass = null;
      let currentFunction = null;
      let indentLevel = 0;

      for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        const trimmed = line.trim();
        
        if (trimmed === '' || trimmed.startsWith('#')) continue;

        const currentIndent = line.length - line.trimStart().length;

        // Class definitions
        if (trimmed.startsWith('class ')) {
          const className = this.extractClassName(trimmed);
          currentClass = {
            type: 'class',
            properties: {
              name: className,
              methods: [],
              attributes: []
            },
            children: []
          };
          nodes.push(currentClass);
          indentLevel = currentIndent;
        }

        // Function definitions
        else if (trimmed.startsWith('def ')) {
          const functionInfo = this.extractFunctionInfo(trimmed);
          const functionNode = {
            type: 'function',
            properties: functionInfo,
            children: []
          };

          if (currentClass && currentIndent > indentLevel) {
            currentClass.children.push(functionNode);
            currentClass.properties.methods.push(functionInfo.name);
          } else {
            nodes.push(functionNode);
            currentClass = null;
          }
          currentFunction = functionNode;
        }

        // API routes (FastAPI/Flask)
        else if (this.isAPIRoute(trimmed)) {
          const routeInfo = this.extractRouteInfo(trimmed);
          nodes.push({
            type: 'route',
            properties: routeInfo,
            children: []
          });
        }

        // Imports
        else if (trimmed.startsWith('import ') || trimmed.startsWith('from ')) {
          const importInfo = this.extractImportInfo(trimmed);
          nodes.push({
            type: 'import',
            properties: importInfo,
            children: []
          });
        }

        // Variable assignments
        else if (this.isAssignment(trimmed)) {
          const assignment = this.extractAssignment(trimmed);
          nodes.push({
            type: 'assignment',
            properties: assignment,
            children: []
          });
        }
      }

      return nodes.map(node => ({
        ...node,
        filePath
      }));

    } catch (error) {
      console.error(`Error parsing Python file ${filePath}:`, error);
      throw error;
    }
  }

  extractClassName(line) {
    const match = line.match(/class\s+(\w+)/);
    return match ? match[1] : 'UnnamedClass';
  }

  extractFunctionInfo(line) {
    const match = line.match(/def\s+(\w+)\s*\(([^)]*)\)/);
    if (match) {
      const [, name, params] = match;
      const paramList = params.split(',').map(p => p.trim()).filter(p => p);
      
      return {
        name,
        parameters: paramList,
        isAsync: line.includes('async def'),
        decorator: this.extractDecorator(line)
      };
    }
    
    return { name: 'unknown', parameters: [] };
  }

  extractDecorator(line) {
    // Look for common decorators like @app.get, @app.post, etc.
    const decoratorMatch = line.match(/@([\w.]+)/);
    return decoratorMatch ? decoratorMatch[1] : null;
  }

  isAPIRoute(line) {
    const routePatterns = [
      /@app\.(get|post|put|delete|patch)/,
      /@router\.(get|post|put|delete|patch)/,
      /@bp\.(route)/
    ];
    
    return routePatterns.some(pattern => pattern.test(line));
  }

  extractRouteInfo(line) {
    const methodMatch = line.match(/@\w+\.(get|post|put|delete|patch)\s*\(\s*['"]([^'"]+)['"]/);
    if (methodMatch) {
      return {
        method: methodMatch[1],
        path: methodMatch[2],
        framework: line.includes('@app') ? 'fastapi' : 'flask'
      };
    }

    return { method: 'get', path: '/', framework: 'unknown' };
  }

  extractImportInfo(line) {
    if (line.startsWith('import ')) {
      const modules = line.replace('import ', '').split(',').map(m => m.trim());
      return {
        type: 'import',
        modules
      };
    } else if (line.startsWith('from ')) {
      const match = line.match(/from\s+(\S+)\s+import\s+(.+)/);
      if (match) {
        const [, module, imports] = match;
        const importList = imports.split(',').map(i => i.trim());
        return {
          type: 'from_import',
          module,
          imports: importList
        };
      }
    }

    return { type: 'unknown' };
  }

  isAssignment(line) {
    return line.includes('=') && !line.includes('==') && !line.includes('!=');
  }

  extractAssignment(line) {
    const parts = line.split('=');
    if (parts.length >= 2) {
      const variable = parts[0].trim();
      const value = parts.slice(1).join('=').trim();
      
      return {
        variable,
        value: this.parseValue(value)
      };
    }

    return { variable: 'unknown', value: null };
  }

  parseValue(value) {
    // Simple value parsing
    if (value.startsWith('"') || value.startsWith("'")) {
      return { type: 'string', value: value.slice(1, -1) };
    } else if (!isNaN(value)) {
      return { type: 'number', value: parseFloat(value) };
    } else if (value === 'True' || value === 'False') {
      return { type: 'boolean', value: value === 'True' };
    } else if (value === 'None') {
      return { type: 'null', value: null };
    } else if (value.startsWith('[') && value.endsWith(']')) {
      return { type: 'list', value: value };
    } else if (value.startsWith('{') && value.endsWith('}')) {
      return { type: 'dict', value: value };
    }

    return { type: 'expression', value };
  }
}