import { parse } from '@babel/parser';
import traverse from '@babel/traverse';
import fs from 'fs';

export class JavaScriptParser {
  async parseFile(filePath) {
    try {
      const content = fs.readFileSync(filePath, 'utf8');
      const ast = parse(content, {
        sourceType: 'module',
        plugins: [
          'jsx',
          'typescript',
          'decorators-legacy',
          'classProperties',
          'objectRestSpread',
          'functionBind',
          'exportDefaultFrom',
          'exportNamespaceFrom',
          'dynamicImport',
          'nullishCoalescingOperator',
          'optionalChaining'
        ]
      });

      const nodes = [];
      const metadata = {
        imports: [],
        exports: [],
        functions: [],
        components: [],
        hooks: []
      };

      traverse.default(ast, {
        ImportDeclaration(path) {
          metadata.imports.push({
            source: path.node.source.value,
            specifiers: path.node.specifiers.map(spec => ({
              type: spec.type,
              local: spec.local?.name,
              imported: spec.imported?.name
            }))
          });
        },

        ExportDefaultDeclaration(path) {
          if (path.node.declaration.type === 'FunctionDeclaration' || 
              path.node.declaration.type === 'ArrowFunctionExpression') {
            metadata.exports.push({
              type: 'default',
              name: path.node.declaration.name?.name || 'default'
            });
          }
        },

        FunctionDeclaration(path) {
          const func = {
            name: path.node.id?.name,
            params: path.node.params.map(param => param.name),
            isAsync: path.node.async,
            isGenerator: path.node.generator
          };

          metadata.functions.push(func);
          
          nodes.push({
            type: 'function',
            properties: func,
            children: this.extractFunctionBody(path.node.body)
          });
        },

        ArrowFunctionExpression(path) {
          if (this.isReactComponent(path)) {
            const component = this.extractReactComponent(path);
            metadata.components.push(component);
            
            nodes.push({
              type: 'component',
              properties: component,
              children: this.extractJSXElements(path.node.body)
            });
          }
        },

        FunctionExpression(path) {
          if (this.isReactComponent(path)) {
            const component = this.extractReactComponent(path);
            metadata.components.push(component);
            
            nodes.push({
              type: 'component',
              properties: component,
              children: this.extractJSXElements(path.node.body)
            });
          }
        },

        CallExpression(path) {
          if (this.isReactHook(path)) {
            const hook = this.extractReactHook(path);
            metadata.hooks.push(hook);
            
            nodes.push({
              type: 'hook',
              properties: hook,
              children: []
            });
          }

          if (this.isApiCall(path)) {
            const apiCall = this.extractApiCall(path);
            nodes.push({
              type: 'api_call',
              properties: apiCall,
              children: []
            });
          }
        },

        JSXElement(path) {
          const element = this.extractJSXElement(path);
          nodes.push({
            type: 'jsx_element',
            properties: element,
            children: this.extractJSXChildren(path.node)
          });
        }
      });

      return nodes.map(node => ({
        ...node,
        metadata,
        filePath
      }));

    } catch (error) {
      console.error(`Error parsing JavaScript file ${filePath}:`, error);
      throw error;
    }
  }

  isReactComponent(path) {
    // Check if function returns JSX
    let hasJSXReturn = false;
    
    path.traverse({
      ReturnStatement(returnPath) {
        if (returnPath.node.argument && 
            (returnPath.node.argument.type === 'JSXElement' || 
             returnPath.node.argument.type === 'JSXFragment')) {
          hasJSXReturn = true;
        }
      }
    });

    return hasJSXReturn;
  }

  extractReactComponent(path) {
    const component = {
      name: this.getComponentName(path),
      props: this.extractProps(path),
      state: this.extractState(path),
      hooks: this.extractHooksUsage(path)
    };

    return component;
  }

  getComponentName(path) {
    // Try to get name from various contexts
    if (path.parent.type === 'VariableDeclarator') {
      return path.parent.id.name;
    }
    if (path.parent.type === 'AssignmentExpression') {
      return path.parent.left.property?.name;
    }
    return 'UnnamedComponent';
  }

  extractProps(path) {
    const params = path.node.params;
    if (params.length > 0 && params[0].type === 'ObjectPattern') {
      return params[0].properties.map(prop => prop.key.name);
    }
    return [];
  }

  extractState(path) {
    const state = {};
    
    path.traverse({
      CallExpression(callPath) {
        if (callPath.node.callee.name === 'useState') {
          const parent = callPath.parent;
          if (parent.type === 'VariableDeclarator' && 
              parent.id.type === 'ArrayPattern') {
            const stateVar = parent.id.elements[0]?.name;
            const initialValue = callPath.node.arguments[0];
            
            if (stateVar) {
              state[stateVar] = this.evaluateLiteral(initialValue);
            }
          }
        }
      }
    });

    return state;
  }

  extractHooksUsage(path) {
    const hooks = [];
    
    path.traverse({
      CallExpression(callPath) {
        const calleeName = callPath.node.callee.name;
        if (calleeName && calleeName.startsWith('use')) {
          hooks.push({
            name: calleeName,
            args: callPath.node.arguments.map(arg => this.evaluateLiteral(arg))
          });
        }
      }
    });

    return hooks;
  }

  isReactHook(path) {
    const calleeName = path.node.callee.name;
    return calleeName && calleeName.startsWith('use');
  }

  extractReactHook(path) {
    return {
      name: path.node.callee.name,
      arguments: path.node.arguments.map(arg => this.evaluateLiteral(arg))
    };
  }

  isApiCall(path) {
    const callee = path.node.callee;
    
    // Check for fetch calls
    if (callee.name === 'fetch') return true;
    
    // Check for axios calls
    if (callee.type === 'MemberExpression' && 
        callee.object.name === 'axios') return true;
    
    // Check for common HTTP methods
    const httpMethods = ['get', 'post', 'put', 'delete', 'patch'];
    if (callee.type === 'MemberExpression' && 
        httpMethods.includes(callee.property.name)) return true;

    return false;
  }

  extractApiCall(path) {
    const callee = path.node.callee;
    
    if (callee.name === 'fetch') {
      return {
        type: 'fetch',
        url: this.evaluateLiteral(path.node.arguments[0]),
        options: path.node.arguments[1] ? this.evaluateLiteral(path.node.arguments[1]) : {}
      };
    }

    if (callee.type === 'MemberExpression') {
      return {
        type: 'method_call',
        object: callee.object.name,
        method: callee.property.name,
        arguments: path.node.arguments.map(arg => this.evaluateLiteral(arg))
      };
    }

    return {
      type: 'unknown',
      raw: path.node
    };
  }

  extractJSXElement(path) {
    const node = path.node;
    const element = {
      tagName: node.openingElement.name.name,
      attributes: this.extractJSXAttributes(node.openingElement.attributes),
      selfClosing: node.openingElement.selfClosing
    };

    return element;
  }

  extractJSXAttributes(attributes) {
    const attrs = {};
    
    attributes.forEach(attr => {
      if (attr.type === 'JSXAttribute') {
        const name = attr.name.name;
        const value = this.extractJSXAttributeValue(attr.value);
        attrs[name] = value;
      }
    });

    return attrs;
  }

  extractJSXAttributeValue(value) {
    if (!value) return true;
    
    if (value.type === 'StringLiteral') {
      return value.value;
    }
    
    if (value.type === 'JSXExpressionContainer') {
      return this.evaluateLiteral(value.expression);
    }

    return null;
  }

  extractJSXChildren(node) {
    if (!node.children) return [];
    
    return node.children.map(child => {
      if (child.type === 'JSXElement') {
        return {
          type: child.openingElement.name.name,
          properties: this.extractJSXAttributes(child.openingElement.attributes),
          children: this.extractJSXChildren(child)
        };
      }
      
      if (child.type === 'JSXText') {
        return {
          type: 'text',
          properties: { content: child.value.trim() },
          children: []
        };
      }

      if (child.type === 'JSXExpressionContainer') {
        return {
          type: 'expression',
          properties: { expression: this.evaluateLiteral(child.expression) },
          children: []
        };
      }

      return {
        type: 'unknown',
        properties: {},
        children: []
      };
    }).filter(child => child.type !== 'text' || child.properties.content);
  }

  extractJSXElements(body) {
    const elements = [];
    
    if (body.type === 'BlockStatement') {
      body.body.forEach(stmt => {
        if (stmt.type === 'ReturnStatement' && stmt.argument) {
          if (stmt.argument.type === 'JSXElement') {
            elements.push(this.jsxNodeToUIRNode(stmt.argument));
          }
        }
      });
    } else if (body.type === 'JSXElement') {
      elements.push(this.jsxNodeToUIRNode(body));
    }

    return elements;
  }

  jsxNodeToUIRNode(jsxNode) {
    return {
      type: jsxNode.openingElement.name.name,
      properties: this.extractJSXAttributes(jsxNode.openingElement.attributes),
      children: this.extractJSXChildren(jsxNode)
    };
  }

  extractFunctionBody(body) {
    // Simplified function body extraction
    return [{
      type: 'statement',
      properties: { type: 'function_body' },
      children: []
    }];
  }

  evaluateLiteral(node) {
    if (!node) return null;
    
    switch (node.type) {
      case 'StringLiteral':
        return node.value;
      case 'NumericLiteral':
        return node.value;
      case 'BooleanLiteral':
        return node.value;
      case 'NullLiteral':
        return null;
      case 'Identifier':
        return node.name;
      case 'ObjectExpression':
        return this.evaluateObjectExpression(node);
      case 'ArrayExpression':
        return node.elements.map(el => this.evaluateLiteral(el));
      default:
        return `<${node.type}>`;
    }
  }

  evaluateObjectExpression(node) {
    const obj = {};
    node.properties.forEach(prop => {
      if (prop.type === 'ObjectProperty') {
        const key = prop.key.name || prop.key.value;
        obj[key] = this.evaluateLiteral(prop.value);
      }
    });
    return obj;
  }
}