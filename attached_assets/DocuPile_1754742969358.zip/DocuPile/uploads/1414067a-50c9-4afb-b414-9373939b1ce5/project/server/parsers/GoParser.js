import fs from 'fs';

export class GoParser {
  async parseFile(filePath) {
    try {
      const content = fs.readFileSync(filePath, 'utf8');
      const nodes = [];
      
      const lines = content.split('\n');
      let currentPackage = null;
      let currentStruct = null;
      let currentFunction = null;

      for (let i = 0; i < lines.length; i++) {
        const line = lines[i].trim();
        
        if (line === '' || line.startsWith('//')) continue;

        // Package declaration
        if (line.startsWith('package ')) {
          currentPackage = line.replace('package ', '');
          nodes.push({
            type: 'package',
            properties: { name: currentPackage },
            children: []
          });
        }

        // Import statements
        else if (line.startsWith('import ')) {
          const importInfo = this.extractImportInfo(line, lines, i);
          nodes.push({
            type: 'import',
            properties: importInfo,
            children: []
          });
        }

        // Struct definitions
        else if (line.includes('type ') && line.includes(' struct')) {
          const structInfo = this.extractStructInfo(line);
          currentStruct = {
            type: 'struct',
            properties: structInfo,
            children: []
          };
          nodes.push(currentStruct);
        }

        // Function definitions
        else if (line.startsWith('func ')) {
          const functionInfo = this.extractFunctionInfo(line);
          const functionNode = {
            type: 'function',
            properties: functionInfo,
            children: []
          };

          if (currentStruct && functionInfo.receiver) {
            currentStruct.children.push(functionNode);
          } else {
            nodes.push(functionNode);
          }
          currentFunction = functionNode;
        }

        // HTTP handlers (common patterns)
        else if (this.isHTTPHandler(line)) {
          const handlerInfo = this.extractHTTPHandler(line);
          nodes.push({
            type: 'route',
            properties: handlerInfo,
            children: []
          });
        }

        // Variable declarations
        else if (line.startsWith('var ') || line.startsWith('const ')) {
          const varInfo = this.extractVariableDeclaration(line);
          nodes.push({
            type: 'variable',
            properties: varInfo,
            children: []
          });
        }
      }

      return nodes.map(node => ({
        ...node,
        filePath
      }));

    } catch (error) {
      console.error(`Error parsing Go file ${filePath}:`, error);
      throw error;
    }
  }

  extractImportInfo(line, lines, startIndex) {
    if (line === 'import (') {
      // Multi-line import
      const imports = [];
      let i = startIndex + 1;
      
      while (i < lines.length && lines[i].trim() !== ')') {
        const importLine = lines[i].trim();
        if (importLine && !importLine.startsWith('//')) {
          imports.push(importLine.replace(/"/g, ''));
        }
        i++;
      }
      
      return { type: 'multiline', imports };
    } else {
      // Single line import
      const match = line.match(/import\s+"([^"]+)"/);
      return {
        type: 'single',
        imports: match ? [match[1]] : []
      };
    }
  }

  extractStructInfo(line) {
    const match = line.match(/type\s+(\w+)\s+struct/);
    return {
      name: match ? match[1] : 'UnnamedStruct',
      fields: []
    };
  }

  extractFunctionInfo(line) {
    // Handle method receivers: func (r *Receiver) FuncName(params) returns
    const methodMatch = line.match(/func\s+\(([^)]+)\)\s+(\w+)\s*\(([^)]*)\)(?:\s+(.+))?/);
    if (methodMatch) {
      const [, receiver, name, params, returns] = methodMatch;
      return {
        name,
        receiver: receiver.trim(),
        parameters: this.parseParameters(params),
        returns: returns ? returns.trim() : null,
        isMethod: true
      };
    }

    // Handle regular functions: func FuncName(params) returns
    const funcMatch = line.match(/func\s+(\w+)\s*\(([^)]*)\)(?:\s+(.+))?/);
    if (funcMatch) {
      const [, name, params, returns] = funcMatch;
      return {
        name,
        parameters: this.parseParameters(params),
        returns: returns ? returns.trim() : null,
        isMethod: false
      };
    }

    return { name: 'unknown', parameters: [], isMethod: false };
  }

  parseParameters(paramString) {
    if (!paramString.trim()) return [];
    
    return paramString.split(',').map(param => {
      const parts = param.trim().split(' ');
      if (parts.length >= 2) {
        return {
          name: parts[0],
          type: parts.slice(1).join(' ')
        };
      }
      return { name: param.trim(), type: 'unknown' };
    });
  }

  isHTTPHandler(line) {
    const httpPatterns = [
      /http\.HandleFunc/,
      /router\.GET|router\.POST|router\.PUT|router\.DELETE/,
      /mux\.HandleFunc/,
      /\.Handle\(/
    ];
    
    return httpPatterns.some(pattern => pattern.test(line));
  }

  extractHTTPHandler(line) {
    // Extract HTTP method and path from common router patterns
    const ginMatch = line.match(/router\.(GET|POST|PUT|DELETE|PATCH)\s*\(\s*"([^"]+)"/);
    if (ginMatch) {
      return {
        method: ginMatch[1].toLowerCase(),
        path: ginMatch[2],
        framework: 'gin'
      };
    }

    const handleFuncMatch = line.match(/http\.HandleFunc\s*\(\s*"([^"]+)"/);
    if (handleFuncMatch) {
      return {
        method: 'any',
        path: handleFuncMatch[1],
        framework: 'net/http'
      };
    }

    return {
      method: 'unknown',
      path: '/',
      framework: 'unknown'
    };
  }

  extractVariableDeclaration(line) {
    const varMatch = line.match(/(var|const)\s+(\w+)(?:\s+([^=]+))?\s*(?:=\s*(.+))?/);
    if (varMatch) {
      const [, keyword, name, type, value] = varMatch;
      return {
        keyword,
        name,
        type: type ? type.trim() : 'inferred',
        value: value ? value.trim() : null
      };
    }

    return { keyword: 'unknown', name: 'unknown' };
  }
}