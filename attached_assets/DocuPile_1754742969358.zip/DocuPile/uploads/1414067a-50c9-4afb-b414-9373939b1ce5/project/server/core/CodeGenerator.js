import path from 'path';
import fs from 'fs';

export class CodeGenerator {
  constructor() {
    this.templates = this.loadTemplates();
  }

  loadTemplates() {
    return {
      react: {
        component: `import React from 'react';

const {{componentName}} = ({{props}}) => {
  {{hooks}}
  
  return (
    {{jsx}}
  );
};

export default {{componentName}};`,
        
        package: `{
  "name": "{{projectName}}",
  "version": "1.0.0",
  "private": true,
  "dependencies": {{dependencies}},
  "scripts": {
    "start": "react-scripts start",
    "build": "react-scripts build",
    "test": "react-scripts test",
    "eject": "react-scripts eject"
  }
}`
      },
      
      react_native: {
        component: `import React from 'react';
import { {{imports}} } from 'react-native';

const {{componentName}} = ({{props}}) => {
  {{hooks}}
  
  return (
    {{jsx}}
  );
};

export default {{componentName}};`,
        
        package: `{
  "name": "{{projectName}}",
  "version": "1.0.0",
  "private": true,
  "dependencies": {{dependencies}},
  "scripts": {
    "android": "react-native run-android",
    "ios": "react-native run-ios",
    "start": "react-native start"
  }
}`
      },

      flutter: {
        widget: `import 'package:flutter/material.dart';

class {{widgetName}} extends StatelessWidget {
  {{fields}}

  const {{widgetName}}({{constructor}});

  @override
  Widget build(BuildContext context) {
    return {{widgetTree}};
  }
}`,

        pubspec: `name: {{projectName}}
description: A new Flutter project.
version: 1.0.0+1

environment:
  sdk: ">=2.17.0 <4.0.0"

dependencies:
  flutter:
    sdk: flutter
{{dependencies}}

dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^2.0.0`
      },

      python: {
        fastapi: `from fastapi import FastAPI
from pydantic import BaseModel
{{imports}}

app = FastAPI()

{{models}}

{{routes}}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)`,

        requirements: `fastapi==0.104.1
uvicorn[standard]==0.24.0
{{dependencies}}`
      },

      nodejs: {
        express: `const express = require('express');
const cors = require('cors');
{{imports}}

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());

{{routes}}

app.listen(PORT, () => {
  console.log(\`Server running on port \${PORT}\`);
});`,

        package: `{
  "name": "{{projectName}}",
  "version": "1.0.0",
  "main": "index.js",
  "dependencies": {{dependencies}},
  "scripts": {
    "start": "node index.js",
    "dev": "nodemon index.js"
  }
}`
      },

      go: {
        main: `package main

import (
{{imports}}
)

{{structs}}

{{functions}}

func main() {
{{mainBody}}
}`
      }
    };
  }

  async generateProject(uir, outputPath) {
    // Create output directory
    if (!fs.existsSync(outputPath)) {
      fs.mkdirSync(outputPath, { recursive: true });
    }

    // Generate each component
    for (const [componentType, component] of Object.entries(uir.components)) {
      await this.generateComponent(component, componentType, outputPath);
    }

    // Copy assets
    await this.copyAssets(uir.assets, outputPath);

    // Generate configuration files
    await this.generateConfigFiles(uir, outputPath);
  }

  async generateComponent(component, componentType, outputPath) {
    const componentDir = path.join(outputPath, componentType);
    if (!fs.existsSync(componentDir)) {
      fs.mkdirSync(componentDir, { recursive: true });
    }

    const technology = component.technology;
    const generator = this.getGenerator(technology);

    if (generator) {
      await generator(component, componentDir);
    } else {
      console.warn(`No generator available for technology: ${technology}`);
    }
  }

  getGenerator(technology) {
    const generators = {
      react: this.generateReactComponent.bind(this),
      react_native: this.generateReactNativeComponent.bind(this),
      flutter: this.generateFlutterComponent.bind(this),
      python: this.generatePythonComponent.bind(this),
      nodejs: this.generateNodejsComponent.bind(this),
      go: this.generateGoComponent.bind(this)
    };

    return generators[technology];
  }

  async generateReactComponent(component, outputDir) {
    // Generate package.json
    const packageJson = this.templates.react.package
      .replace('{{projectName}}', 'transpiled-project')
      .replace('{{dependencies}}', JSON.stringify({
        "react": "^18.2.0",
        "react-dom": "^18.2.0",
        "react-scripts": "5.0.1"
      }, null, 2));

    fs.writeFileSync(path.join(outputDir, 'package.json'), packageJson);

    // Create src directory
    const srcDir = path.join(outputDir, 'src');
    if (!fs.existsSync(srcDir)) {
      fs.mkdirSync(srcDir, { recursive: true });
    }

    // Generate components
    const componentNodes = component.nodes.filter(node => node.type === 'component');
    
    for (const node of componentNodes) {
      const componentCode = this.generateReactComponentCode(node);
      const fileName = `${node.properties.name || 'Component'}.jsx`;
      fs.writeFileSync(path.join(srcDir, fileName), componentCode);
    }

    // Generate App.jsx
    const appComponent = this.generateReactApp(componentNodes);
    fs.writeFileSync(path.join(srcDir, 'App.jsx'), appComponent);

    // Generate index.js
    const indexJs = `import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);`;

    fs.writeFileSync(path.join(srcDir, 'index.js'), indexJs);

    // Generate public/index.html
    const publicDir = path.join(outputDir, 'public');
    if (!fs.existsSync(publicDir)) {
      fs.mkdirSync(publicDir, { recursive: true });
    }

    const indexHtml = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transpiled React App</title>
</head>
<body>
    <div id="root"></div>
</body>
</html>`;

    fs.writeFileSync(path.join(publicDir, 'index.html'), indexHtml);
  }

  generateReactComponentCode(node) {
    const componentName = node.properties.name || 'Component';
    const props = this.extractPropsFromNode(node);
    const hooks = this.generateHooks(node);
    const jsx = this.generateJSX(node);

    return this.templates.react.component
      .replace('{{componentName}}', componentName)
      .replace('{{props}}', props)
      .replace('{{hooks}}', hooks)
      .replace('{{jsx}}', jsx);
  }

  generateReactApp(components) {
    const imports = components.map(comp => 
      `import ${comp.properties.name} from './${comp.properties.name}';`
    ).join('\n');

    const componentUsage = components.map(comp => 
      `      <${comp.properties.name} />`
    ).join('\n');

    return `import React from 'react';
${imports}

function App() {
  return (
    <div className="App">
${componentUsage}
    </div>
  );
}

export default App;`;
  }

  async generateReactNativeComponent(component, outputDir) {
    // Similar to React but with React Native specific code
    const packageJson = this.templates.react_native.package
      .replace('{{projectName}}', 'transpiled-rn-project')
      .replace('{{dependencies}}', JSON.stringify({
        "react": "^18.2.0",
        "react-native": "^0.72.0"
      }, null, 2));

    fs.writeFileSync(path.join(outputDir, 'package.json'), packageJson);

    // Generate components with React Native imports
    const componentNodes = component.nodes.filter(node => node.type === 'component');
    
    for (const node of componentNodes) {
      const componentCode = this.generateReactNativeComponentCode(node);
      const fileName = `${node.properties.name || 'Component'}.jsx`;
      fs.writeFileSync(path.join(outputDir, fileName), componentCode);
    }
  }

  generateReactNativeComponentCode(node) {
    const componentName = node.properties.name || 'Component';
    const imports = this.extractReactNativeImports(node);
    const props = this.extractPropsFromNode(node);
    const hooks = this.generateHooks(node);
    const jsx = this.generateReactNativeJSX(node);

    return this.templates.react_native.component
      .replace('{{componentName}}', componentName)
      .replace('{{imports}}', imports)
      .replace('{{props}}', props)
      .replace('{{hooks}}', hooks)
      .replace('{{jsx}}', jsx);
  }

  async generateFlutterComponent(component, outputDir) {
    // Generate pubspec.yaml
    const pubspec = this.templates.flutter.pubspec
      .replace('{{projectName}}', 'transpiled_flutter_project')
      .replace('{{dependencies}}', '');

    fs.writeFileSync(path.join(outputDir, 'pubspec.yaml'), pubspec);

    // Create lib directory
    const libDir = path.join(outputDir, 'lib');
    if (!fs.existsSync(libDir)) {
      fs.mkdirSync(libDir, { recursive: true });
    }

    // Generate widgets
    const componentNodes = component.nodes.filter(node => node.type === 'component');
    
    for (const node of componentNodes) {
      const widgetCode = this.generateFlutterWidget(node);
      const fileName = `${(node.properties.name || 'component').toLowerCase()}.dart`;
      fs.writeFileSync(path.join(libDir, fileName), widgetCode);
    }

    // Generate main.dart
    const mainDart = this.generateFlutterMain(componentNodes);
    fs.writeFileSync(path.join(libDir, 'main.dart'), mainDart);
  }

  generateFlutterWidget(node) {
    const widgetName = node.properties.name || 'MyWidget';
    const fields = this.extractFlutterFields(node);
    const constructor = this.generateFlutterConstructor(node);
    const widgetTree = this.generateFlutterWidgetTree(node);

    return this.templates.flutter.widget
      .replace('{{widgetName}}', widgetName)
      .replace('{{fields}}', fields)
      .replace('{{constructor}}', constructor)
      .replace('{{widgetTree}}', widgetTree);
  }

  generateFlutterMain(components) {
    return `import 'package:flutter/material.dart';
${components.map(comp => `import '${(comp.properties.name || 'component').toLowerCase()}.dart';`).join('\n')}

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Transpiled Flutter App',
      home: Scaffold(
        appBar: AppBar(title: Text('Transpiled App')),
        body: Column(
          children: [
            ${components.map(comp => `${comp.properties.name}(),`).join('\n            ')}
          ],
        ),
      ),
    );
  }
}`;
  }

  async generatePythonComponent(component, outputDir) {
    const requirements = this.templates.python.requirements
      .replace('{{dependencies}}', '');

    fs.writeFileSync(path.join(outputDir, 'requirements.txt'), requirements);

    // Generate main app file
    const routes = this.generatePythonRoutes(component.nodes);
    const models = this.generatePythonModels(component.nodes);
    const imports = this.generatePythonImports(component.nodes);

    const appCode = this.templates.python.fastapi
      .replace('{{imports}}', imports)
      .replace('{{models}}', models)
      .replace('{{routes}}', routes);

    fs.writeFileSync(path.join(outputDir, 'app.py'), appCode);
  }

  async generateNodejsComponent(component, outputDir) {
    const packageJson = this.templates.nodejs.package
      .replace('{{projectName}}', 'transpiled-node-project')
      .replace('{{dependencies}}', JSON.stringify({
        "express": "^4.18.2",
        "cors": "^2.8.5"
      }, null, 2));

    fs.writeFileSync(path.join(outputDir, 'package.json'), packageJson);

    // Generate main server file
    const routes = this.generateNodejsRoutes(component.nodes);
    const imports = this.generateNodejsImports(component.nodes);

    const serverCode = this.templates.nodejs.express
      .replace('{{imports}}', imports)
      .replace('{{routes}}', routes);

    fs.writeFileSync(path.join(outputDir, 'index.js'), serverCode);
  }

  async generateGoComponent(component, outputDir) {
    const structs = this.generateGoStructs(component.nodes);
    const functions = this.generateGoFunctions(component.nodes);
    const imports = this.generateGoImports(component.nodes);
    const mainBody = this.generateGoMainBody(component.nodes);

    const goCode = this.templates.go.main
      .replace('{{imports}}', imports)
      .replace('{{structs}}', structs)
      .replace('{{functions}}', functions)
      .replace('{{mainBody}}', mainBody);

    fs.writeFileSync(path.join(outputDir, 'main.go'), goCode);

    // Generate go.mod
    const goMod = `module transpiled-go-project

go 1.21
`;
    fs.writeFileSync(path.join(outputDir, 'go.mod'), goMod);
  }

  // Helper methods for code generation
  extractPropsFromNode(node) {
    const props = node.properties.props || {};
    return Object.keys(props).length > 0 
      ? `{ ${Object.keys(props).join(', ')} }` 
      : '';
  }

  generateHooks(node) {
    const hooks = [];
    if (node.properties.state) {
      Object.keys(node.properties.state).forEach(stateVar => {
        hooks.push(`  const [${stateVar}, set${stateVar.charAt(0).toUpperCase() + stateVar.slice(1)}] = useState(${JSON.stringify(node.properties.state[stateVar])});`);
      });
    }
    return hooks.join('\n');
  }

  generateJSX(node) {
    if (node.children && node.children.length > 0) {
      const childrenJSX = node.children.map(child => this.nodeToJSX(child)).join('\n      ');
      return `    <div>\n      ${childrenJSX}\n    </div>`;
    }
    return '    <div>Generated Component</div>';
  }

  nodeToJSX(node) {
    const attributes = Object.entries(node.properties || {})
      .map(([key, value]) => `${key}="${value}"`)
      .join(' ');

    if (node.children && node.children.length > 0) {
      const childrenJSX = node.children.map(child => this.nodeToJSX(child)).join('');
      return `<${node.type} ${attributes}>${childrenJSX}</${node.type}>`;
    }

    return `<${node.type} ${attributes} />`;
  }

  generateReactNativeJSX(node) {
    // Convert HTML elements to React Native components
    const convertedNode = this.convertToReactNative(node);
    return this.generateJSX(convertedNode);
  }

  convertToReactNative(node) {
    const elementMapping = {
      'div': 'View',
      'button': 'TouchableOpacity',
      'input': 'TextInput',
      'text': 'Text',
      'img': 'Image'
    };

    const converted = {
      ...node,
      type: elementMapping[node.type] || 'View'
    };

    if (converted.children) {
      converted.children = converted.children.map(child => this.convertToReactNative(child));
    }

    return converted;
  }

  extractReactNativeImports(node) {
    const imports = new Set();
    this.collectReactNativeImports(node, imports);
    return Array.from(imports).join(', ');
  }

  collectReactNativeImports(node, imports) {
    const elementMapping = {
      'div': 'View',
      'button': 'TouchableOpacity',
      'input': 'TextInput',
      'text': 'Text',
      'img': 'Image'
    };

    const componentType = elementMapping[node.type] || 'View';
    imports.add(componentType);

    if (node.children) {
      node.children.forEach(child => this.collectReactNativeImports(child, imports));
    }
  }

  extractFlutterFields(node) {
    const props = node.properties.props || {};
    return Object.entries(props)
      .map(([key, value]) => `  final ${typeof value === 'string' ? 'String' : 'dynamic'} ${key};`)
      .join('\n');
  }

  generateFlutterConstructor(node) {
    const props = node.properties.props || {};
    if (Object.keys(props).length === 0) return '{Key? key} : super(key: key)';
    
    const params = Object.keys(props).map(prop => `required this.${prop}`).join(', ');
    return `{Key? key, ${params}} : super(key: key)`;
  }

  generateFlutterWidgetTree(node) {
    return this.nodeToFlutterWidget(node);
  }

  nodeToFlutterWidget(node) {
    const widgetMapping = {
      'div': 'Container',
      'button': 'ElevatedButton',
      'input': 'TextField',
      'text': 'Text'
    };

    const widgetType = widgetMapping[node.type] || 'Container';
    
    if (node.children && node.children.length > 0) {
      const children = node.children.map(child => this.nodeToFlutterWidget(child)).join(',\n        ');
      return `${widgetType}(
      child: Column(
        children: [
          ${children}
        ],
      ),
    )`;
    }

    return `${widgetType}()`;
  }

  generatePythonRoutes(nodes) {
    const routes = nodes
      .filter(node => node.type === 'route')
      .map(node => {
        const method = node.properties.method || 'get';
        const path = node.properties.path || '/';
        const functionName = node.properties.name || 'handler';
        
        return `@app.${method}("${path}")
async def ${functionName}():
    return {"message": "Generated endpoint"}`;
      });

    return routes.length > 0 ? routes.join('\n\n') : '@app.get("/")\nasync def root():\n    return {"message": "Transpiled API"}';
  }

  generatePythonModels(nodes) {
    return '# Generated models\n';
  }

  generatePythonImports(nodes) {
    return '# Generated imports\n';
  }

  generateNodejsRoutes(nodes) {
    const routes = nodes
      .filter(node => node.type === 'route')
      .map(node => {
        const method = node.properties.method || 'get';
        const path = node.properties.path || '/';
        
        return `app.${method}('${path}', (req, res) => {
  res.json({ message: 'Generated endpoint' });
});`;
      });

    return routes.length > 0 ? routes.join('\n\n') : `app.get('/', (req, res) => {
  res.json({ message: 'Transpiled API' });
});`;
  }

  generateNodejsImports(nodes) {
    return '// Generated imports\n';
  }

  generateGoStructs(nodes) {
    return '// Generated structs\n';
  }

  generateGoFunctions(nodes) {
    return '// Generated functions\n';
  }

  generateGoImports(nodes) {
    return `"fmt"
"net/http"`;
  }

  generateGoMainBody(nodes) {
    return `fmt.Println("Starting transpiled Go server...")
http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
    fmt.Fprintf(w, "Transpiled Go API")
})
http.ListenAndServe(":8080", nil)`;
  }

  async copyAssets(assets, outputPath) {
    const assetsDir = path.join(outputPath, 'assets');
    if (!fs.existsSync(assetsDir)) {
      fs.mkdirSync(assetsDir, { recursive: true });
    }

    for (const assetPath of assets) {
      try {
        const filename = path.basename(assetPath);
        const destPath = path.join(assetsDir, filename);
        fs.copyFileSync(assetPath, destPath);
      } catch (error) {
        console.warn(`Failed to copy asset ${assetPath}:`, error.message);
      }
    }
  }

  async generateConfigFiles(uir, outputPath) {
    // Generate README.md
    const readme = `# Transpiled Project

This project was automatically transpiled using the Universal Code Transpiler.

## Original Stack
${Object.entries(uir.components).map(([type, comp]) => `- ${type}: ${comp.technology}`).join('\n')}

## Generated Files
- Frontend components in \`frontend/\`
- Backend code in \`backend/\`
- Assets in \`assets/\`

## Getting Started
See deployment-config.json for specific instructions.
`;

    fs.writeFileSync(path.join(outputPath, 'README.md'), readme);

    // Generate .gitignore
    const gitignore = `node_modules/
__pycache__/
*.pyc
.env
dist/
build/
.DS_Store
`;

    fs.writeFileSync(path.join(outputPath, '.gitignore'), gitignore);
  }
}