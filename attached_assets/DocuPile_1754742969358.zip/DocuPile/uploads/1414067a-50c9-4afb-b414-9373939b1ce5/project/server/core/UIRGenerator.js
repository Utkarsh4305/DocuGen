import { JavaScriptParser } from '../parsers/JavaScriptParser.js';
import { PythonParser } from '../parsers/PythonParser.js';
import { GoParser } from '../parsers/GoParser.js';
import path from 'path';
import fs from 'fs';

export class UIRGenerator {
  constructor() {
    this.parsers = {
      '.js': new JavaScriptParser(),
      '.jsx': new JavaScriptParser(),
      '.ts': new JavaScriptParser(),
      '.tsx': new JavaScriptParser(),
      '.py': new PythonParser(),
      '.go': new GoParser()
    };
  }

  async generateFromProject(projectPath) {
    const projectInfo = this.analyzeProjectStructure(projectPath);
    const uir = {
      version: '1.0',
      metadata: {
        name: path.basename(projectPath),
        originalPath: projectPath,
        timestamp: new Date().toISOString()
      },
      components: {},
      dependencies: projectInfo.dependencies,
      assets: projectInfo.assets
    };

    // Parse each component
    for (const [componentType, files] of Object.entries(projectInfo.components)) {
      uir.components[componentType] = await this.parseComponent(files, componentType);
    }

    return uir;
  }

  analyzeProjectStructure(projectPath) {
    const structure = {
      components: {
        frontend: [],
        backend: [],
        database: []
      },
      dependencies: {},
      assets: []
    };

    this.walkDirectory(projectPath, (filePath, stats) => {
      const relativePath = path.relative(projectPath, filePath);
      const ext = path.extname(filePath);
      
      if (stats.isFile()) {
        // Categorize files
        if (this.isFrontendFile(relativePath, ext)) {
          structure.components.frontend.push(filePath);
        } else if (this.isBackendFile(relativePath, ext)) {
          structure.components.backend.push(filePath);
        } else if (this.isDatabaseFile(relativePath, ext)) {
          structure.components.database.push(filePath);
        } else if (this.isAssetFile(ext)) {
          structure.assets.push(filePath);
        }
      }
    });

    // Extract dependencies
    structure.dependencies = this.extractDependencies(projectPath);

    return structure;
  }

  isFrontendFile(relativePath, ext) {
    const frontendExtensions = ['.jsx', '.tsx', '.vue', '.svelte'];
    const frontendPaths = ['src/components', 'src/pages', 'src/views', 'components', 'pages'];
    
    return frontendExtensions.includes(ext) || 
           frontendPaths.some(p => relativePath.includes(p)) ||
           (ext === '.js' && this.containsReactCode(relativePath));
  }

  isBackendFile(relativePath, ext) {
    const backendExtensions = ['.py', '.go', '.java'];
    const backendPaths = ['server', 'backend', 'api', 'routes'];
    
    return backendExtensions.includes(ext) ||
           backendPaths.some(p => relativePath.includes(p)) ||
           relativePath.includes('app.js') ||
           relativePath.includes('server.js');
  }

  isDatabaseFile(relativePath, ext) {
    const dbExtensions = ['.sql', '.migration'];
    const dbPaths = ['migrations', 'database', 'db'];
    
    return dbExtensions.includes(ext) ||
           dbPaths.some(p => relativePath.includes(p));
  }

  isAssetFile(ext) {
    const assetExtensions = ['.png', '.jpg', '.jpeg', '.gif', '.svg', '.css', '.scss', '.less'];
    return assetExtensions.includes(ext);
  }

  containsReactCode(filePath) {
    try {
      const content = fs.readFileSync(filePath, 'utf8');
      return content.includes('import React') || 
             content.includes('from \'react\'') || 
             content.includes('jsx');
    } catch {
      return false;
    }
  }

  walkDirectory(dir, callback) {
    const items = fs.readdirSync(dir);
    
    for (const item of items) {
      const fullPath = path.join(dir, item);
      const stats = fs.statSync(fullPath);
      
      if (stats.isDirectory() && !this.shouldSkipDirectory(item)) {
        this.walkDirectory(fullPath, callback);
      } else {
        callback(fullPath, stats);
      }
    }
  }

  shouldSkipDirectory(dirName) {
    const skipDirs = ['node_modules', '.git', 'dist', 'build', '__pycache__', '.pytest_cache'];
    return skipDirs.includes(dirName);
  }

  async parseComponent(files, componentType) {
    const component = {
      type: componentType,
      technology: this.detectTechnology(files),
      nodes: [],
      metadata: {
        fileCount: files.length,
        mainFiles: this.identifyMainFiles(files)
      }
    };

    for (const filePath of files) {
      const ext = path.extname(filePath);
      const parser = this.parsers[ext];
      
      if (parser) {
        try {
          const fileNodes = await parser.parseFile(filePath);
          component.nodes.push(...fileNodes);
        } catch (error) {
          console.warn(`Failed to parse ${filePath}:`, error.message);
        }
      }
    }

    return component;
  }

  detectTechnology(files) {
    const extensions = files.map(f => path.extname(f));
    const hasPackageJson = files.some(f => f.endsWith('package.json'));
    const hasRequirementsTxt = files.some(f => f.endsWith('requirements.txt'));
    const hasGoMod = files.some(f => f.endsWith('go.mod'));

    if (extensions.includes('.jsx') || extensions.includes('.tsx')) {
      return 'react';
    } else if (extensions.includes('.vue')) {
      return 'vue';
    } else if (extensions.includes('.svelte')) {
      return 'svelte';
    } else if (extensions.includes('.dart')) {
      return 'flutter';
    } else if (extensions.includes('.swift')) {
      return 'swiftui';
    } else if (extensions.includes('.kt')) {
      return 'kotlin';
    } else if (extensions.includes('.py')) {
      return hasRequirementsTxt ? 'python' : 'python';
    } else if (extensions.includes('.go')) {
      return 'go';
    } else if (extensions.includes('.js') && hasPackageJson) {
      return 'nodejs';
    }

    return 'unknown';
  }

  identifyMainFiles(files) {
    const mainFileNames = [
      'index.js', 'index.jsx', 'index.ts', 'index.tsx',
      'App.js', 'App.jsx', 'App.ts', 'App.tsx',
      'main.py', 'app.py', 'server.py',
      'main.go', 'server.go'
    ];

    return files.filter(f => {
      const basename = path.basename(f);
      return mainFileNames.includes(basename);
    });
  }

  extractDependencies(projectPath) {
    const dependencies = {};

    // Extract from package.json
    const packageJsonPath = path.join(projectPath, 'package.json');
    if (fs.existsSync(packageJsonPath)) {
      try {
        const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8'));
        dependencies.npm = {
          ...packageJson.dependencies,
          ...packageJson.devDependencies
        };
      } catch (error) {
        console.warn('Failed to parse package.json:', error.message);
      }
    }

    // Extract from requirements.txt
    const requirementsPath = path.join(projectPath, 'requirements.txt');
    if (fs.existsSync(requirementsPath)) {
      try {
        const requirements = fs.readFileSync(requirementsPath, 'utf8')
          .split('\n')
          .filter(line => line.trim() && !line.startsWith('#'))
          .reduce((acc, line) => {
            const [pkg] = line.split('==');
            acc[pkg.trim()] = line.includes('==') ? line.split('==')[1] : 'latest';
            return acc;
          }, {});
        dependencies.pip = requirements;
      } catch (error) {
        console.warn('Failed to parse requirements.txt:', error.message);
      }
    }

    // Extract from go.mod
    const goModPath = path.join(projectPath, 'go.mod');
    if (fs.existsSync(goModPath)) {
      try {
        const goMod = fs.readFileSync(goModPath, 'utf8');
        const requires = goMod.match(/require\s*\(([\s\S]*?)\)/);
        if (requires) {
          const deps = requires[1]
            .split('\n')
            .map(line => line.trim())
            .filter(line => line && !line.startsWith('//'))
            .reduce((acc, line) => {
              const parts = line.split(/\s+/);
              if (parts.length >= 2) {
                acc[parts[0]] = parts[1];
              }
              return acc;
            }, {});
          dependencies.go = deps;
        }
      } catch (error) {
        console.warn('Failed to parse go.mod:', error.message);
      }
    }

    return dependencies;
  }
}