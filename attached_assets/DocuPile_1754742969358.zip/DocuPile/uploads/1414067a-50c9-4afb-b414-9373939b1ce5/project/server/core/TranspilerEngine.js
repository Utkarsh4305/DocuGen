import { UIRGenerator } from './UIRGenerator.js';
import { CodeGenerator } from './CodeGenerator.js';
import { TestGenerator } from './TestGenerator.js';
import path from 'path';
import fs from 'fs';
import { v4 as uuidv4 } from 'uuid';

export class TranspilerEngine {
  constructor() {
    this.uirGenerator = new UIRGenerator();
    this.codeGenerator = new CodeGenerator();
    this.testGenerator = new TestGenerator();
  }

  async transpileProject(projectPath, conversions) {
    const outputId = uuidv4();
    const outputPath = path.join(path.dirname(projectPath), `output-${outputId}`);

    try {
      // Step 1: Generate Universal Intermediate Representation
      console.log('Generating UIR...');
      const uir = await this.uirGenerator.generateFromProject(projectPath);
      
      // Step 2: Apply conversions to each component
      console.log('Applying conversions...');
      const convertedUIR = await this.applyConversions(uir, conversions);
      
      // Step 3: Generate target code
      console.log('Generating target code...');
      await this.codeGenerator.generateProject(convertedUIR, outputPath);
      
      // Step 4: Generate tests
      console.log('Generating tests...');
      await this.testGenerator.generateTests(convertedUIR, outputPath);
      
      // Step 5: Create deployment configuration
      console.log('Creating deployment config...');
      await this.createDeploymentConfig(convertedUIR, outputPath);

      return { outputId, outputPath };
    } catch (error) {
      console.error('Transpilation error:', error);
      throw error;
    }
  }

  async applyConversions(uir, conversions) {
    const convertedUIR = JSON.parse(JSON.stringify(uir)); // Deep copy
    
    for (const [component, conversion] of Object.entries(conversions)) {
      if (conversion.from !== conversion.to) {
        console.log(`Converting ${component}: ${conversion.from} → ${conversion.to}`);
        convertedUIR.components[component] = await this.convertComponent(
          convertedUIR.components[component],
          conversion
        );
      }
    }

    return convertedUIR;
  }

  async convertComponent(component, conversion) {
    const conversionKey = `${conversion.from}_to_${conversion.to}`;
    const conversionRules = this.getConversionRules(conversionKey);
    
    if (!conversionRules) {
      throw new Error(`Conversion not supported: ${conversion.from} → ${conversion.to}`);
    }

    // Apply transformation rules
    const converted = {
      ...component,
      technology: conversion.to,
      nodes: await this.transformNodes(component.nodes, conversionRules)
    };

    return converted;
  }

  async transformNodes(nodes, rules) {
    const transformed = [];
    
    for (const node of nodes) {
      const transformedNode = await this.transformNode(node, rules);
      transformed.push(transformedNode);
    }

    return transformed;
  }

  async transformNode(node, rules) {
    const rule = rules[node.type] || rules.default;
    
    if (!rule) {
      return node; // No transformation rule, keep as-is
    }

    return {
      ...node,
      type: rule.targetType || node.type,
      properties: this.transformProperties(node.properties, rule.propertyMappings || {}),
      children: node.children ? await this.transformNodes(node.children, rules) : []
    };
  }

  transformProperties(properties, mappings) {
    const transformed = {};
    
    for (const [key, value] of Object.entries(properties)) {
      const mapping = mappings[key];
      if (mapping) {
        if (typeof mapping === 'string') {
          transformed[mapping] = value;
        } else if (typeof mapping === 'function') {
          const result = mapping(value);
          Object.assign(transformed, result);
        }
      } else {
        transformed[key] = value;
      }
    }

    return transformed;
  }

  getConversionRules(conversionKey) {
    // This would be loaded from a configuration file in a real implementation
    const rules = {
      'react_to_react_native': {
        'component': {
          targetType: 'component',
          propertyMappings: {
            'className': 'style',
            'onClick': 'onPress'
          }
        },
        'div': {
          targetType: 'View',
          propertyMappings: {
            'className': 'style'
          }
        },
        'button': {
          targetType: 'TouchableOpacity',
          propertyMappings: {
            'onClick': 'onPress',
            'className': 'style'
          }
        },
        'input': {
          targetType: 'TextInput',
          propertyMappings: {
            'value': 'value',
            'onChange': 'onChangeText'
          }
        },
        'default': {
          targetType: 'View'
        }
      },
      'react_to_flutter': {
        'component': {
          targetType: 'Widget',
          propertyMappings: {}
        },
        'div': {
          targetType: 'Container',
          propertyMappings: {}
        },
        'button': {
          targetType: 'ElevatedButton',
          propertyMappings: {
            'onClick': 'onPressed'
          }
        },
        'input': {
          targetType: 'TextField',
          propertyMappings: {
            'value': 'controller',
            'onChange': 'onChanged'
          }
        },
        'default': {
          targetType: 'Container'
        }
      },
      'nodejs_to_python': {
        'function': {
          targetType: 'function',
          propertyMappings: {}
        },
        'route': {
          targetType: 'endpoint',
          propertyMappings: {
            'app.get': 'app.get',
            'app.post': 'app.post'
          }
        },
        'default': {
          targetType: 'statement'
        }
      }
    };

    return rules[conversionKey];
  }

  async createDeploymentConfig(uir, outputPath) {
    const config = {
      name: uir.metadata.name,
      version: '1.0.0',
      frontend: uir.components.frontend?.technology,
      backend: uir.components.backend?.technology,
      database: uir.components.database?.technology,
      deploymentInstructions: this.generateDeploymentInstructions(uir)
    };

    const configPath = path.join(outputPath, 'deployment-config.json');
    fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
  }

  generateDeploymentInstructions(uir) {
    const instructions = [];
    
    if (uir.components.frontend) {
      const tech = uir.components.frontend.technology;
      if (tech === 'react') {
        instructions.push('Frontend: Run "npm install && npm run build" to build React app');
      } else if (tech === 'flutter') {
        instructions.push('Frontend: Run "flutter build web" for web deployment');
      } else if (tech === 'react_native') {
        instructions.push('Frontend: Run "npx react-native run-android" or "npx react-native run-ios"');
      }
    }

    if (uir.components.backend) {
      const tech = uir.components.backend.technology;
      if (tech === 'nodejs') {
        instructions.push('Backend: Run "npm install && npm start" to start Node.js server');
      } else if (tech === 'python') {
        instructions.push('Backend: Run "pip install -r requirements.txt && python app.py"');
      } else if (tech === 'go') {
        instructions.push('Backend: Run "go mod tidy && go run main.go"');
      }
    }

    if (uir.components.database) {
      const tech = uir.components.database.technology;
      if (tech === 'mongodb') {
        instructions.push('Database: Ensure MongoDB is running and update connection string');
      } else if (tech === 'postgresql') {
        instructions.push('Database: Set up PostgreSQL and run migration scripts');
      }
    }

    return instructions;
  }
}