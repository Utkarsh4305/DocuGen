import path from 'path';
import fs from 'fs';

export class ProjectAnalyzer {
  async analyzeProject(projectPath) {
    const analysis = {
      techStack: {},
      languageDistribution: {},
      dependencies: {},
      structure: {},
      recommendations: []
    };

    // Analyze file structure
    analysis.structure = this.analyzeStructure(projectPath);
    
    // Analyze languages and calculate distribution
    analysis.languageDistribution = this.calculateLanguageDistribution(projectPath);
    
    // Detect technologies
    analysis.techStack = this.detectTechnologies(projectPath, analysis.languageDistribution);
    
    // Extract dependencies
    analysis.dependencies = this.extractAllDependencies(projectPath);
    
    // Generate recommendations
    analysis.recommendations = this.generateRecommendations(analysis);

    return analysis;
  }

  analyzeStructure(projectPath) {
    const structure = {
      directories: [],
      files: [],
      configFiles: [],
      totalSize: 0
    };

    this.walkDirectory(projectPath, (filePath, stats) => {
      const relativePath = path.relative(projectPath, filePath);
      
      if (stats.isDirectory()) {
        structure.directories.push(relativePath);
      } else {
        structure.files.push({
          path: relativePath,
          size: stats.size,
          extension: path.extname(filePath)
        });
        structure.totalSize += stats.size;

        if (this.isConfigFile(path.basename(filePath))) {
          structure.configFiles.push(relativePath);
        }
      }
    });

    return structure;
  }

  calculateLanguageDistribution(projectPath) {
    const distribution = {};
    let totalLines = 0;

    this.walkDirectory(projectPath, (filePath, stats) => {
      if (stats.isFile()) {
        const ext = path.extname(filePath);
        const language = this.getLanguageFromExtension(ext);
        
        if (language !== 'unknown') {
          const lines = this.countLines(filePath);
          
          if (!distribution[language]) {
            distribution[language] = {
              lines: 0,
              files: 0,
              percentage: 0,
              extensions: new Set()
            };
          }
          
          distribution[language].lines += lines;
          distribution[language].files += 1;
          distribution[language].extensions.add(ext);
          totalLines += lines;
        }
      }
    });

    // Calculate percentages
    Object.keys(distribution).forEach(lang => {
      distribution[lang].percentage = Math.round((distribution[lang].lines / totalLines) * 100);
      distribution[lang].extensions = Array.from(distribution[lang].extensions);
    });

    return distribution;
  }

  getLanguageFromExtension(ext) {
    const languageMap = {
      '.js': 'JavaScript',
      '.jsx': 'JavaScript',
      '.ts': 'TypeScript',
      '.tsx': 'TypeScript',
      '.py': 'Python',
      '.go': 'Go',
      '.java': 'Java',
      '.cs': 'C#',
      '.cpp': 'C++',
      '.c': 'C',
      '.rs': 'Rust',
      '.php': 'PHP',
      '.rb': 'Ruby',
      '.swift': 'Swift',
      '.kt': 'Kotlin',
      '.dart': 'Dart',
      '.vue': 'Vue',
      '.svelte': 'Svelte',
      '.html': 'HTML',
      '.css': 'CSS',
      '.scss': 'SCSS',
      '.less': 'Less',
      '.sql': 'SQL',
      '.sh': 'Shell',
      '.yml': 'YAML',
      '.yaml': 'YAML',
      '.json': 'JSON',
      '.xml': 'XML',
      '.md': 'Markdown'
    };

    return languageMap[ext] || 'unknown';
  }

  countLines(filePath) {
    try {
      const content = fs.readFileSync(filePath, 'utf8');
      return content.split('\n').length;
    } catch {
      return 0;
    }
  }

  detectTechnologies(projectPath, languageDistribution) {
    const techStack = {
      frontend: [],
      backend: [],
      database: [],
      mobile: [],
      tools: []
    };

    // Analyze based on file presence and package.json/requirements.txt
    const packageJsonPath = path.join(projectPath, 'package.json');
    const requirementsPath = path.join(projectPath, 'requirements.txt');
    const goModPath = path.join(projectPath, 'go.mod');
    const pubspecPath = path.join(projectPath, 'pubspec.yaml');

    // Frontend detection
    if (fs.existsSync(packageJsonPath)) {
      const packageJson = this.parsePackageJson(packageJsonPath);
      techStack.frontend.push(...this.detectFrontendTech(packageJson, languageDistribution));
      techStack.tools.push(...this.detectBuildTools(packageJson));
    }

    // Backend detection
    if (fs.existsSync(requirementsPath)) {
      const requirements = this.parseRequirements(requirementsPath);
      techStack.backend.push(...this.detectPythonFrameworks(requirements));
    }

    if (fs.existsSync(goModPath)) {
      const goMod = this.parseGoMod(goModPath);
      techStack.backend.push(...this.detectGoFrameworks(goMod));
    }

    if (languageDistribution.JavaScript || languageDistribution.TypeScript) {
      techStack.backend.push(...this.detectNodejsFrameworks(packageJsonPath));
    }

    // Mobile detection
    if (fs.existsSync(pubspecPath)) {
      techStack.mobile.push('Flutter');
    }

    if (languageDistribution.Swift) {
      techStack.mobile.push('iOS/Swift');
    }

    if (languageDistribution.Kotlin) {
      techStack.mobile.push('Android/Kotlin');
    }

    // Database detection
    techStack.database.push(...this.detectDatabases(projectPath));

    return techStack;
  }

  parsePackageJson(filePath) {
    try {
      const content = fs.readFileSync(filePath, 'utf8');
      return JSON.parse(content);
    } catch {
      return {};
    }
  }

  parseRequirements(filePath) {
    try {
      const content = fs.readFileSync(filePath, 'utf8');
      return content.split('\n')
        .map(line => line.trim())
        .filter(line => line && !line.startsWith('#'))
        .map(line => line.split('==')[0].trim());
    } catch {
      return [];
    }
  }

  parseGoMod(filePath) {
    try {
      const content = fs.readFileSync(filePath, 'utf8');
      return content;
    } catch {
      return '';
    }
  }

  detectFrontendTech(packageJson, languageDistribution) {
    const frontend = [];
    const deps = { ...packageJson.dependencies, ...packageJson.devDependencies };

    if (deps.react || deps['@types/react']) {
      frontend.push('React');
    }
    if (deps.vue || deps['@vue/cli']) {
      frontend.push('Vue.js');
    }
    if (deps['@angular/core']) {
      frontend.push('Angular');
    }
    if (deps.svelte) {
      frontend.push('Svelte');
    }
    if (deps.next) {
      frontend.push('Next.js');
    }
    if (deps.nuxt) {
      frontend.push('Nuxt.js');
    }
    if (deps['react-native']) {
      frontend.push('React Native');
    }

    return frontend;
  }

  detectBuildTools(packageJson) {
    const tools = [];
    const deps = { ...packageJson.dependencies, ...packageJson.devDependencies };

    if (deps.webpack) tools.push('Webpack');
    if (deps.vite) tools.push('Vite');
    if (deps.parcel) tools.push('Parcel');
    if (deps.rollup) tools.push('Rollup');
    if (deps.babel || deps['@babel/core']) tools.push('Babel');
    if (deps.typescript) tools.push('TypeScript');
    if (deps.eslint) tools.push('ESLint');
    if (deps.prettier) tools.push('Prettier');

    return tools;
  }

  detectPythonFrameworks(requirements) {
    const frameworks = [];

    if (requirements.includes('fastapi')) frameworks.push('FastAPI');
    if (requirements.includes('django')) frameworks.push('Django');
    if (requirements.includes('flask')) frameworks.push('Flask');
    if (requirements.includes('tornado')) frameworks.push('Tornado');
    if (requirements.includes('starlette')) frameworks.push('Starlette');

    return frameworks;
  }

  detectGoFrameworks(goModContent) {
    const frameworks = [];

    if (goModContent.includes('github.com/gin-gonic/gin')) frameworks.push('Gin');
    if (goModContent.includes('github.com/labstack/echo')) frameworks.push('Echo');
    if (goModContent.includes('github.com/gofiber/fiber')) frameworks.push('Fiber');
    if (goModContent.includes('github.com/gorilla/mux')) frameworks.push('Gorilla Mux');

    return frameworks;
  }

  detectNodejsFrameworks(packageJsonPath) {
    if (!fs.existsSync(packageJsonPath)) return [];

    const packageJson = this.parsePackageJson(packageJsonPath);
    const deps = { ...packageJson.dependencies, ...packageJson.devDependencies };
    const frameworks = [];

    if (deps.express) frameworks.push('Express');
    if (deps.koa) frameworks.push('Koa');
    if (deps.fastify) frameworks.push('Fastify');
    if (deps.nestjs || deps['@nestjs/core']) frameworks.push('NestJS');

    return frameworks;
  }

  detectDatabases(projectPath) {
    const databases = [];

    // Check for database config files
    if (fs.existsSync(path.join(projectPath, 'docker-compose.yml'))) {
      const dockerCompose = this.readFileContent(path.join(projectPath, 'docker-compose.yml'));
      if (dockerCompose.includes('postgres')) databases.push('PostgreSQL');
      if (dockerCompose.includes('mysql')) databases.push('MySQL');
      if (dockerCompose.includes('mongo')) databases.push('MongoDB');
      if (dockerCompose.includes('redis')) databases.push('Redis');
    }

    // Check for migration directories
    if (fs.existsSync(path.join(projectPath, 'migrations'))) {
      databases.push('SQL Database (detected migrations)');
    }

    // Check for database files
    if (this.findFilesByExtension(projectPath, '.sql').length > 0) {
      databases.push('SQL');
    }

    if (this.findFilesByExtension(projectPath, '.sqlite').length > 0 ||
        this.findFilesByExtension(projectPath, '.db').length > 0) {
      databases.push('SQLite');
    }

    return databases;
  }

  extractAllDependencies(projectPath) {
    const dependencies = {};

    // Node.js dependencies
    const packageJsonPath = path.join(projectPath, 'package.json');
    if (fs.existsSync(packageJsonPath)) {
      const packageJson = this.parsePackageJson(packageJsonPath);
      dependencies.npm = {
        dependencies: packageJson.dependencies || {},
        devDependencies: packageJson.devDependencies || {}
      };
    }

    // Python dependencies
    const requirementsPath = path.join(projectPath, 'requirements.txt');
    if (fs.existsSync(requirementsPath)) {
      dependencies.pip = this.parseRequirements(requirementsPath);
    }

    // Go dependencies
    const goModPath = path.join(projectPath, 'go.mod');
    if (fs.existsSync(goModPath)) {
      dependencies.go = this.parseGoMod(goModPath);
    }

    // Flutter dependencies
    const pubspecPath = path.join(projectPath, 'pubspec.yaml');
    if (fs.existsSync(pubspecPath)) {
      dependencies.flutter = this.readFileContent(pubspecPath);
    }

    return dependencies;
  }

  generateRecommendations(analysis) {
    const recommendations = [];
    const { techStack, languageDistribution } = analysis;

    // Migration recommendations
    if (techStack.frontend.includes('React')) {
      recommendations.push({
        type: 'migration',
        title: 'Consider React Native for Mobile',
        description: 'Your React skills can be leveraged for mobile development with React Native',
        difficulty: 'medium',
        impact: 'high'
      });
    }

    if (techStack.backend.includes('Node.js') && languageDistribution.JavaScript) {
      recommendations.push({
        type: 'migration',
        title: 'Migrate to TypeScript',
        description: 'Adding TypeScript can improve code quality and development experience',
        difficulty: 'low',
        impact: 'medium'
      });
    }

    if (languageDistribution.Python && techStack.backend.includes('Flask')) {
      recommendations.push({
        type: 'migration',
        title: 'Consider FastAPI for Better Performance',
        description: 'FastAPI offers better performance and automatic API documentation',
        difficulty: 'medium',
        impact: 'high'
      });
    }

    // Performance recommendations
    if (Object.keys(languageDistribution).length > 3) {
      recommendations.push({
        type: 'optimization',
        title: 'Consider Language Consolidation',
        description: 'Using fewer languages can simplify maintenance and deployment',
        difficulty: 'high',
        impact: 'medium'
      });
    }

    return recommendations;
  }

  // Utility methods
  walkDirectory(dir, callback) {
    try {
      const items = fs.readdirSync(dir);
      
      for (const item of items) {
        const fullPath = path.join(dir, item);
        const stats = fs.statSync(fullPath);
        
        callback(fullPath, stats);
        
        if (stats.isDirectory() && !this.shouldSkipDirectory(item)) {
          this.walkDirectory(fullPath, callback);
        }
      }
    } catch (error) {
      console.warn(`Failed to read directory ${dir}:`, error.message);
    }
  }

  shouldSkipDirectory(dirName) {
    const skipDirs = [
      'node_modules', '.git', 'dist', 'build', '__pycache__', 
      '.pytest_cache', 'vendor', '.next', '.nuxt', 'target'
    ];
    return skipDirs.includes(dirName);
  }

  isConfigFile(filename) {
    const configFiles = [
      'package.json', 'package-lock.json', 'yarn.lock',
      'requirements.txt', 'Pipfile', 'poetry.lock',
      'go.mod', 'go.sum',
      'Dockerfile', 'docker-compose.yml',
      'webpack.config.js', 'vite.config.js',
      'tsconfig.json', 'jsconfig.json',
      '.eslintrc', '.prettierrc',
      'pubspec.yaml'
    ];
    
    return configFiles.includes(filename) || filename.startsWith('.env');
  }

  findFilesByExtension(dir, extension) {
    const files = [];
    
    this.walkDirectory(dir, (filePath, stats) => {
      if (stats.isFile() && path.extname(filePath) === extension) {
        files.push(filePath);
      }
    });
    
    return files;
  }

  readFileContent(filePath) {
    try {
      return fs.readFileSync(filePath, 'utf8');
    } catch {
      return '';
    }
  }
}